/*
 jQuery JavaScript Library v1.6.4
 http://jquery.com/

 Copyright 2011, John Resig
 Dual licensed under the MIT or GPL Version 2 licenses.
 http://jquery.org/license

 Includes Sizzle.js
 http://sizzlejs.com/
 Copyright 2011, The Dojo Foundation
 Released under the MIT, BSD, and GPL Licenses.

 Amazon elects to use jQuery and Sizzle under the MIT license.

 Date: Mon Sep 12 18:54:48 2011 -0400
 Sizzle CSS Selector Engine
  Copyright 2011, The Dojo Foundation
  Released under the MIT, BSD, and GPL Licenses.
  More information: http://sizzlejs.com/
*/
(function (N) {
  var r = window.AmazonUIPageJS || window.P,
    p = r._namespace || r.attributeErrors,
    C = p ? p("AmazonUIjQuery", "AmazonUI") : r;
  C.guardFatal
    ? C.guardFatal(N)(C, window)
    : C.execute(function () {
        N(C, window);
      });
})(function (N, r, p) {
  r.navigator &&
    r.navigator.userAgent &&
    N.declare(
      "jQuery",
      (function () {
        function C(a, b, d) {
          if (d === p && 1 === a.nodeType)
            if (
              ((d = "data-" + b.replace(gb, "-$1").toLowerCase()),
              (d = a.getAttribute(d)),
              "string" === typeof d)
            ) {
              try {
                d =
                  "true" === d
                    ? !0
                    : "false" === d
                    ? !1
                    : "null" === d
                    ? null
                    : c.isNaN(d)
                    ? hb.test(d)
                      ? c.parseJSON(d)
                      : d
                    : parseFloat(d);
              } catch (e) {}
              c.data(a, b, d);
            } else d = p;
          return d;
        }
        function ha(a) {
          for (var b in a) if ("toJSON" !== b) return !1;
          return !0;
        }
        function va(a, b, d) {
          var e = b + "defer",
            f = b + "queue",
            g = b + "mark",
            h = c.data(a, e, p, !0);
          !h ||
            ("queue" !== d && c.data(a, f, p, !0)) ||
            ("mark" !== d && c.data(a, g, p, !0)) ||
            setTimeout(function () {
              c.data(a, f, p, !0) ||
                c.data(a, g, p, !0) ||
                (c.removeData(a, e, !0), h.resolve());
            }, 0);
        }
        function H() {
          return !1;
        }
        function W() {
          return !0;
        }
        function wa(a, b, d) {
          var e = c.extend({}, d[0]);
          e.type = a;
          e.originalEvent = {};
          e.liveFired = p;
          c.event.handle.call(b, e);
          e.isDefaultPrevented() && d[0].preventDefault();
        }
        function ib(a) {
          var b,
            d,
            e,
            f,
            g = [];
          var h = [];
          var k = c._data(this, "events");
          if (
            a.liveFired !== this &&
            k &&
            k.live &&
            !a.target.disabled &&
            (!a.button || "click" !== a.type)
          ) {
            a.namespace &&
              (f = new RegExp(
                "(^|\\.)" +
                  a.namespace.split(".").join("\\.(?:.*\\.)?") +
                  "(\\.|$)"
              ));
            a.liveFired = this;
            var l = k.live.slice(0);
            for (d = 0; d < l.length; d++)
              (k = l[d]),
                k.origType.replace(ia, "") === a.type
                  ? h.push(k.selector)
                  : l.splice(d--, 1);
            h = c(a.target).closest(h, a.currentTarget);
            var m = 0;
            for (e = h.length; m < e; m++) {
              var n = h[m];
              for (d = 0; d < l.length; d++)
                if (
                  ((k = l[d]),
                  n.selector === k.selector &&
                    (!f || f.test(k.namespace)) &&
                    !n.elem.disabled)
                ) {
                  var p = n.elem;
                  var q = null;
                  if ("mouseenter" === k.preType || "mouseleave" === k.preType)
                    (a.type = k.preType),
                      (q = c(a.relatedTarget).closest(k.selector)[0]) &&
                        c.contains(p, q) &&
                        (q = p);
                  (q && q === p) ||
                    g.push({elem: p, handleObj: k, level: n.level});
                }
            }
            m = 0;
            for (e = g.length; m < e; m++) {
              h = g[m];
              if (r && h.level > r) break;
              a.currentTarget = h.elem;
              a.data = h.handleObj.data;
              a.handleObj = h.handleObj;
              f = h.handleObj.origHandler.apply(h.elem, arguments);
              if (!1 === f || a.isPropagationStopped()) {
                var r = h.level;
                !1 === f && (b = !1);
                if (a.isImmediatePropagationStopped()) break;
              }
            }
            return b;
          }
        }
        function X(a, b) {
          return (
            (a && "*" !== a ? a + "." : "") +
            b.replace(jb, "`").replace(kb, "\x26")
          );
        }
        function xa(a) {
          return !a || !a.parentNode || 11 === a.parentNode.nodeType;
        }
        function ya(a, b, d) {
          b = b || 0;
          if (c.isFunction(b))
            return c.grep(a, function (a, c) {
              return !!b.call(a, c, a) === d;
            });
          if (b.nodeType)
            return c.grep(a, function (a, c) {
              return (a === b) === d;
            });
          if ("string" === typeof b) {
            var e = c.grep(a, function (a) {
              return 1 === a.nodeType;
            });
            if (lb.test(b)) return c.filter(b, e, !d);
            b = c.filter(b, e);
          }
          return c.grep(a, function (a, e) {
            return 0 <= c.inArray(a, b) === d;
          });
        }
        function mb(a, b) {
          return c.nodeName(a, "table")
            ? a.getElementsByTagName("tbody")[0] ||
                a.appendChild(a.ownerDocument.createElement("tbody"))
            : a;
        }
        function za(a, b) {
          if (1 === b.nodeType && c.hasData(a)) {
            var d = c.expando,
              e = c.data(a),
              f = c.data(b, e);
            if ((e = e[d]))
              if (((a = e.events), (f = f[d] = c.extend({}, e)), a)) {
                delete f.handle;
                f.events = {};
                for (var g in a)
                  for (d = 0, e = a[g].length; d < e; d++)
                    c.event.add(
                      b,
                      g + (a[g][d].namespace ? "." : "") + a[g][d].namespace,
                      a[g][d],
                      a[g][d].data
                    );
              }
          }
        }
        function Aa(a, b) {
          if (1 === b.nodeType) {
            b.clearAttributes && b.clearAttributes();
            b.mergeAttributes && b.mergeAttributes(a);
            var d = b.nodeName.toLowerCase();
            if ("object" === d) b.outerHTML = a.outerHTML;
            else if (
              "input" === d &&
              ("checkbox" === a.type || "radio" === a.type)
            )
              a.checked && (b.defaultChecked = b.checked = a.checked),
                b.value !== a.value && (b.value = a.value);
            else if ("option" === d) b.selected = a.defaultSelected;
            else if ("input" === d || "textarea" === d)
              b.defaultValue = a.defaultValue;
            b.removeAttribute(c.expando);
          }
        }
        function Y(a) {
          return "getElementsByTagName" in a
            ? a.getElementsByTagName("*")
            : "querySelectorAll" in a
            ? a.querySelectorAll("*")
            : [];
        }
        function Ba(a) {
          if ("checkbox" === a.type || "radio" === a.type)
            a.defaultChecked = a.checked;
        }
        function Ca(a) {
          c.nodeName(a, "input")
            ? Ba(a)
            : "getElementsByTagName" in a &&
              c.grep(a.getElementsByTagName("input"), Ba);
        }
        function nb(a, b) {
          b.src
            ? c.ajax({url: b.src, async: !1, dataType: "script"})
            : c.globalEval(
                (b.text || b.textContent || b.innerHTML || "").replace(
                  ob,
                  "/*$0*/"
                )
              );
          b.parentNode && b.parentNode.removeChild(b);
        }
        function Da(a, b, d) {
          var e = "width" === b ? a.offsetWidth : a.offsetHeight,
            f = "width" === b ? pb : qb;
          if (0 < e)
            return (
              "border" !== d &&
                c.each(f, function () {
                  d || (e -= parseFloat(c.css(a, "padding" + this)) || 0);
                  e =
                    "margin" === d
                      ? e + (parseFloat(c.css(a, d + this)) || 0)
                      : e -
                        (parseFloat(c.css(a, "border" + this + "Width")) || 0);
                }),
              e + "px"
            );
          e = U(a, b, b);
          if (0 > e || null == e) e = a.style[b] || 0;
          e = parseFloat(e) || 0;
          d &&
            c.each(f, function () {
              e += parseFloat(c.css(a, "padding" + this)) || 0;
              "padding" !== d &&
                (e += parseFloat(c.css(a, "border" + this + "Width")) || 0);
              "margin" === d && (e += parseFloat(c.css(a, d + this)) || 0);
            });
          return e + "px";
        }
        function Ea(a) {
          return function (b, d) {
            "string" !== typeof b && ((d = b), (b = "*"));
            if (c.isFunction(d)) {
              b = b.toLowerCase().split(Fa);
              for (var e = 0, f = b.length, g, h; e < f; e++)
                (g = b[e]),
                  (h = /^\+/.test(g)) && (g = g.substr(1) || "*"),
                  (g = a[g] = a[g] || []),
                  g[h ? "unshift" : "push"](d);
            }
          };
        }
        function Z(a, b, c, e, f, g) {
          f = f || b.dataTypes[0];
          g = g || {};
          g[f] = !0;
          f = a[f];
          for (
            var d = 0, k = f ? f.length : 0, l = a === ja, m;
            d < k && (l || !m);
            d++
          )
            (m = f[d](b, c, e)),
              "string" === typeof m &&
                (!l || g[m]
                  ? (m = p)
                  : (b.dataTypes.unshift(m), (m = Z(a, b, c, e, m, g))));
          (!l && m) || g["*"] || (m = Z(a, b, c, e, "*", g));
          return m;
        }
        function Ga(a, b) {
          var d,
            e,
            f = c.ajaxSettings.flatOptions || {};
          for (d in b) b[d] !== p && ((f[d] ? a : e || (e = {}))[d] = b[d]);
          e && c.extend(!0, a, e);
        }
        function ka(a, b, d, e) {
          if (c.isArray(b))
            c.each(b, function (b, f) {
              d || rb.test(a)
                ? e(a, f)
                : ka(
                    a +
                      "[" +
                      ("object" === typeof f || c.isArray(f) ? b : "") +
                      "]",
                    f,
                    d,
                    e
                  );
            });
          else if (d || null == b || "object" !== typeof b) e(a, b);
          else for (var f in b) ka(a + "[" + f + "]", b[f], d, e);
        }
        function Ha() {
          try {
            return new r.XMLHttpRequest();
          } catch (a) {}
        }
        function Ia() {
          setTimeout(sb, 0);
          return (aa = c.now());
        }
        function sb() {
          aa = p;
        }
        function O(a, b) {
          var d = {};
          c.each(Ja.concat.apply([], Ja.slice(0, b)), function () {
            d[this] = a;
          });
          return d;
        }
        function Ka(a) {
          if (!la[a]) {
            var b = q.body,
              d = c("\x3c" + a + "\x3e").appendTo(b),
              e = d.css("display");
            d.remove();
            if ("none" === e || "" === e)
              F ||
                ((F = q.createElement("iframe")),
                (F.frameBorder = F.width = F.height = 0)),
                b.appendChild(F),
                (J && F.createElement) ||
                  ((J = (F.contentWindow || F.contentDocument).document),
                  J.write(
                    (c.support.boxModel ? "\x3c!doctype html\x3e" : "") +
                      "\x3chtml\x3e\x3cbody\x3e"
                  ),
                  J.close()),
                (d = J.createElement(a)),
                J.body.appendChild(d),
                (e = c.css(d, "display")),
                b.removeChild(F);
            la[a] = e;
          }
          return la[a];
        }
        function ma(a) {
          return c.isWindow(a)
            ? a
            : 9 === a.nodeType
            ? a.defaultView || a.parentWindow
            : !1;
        }
        var q = r.document,
          tb = r.navigator,
          ub = r.location,
          c = (function () {
            function a() {
              if (!b.isReady) {
                try {
                  q.documentElement.doScroll("left");
                } catch (gc) {
                  setTimeout(a, 1);
                  return;
                }
                b.ready();
              }
            }
            var b = function (a, c) {
                return new b.fn.init(a, c, vb);
              },
              c = r.jQuery,
              e = r.$,
              f = /^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/,
              g = /\S/,
              h = /^\s+/,
              k = /\s+$/,
              l = /\d/,
              m = /^<(\w+)\s*\/?>(?:<\/\1>)?$/,
              n = /^[\],:{}\s]*$/,
              T = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,
              z =
                /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,
              G = /(?:^|:|,)(?:\s*\[)+/g,
              x = /(webkit)[ \/]([\w.]+)/,
              E = /(opera)(?:.*version)?[ \/]([\w.]+)/,
              w = /(msie) ([\w.]+)/,
              v = /(mozilla)(?:.*? rv:([\w.]+))?/,
              t = /-([a-z]|[0-9])/gi,
              y = /^-ms-/,
              A = function (a, b) {
                return (b + "").toUpperCase();
              },
              u = tb.userAgent,
              Q,
              K,
              wb = Object.prototype.toString,
              ba = Object.prototype.hasOwnProperty,
              na = Array.prototype.push,
              V = Array.prototype.slice,
              La = String.prototype.trim,
              Ma = Array.prototype.indexOf,
              B = {};
            b.fn = b.prototype = {
              constructor: b,
              init: function (a, c, d) {
                if (!a) return this;
                if (a.nodeType)
                  return (this.context = this[0] = a), (this.length = 1), this;
                if ("body" === a && !c && q.body)
                  return (
                    (this.context = q),
                    (this[0] = q.body),
                    (this.selector = a),
                    (this.length = 1),
                    this
                  );
                if ("string" === typeof a) {
                  var e =
                    "\x3c" === a.charAt(0) &&
                    "\x3e" === a.charAt(a.length - 1) &&
                    3 <= a.length
                      ? [null, a, null]
                      : f.exec(a);
                  if (!e || (!e[1] && c))
                    return !c || c.jquery
                      ? (c || d).find(a)
                      : this.constructor(c).find(a);
                  if (e[1])
                    return (
                      (d = (c = c instanceof b ? c[0] : c)
                        ? c.ownerDocument || c
                        : q),
                      (a = m.exec(a))
                        ? b.isPlainObject(c)
                          ? ((a = [q.createElement(a[1])]),
                            b.fn.attr.call(a, c, !0))
                          : (a = [d.createElement(a[1])])
                        : ((a = b.buildFragment([e[1]], [d])),
                          (a = (a.cacheable ? b.clone(a.fragment) : a.fragment)
                            .childNodes)),
                      b.merge(this, a)
                    );
                  if ((c = q.getElementById(e[2])) && c.parentNode) {
                    if (c.id !== e[2]) return d.find(a);
                    this.length = 1;
                    this[0] = c;
                  }
                  this.context = q;
                  this.selector = a;
                  return this;
                }
                if (b.isFunction(a)) return d.ready(a);
                a.selector !== p &&
                  ((this.selector = a.selector), (this.context = a.context));
                return b.makeArray(a, this);
              },
              selector: "",
              jquery: "1.6.4",
              length: 0,
              size: function () {
                return this.length;
              },
              toArray: function () {
                return V.call(this, 0);
              },
              get: function (a) {
                return null == a
                  ? this.toArray()
                  : 0 > a
                  ? this[this.length + a]
                  : this[a];
              },
              pushStack: function (a, c, d) {
                var e = this.constructor();
                b.isArray(a) ? na.apply(e, a) : b.merge(e, a);
                e.prevObject = this;
                e.context = this.context;
                "find" === c
                  ? (e.selector =
                      this.selector + (this.selector ? " " : "") + d)
                  : c && (e.selector = this.selector + "." + c + "(" + d + ")");
                return e;
              },
              each: function (a, c) {
                return b.each(this, a, c);
              },
              ready: function (a) {
                b.bindReady();
                Q.done(a);
                return this;
              },
              eq: function (a) {
                return -1 === a ? this.slice(a) : this.slice(a, +a + 1);
              },
              first: function () {
                return this.eq(0);
              },
              last: function () {
                return this.eq(-1);
              },
              slice: function () {
                return this.pushStack(
                  V.apply(this, arguments),
                  "slice",
                  V.call(arguments).join(",")
                );
              },
              map: function (a) {
                return this.pushStack(
                  b.map(this, function (b, c) {
                    return a.call(b, c, b);
                  })
                );
              },
              end: function () {
                return this.prevObject || this.constructor(null);
              },
              push: na,
              sort: [].sort,
              splice: [].splice,
            };
            b.fn.init.prototype = b.fn;
            b.extend = b.fn.extend = function () {
              var a,
                c,
                d,
                e = arguments[0] || {},
                f = 1,
                g = arguments.length,
                t = !1;
              "boolean" === typeof e &&
                ((t = e), (e = arguments[1] || {}), (f = 2));
              "object" === typeof e || b.isFunction(e) || (e = {});
              g === f && ((e = this), --f);
              for (; f < g; f++)
                if (null != (a = arguments[f]))
                  for (c in a) {
                    var h = e[c];
                    var y = a[c];
                    "__proto__" !== c &&
                      e !== y &&
                      (t && y && (b.isPlainObject(y) || (d = b.isArray(y)))
                        ? (d
                            ? ((d = !1), (h = h && b.isArray(h) ? h : []))
                            : (h = h && b.isPlainObject(h) ? h : {}),
                          (e[c] = b.extend(t, h, y)))
                        : y !== p && (e[c] = y));
                  }
              return e;
            };
            b.extend({
              noConflict: function (a) {
                r.$ === b && (r.$ = e);
                a && r.jQuery === b && (r.jQuery = c);
                return b;
              },
              isReady: !1,
              readyWait: 1,
              holdReady: function (a) {
                a ? b.readyWait++ : b.ready(!0);
              },
              ready: function (a) {
                if ((!0 === a && !--b.readyWait) || (!0 !== a && !b.isReady)) {
                  if (!q.body) return setTimeout(b.ready, 1);
                  b.isReady = !0;
                  (!0 !== a && 0 < --b.readyWait) ||
                    (Q.resolveWith(q, [b]),
                    b.fn.trigger && b(q).trigger("ready").unbind("ready"));
                }
              },
              bindReady: function () {
                if (!Q) {
                  Q = b._Deferred();
                  if ("complete" === q.readyState)
                    return setTimeout(b.ready, 1);
                  if (q.addEventListener)
                    q.addEventListener("DOMContentLoaded", K, !1),
                      r.addEventListener("load", b.ready, !1);
                  else if (q.attachEvent) {
                    q.attachEvent("onreadystatechange", K);
                    r.attachEvent("onload", b.ready);
                    var c = !1;
                    try {
                      c = null == r.frameElement;
                    } catch (hc) {}
                    q.documentElement.doScroll && c && a();
                  }
                }
              },
              isFunction: function (a) {
                return "function" === b.type(a);
              },
              isArray:
                Array.isArray ||
                function (a) {
                  return "array" === b.type(a);
                },
              isWindow: function (a) {
                return a && "object" === typeof a && "setInterval" in a;
              },
              isNaN: function (a) {
                return null == a || !l.test(a) || isNaN(a);
              },
              type: function (a) {
                return null == a ? String(a) : B[wb.call(a)] || "object";
              },
              isPlainObject: function (a) {
                if (!a || "object" !== b.type(a) || a.nodeType || b.isWindow(a))
                  return !1;
                try {
                  if (
                    a.constructor &&
                    !ba.call(a, "constructor") &&
                    !ba.call(a.constructor.prototype, "isPrototypeOf")
                  )
                    return !1;
                } catch (ic) {
                  return !1;
                }
                for (var c in a);
                return c === p || ba.call(a, c);
              },
              isEmptyObject: function (a) {
                for (var b in a) return !1;
                return !0;
              },
              error: function (a) {
                throw a;
              },
              parseJSON: function (a) {
                if ("string" !== typeof a || !a) return null;
                a = b.trim(a);
                if (r.JSON && r.JSON.parse) return r.JSON.parse(a);
                if (n.test(a.replace(T, "@").replace(z, "]").replace(G, "")))
                  return new Function("return " + a)();
                b.error("Invalid JSON: " + a);
              },
              parseXML: function (a) {
                try {
                  if (r.DOMParser) {
                    var c = new DOMParser();
                    var d = c.parseFromString(a, "text/xml");
                  } else
                    (d = new ActiveXObject("Microsoft.XMLDOM")),
                      (d.async = "false"),
                      d.loadXML(a);
                } catch (D) {
                  d = p;
                }
                (d &&
                  d.documentElement &&
                  !d.getElementsByTagName("parsererror").length) ||
                  b.error("Invalid XML: " + a);
                return d;
              },
              noop: function () {},
              globalEval: function (a) {
                a &&
                  g.test(a) &&
                  (
                    r.execScript ||
                    function (a) {
                      r.eval.call(r, a);
                    }
                  )(a);
              },
              camelCase: function (a) {
                return a.replace(y, "ms-").replace(t, A);
              },
              nodeName: function (a, b) {
                return (
                  a.nodeName && a.nodeName.toUpperCase() === b.toUpperCase()
                );
              },
              each: function (a, c, d) {
                var e,
                  f = 0,
                  g = a.length,
                  t = g === p || b.isFunction(a);
                if (d)
                  if (t)
                    for (e in a) {
                      if (!1 === c.apply(a[e], d)) break;
                    }
                  else for (; f < g && !1 !== c.apply(a[f++], d); );
                else if (t)
                  for (e in a) {
                    if (!1 === c.call(a[e], e, a[e])) break;
                  }
                else for (; f < g && !1 !== c.call(a[f], f, a[f++]); );
                return a;
              },
              trim: La
                ? function (a) {
                    return null == a ? "" : La.call(a);
                  }
                : function (a) {
                    return null == a
                      ? ""
                      : a.toString().replace(h, "").replace(k, "");
                  },
              makeArray: function (a, c) {
                c = c || [];
                if (null != a) {
                  var d = b.type(a);
                  null == a.length ||
                  "string" === d ||
                  "function" === d ||
                  "regexp" === d ||
                  b.isWindow(a)
                    ? na.call(c, a)
                    : b.merge(c, a);
                }
                return c;
              },
              inArray: function (a, b) {
                if (!b) return -1;
                if (Ma) return Ma.call(b, a);
                for (var c = 0, d = b.length; c < d; c++)
                  if (b[c] === a) return c;
                return -1;
              },
              merge: function (a, b) {
                var c = a.length,
                  d = 0;
                if ("number" === typeof b.length)
                  for (var e = b.length; d < e; d++) a[c++] = b[d];
                else for (; b[d] !== p; ) a[c++] = b[d++];
                a.length = c;
                return a;
              },
              grep: function (a, b, c) {
                var d = [];
                c = !!c;
                for (var e = 0, f = a.length; e < f; e++) {
                  var g = !!b(a[e], e);
                  c !== g && d.push(a[e]);
                }
                return d;
              },
              map: function (a, c, d) {
                var e,
                  f = [],
                  g = 0,
                  t = a.length;
                if (
                  a instanceof b ||
                  (t !== p &&
                    "number" === typeof t &&
                    ((0 < t && a[0] && a[t - 1]) || 0 === t || b.isArray(a)))
                )
                  for (; g < t; g++) {
                    var h = c(a[g], g, d);
                    null != h && (f[f.length] = h);
                  }
                else
                  for (e in a)
                    (h = c(a[e], e, d)), null != h && (f[f.length] = h);
                return f.concat.apply([], f);
              },
              guid: 1,
              proxy: function (a, c) {
                if ("string" === typeof c) {
                  var d = a[c];
                  c = a;
                  a = d;
                }
                if (!b.isFunction(a)) return p;
                var e = V.call(arguments, 2);
                d = function () {
                  return a.apply(c, e.concat(V.call(arguments)));
                };
                d.guid = a.guid = a.guid || d.guid || b.guid++;
                return d;
              },
              access: function (a, c, d, e, f, g) {
                var t = a.length;
                if ("object" === typeof c) {
                  for (var h in c) b.access(a, h, c[h], e, f, d);
                  return a;
                }
                if (d !== p) {
                  e = !g && e && b.isFunction(d);
                  for (h = 0; h < t; h++)
                    f(a[h], c, e ? d.call(a[h], h, f(a[h], c)) : d, g);
                  return a;
                }
                return t ? f(a[0], c) : p;
              },
              now: function () {
                return new Date().getTime();
              },
              uaMatch: function (a) {
                a = a.toLowerCase();
                a =
                  x.exec(a) ||
                  E.exec(a) ||
                  w.exec(a) ||
                  (0 > a.indexOf("compatible") && v.exec(a)) ||
                  [];
                return {browser: a[1] || "", version: a[2] || "0"};
              },
              sub: function () {
                function a(b, c) {
                  return new a.fn.init(b, c);
                }
                b.extend(!0, a, this);
                a.superclass = this;
                a.fn = a.prototype = this();
                a.fn.constructor = a;
                a.sub = this.sub;
                a.fn.init = function (d, e) {
                  e && e instanceof b && !(e instanceof a) && (e = a(e));
                  return b.fn.init.call(this, d, e, c);
                };
                a.fn.init.prototype = a.fn;
                var c = a(q);
                return a;
              },
              browser: {},
            });
            b.each(
              "Boolean Number String Function Array Date RegExp Object".split(
                " "
              ),
              function (a, b) {
                B["[object " + b + "]"] = b.toLowerCase();
              }
            );
            u = b.uaMatch(u);
            u.browser &&
              ((b.browser[u.browser] = !0), (b.browser.version = u.version));
            b.browser.webkit && (b.browser.safari = !0);
            g.test(" ") && ((h = /^[\s\xA0]+/), (k = /[\s\xA0]+$/));
            var vb = b(q);
            q.addEventListener
              ? (K = function () {
                  q.removeEventListener("DOMContentLoaded", K, !1);
                  b.ready();
                })
              : q.attachEvent &&
                (K = function () {
                  "complete" === q.readyState &&
                    (q.detachEvent("onreadystatechange", K), b.ready());
                });
            return b;
          })(),
          oa = "done fail isResolved isRejected promise then always pipe".split(
            " "
          ),
          Na = [].slice;
        c.extend({
          _Deferred: function () {
            var a = [],
              b,
              d,
              e,
              f = {
                done: function () {
                  if (!e) {
                    var d = arguments,
                      h;
                    if (b) {
                      var k = b;
                      b = 0;
                    }
                    var l = 0;
                    for (h = d.length; l < h; l++) {
                      var m = d[l];
                      var n = c.type(m);
                      "array" === n
                        ? f.done.apply(f, m)
                        : "function" === n && a.push(m);
                    }
                    k && f.resolveWith(k[0], k[1]);
                  }
                  return this;
                },
                resolveWith: function (c, f) {
                  if (!e && !b && !d) {
                    f = f || [];
                    d = 1;
                    try {
                      for (; a[0]; ) a.shift().apply(c, f);
                    } finally {
                      (b = [c, f]), (d = 0);
                    }
                  }
                  return this;
                },
                resolve: function () {
                  f.resolveWith(this, arguments);
                  return this;
                },
                isResolved: function () {
                  return !(!d && !b);
                },
                cancel: function () {
                  e = 1;
                  a = [];
                  return this;
                },
              };
            return f;
          },
          Deferred: function (a) {
            var b = c._Deferred(),
              d = c._Deferred(),
              e;
            c.extend(b, {
              then: function (a, c) {
                b.done(a).fail(c);
                return this;
              },
              always: function () {
                return b.done.apply(b, arguments).fail.apply(this, arguments);
              },
              fail: d.done,
              rejectWith: d.resolveWith,
              reject: d.resolve,
              isRejected: d.isResolved,
              pipe: function (a, d) {
                return c
                  .Deferred(function (e) {
                    c.each(
                      {done: [a, "resolve"], fail: [d, "reject"]},
                      function (a, d) {
                        var f = d[0],
                          g = d[1],
                          h;
                        if (c.isFunction(f))
                          b[a](function () {
                            if (
                              (h = f.apply(this, arguments)) &&
                              c.isFunction(h.promise)
                            )
                              h.promise().then(e.resolve, e.reject);
                            else e[g + "With"](this === b ? e : this, [h]);
                          });
                        else b[a](e[g]);
                      }
                    );
                  })
                  .promise();
              },
              promise: function (a) {
                if (null == a) {
                  if (e) return e;
                  e = a = {};
                }
                for (var c = oa.length; c--; ) a[oa[c]] = b[oa[c]];
                return a;
              },
            });
            b.done(d.cancel).fail(b.cancel);
            delete b.cancel;
            a && a.call(b, b);
            return b;
          },
          when: function (a) {
            function b(a) {
              return function (b) {
                d[a] = 1 < arguments.length ? Na.call(arguments, 0) : b;
                --g || h.resolveWith(h, Na.call(d, 0));
              };
            }
            var d = arguments,
              e = 0,
              f = d.length,
              g = f,
              h = 1 >= f && a && c.isFunction(a.promise) ? a : c.Deferred();
            if (1 < f) {
              for (; e < f; e++)
                d[e] && c.isFunction(d[e].promise)
                  ? d[e].promise().then(b(e), h.reject)
                  : --g;
              g || h.resolveWith(h, d);
            } else h !== a && h.resolveWith(h, f ? [a] : []);
            return h.promise();
          },
        });
        c.support = (function () {
          var a = q.createElement("div"),
            b = q.documentElement,
            d;
          a.setAttribute("className", "t");
          a.innerHTML =
            "   \x3clink/\x3e\x3ctable\x3e\x3c/table\x3e\x3ca href\x3d'/a' style\x3d'top:1px;float:left;opacity:.55;'\x3ea\x3c/a\x3e\x3cinput type\x3d'checkbox'/\x3e";
          var e = a.getElementsByTagName("*");
          var f = a.getElementsByTagName("a")[0];
          if (!e || !e.length || !f) return {};
          var g = q.createElement("select");
          var h = g.appendChild(q.createElement("option"));
          e = a.getElementsByTagName("input")[0];
          var k = {
            leadingWhitespace: 3 === a.firstChild.nodeType,
            tbody: !a.getElementsByTagName("tbody").length,
            htmlSerialize: !!a.getElementsByTagName("link").length,
            style: /top/.test(f.getAttribute("style")),
            hrefNormalized: "/a" === f.getAttribute("href"),
            opacity: /^0.55$/.test(f.style.opacity),
            cssFloat: !!f.style.cssFloat,
            checkOn: "on" === e.value,
            optSelected: h.selected,
            getSetAttribute: "t" !== a.className,
            submitBubbles: !0,
            changeBubbles: !0,
            focusinBubbles: !1,
            deleteExpando: !0,
            noCloneEvent: !0,
            inlineBlockNeedsLayout: !1,
            shrinkWrapBlocks: !1,
            reliableMarginRight: !0,
          };
          e.checked = !0;
          k.noCloneChecked = e.cloneNode(!0).checked;
          g.disabled = !0;
          k.optDisabled = !h.disabled;
          try {
            delete a.test;
          } catch (l) {
            k.deleteExpando = !1;
          }
          !a.addEventListener &&
            a.attachEvent &&
            a.fireEvent &&
            (a.attachEvent("onclick", function () {
              k.noCloneEvent = !1;
            }),
            a.cloneNode(!0).fireEvent("onclick"));
          e = q.createElement("input");
          e.value = "t";
          e.setAttribute("type", "radio");
          k.radioValue = "t" === e.value;
          e.setAttribute("checked", "checked");
          a.appendChild(e);
          f = q.createDocumentFragment();
          f.appendChild(a.firstChild);
          k.checkClone = f.cloneNode(!0).cloneNode(!0).lastChild.checked;
          a.innerHTML = "";
          a.style.width = a.style.paddingLeft = "1px";
          g = q.getElementsByTagName("body")[0];
          f = q.createElement(g ? "div" : "body");
          h = {
            visibility: "hidden",
            width: 0,
            height: 0,
            border: 0,
            margin: 0,
            background: "none",
          };
          g &&
            c.extend(h, {
              position: "absolute",
              left: "-1000px",
              top: "-1000px",
            });
          for (d in h) f.style[d] = h[d];
          f.appendChild(a);
          b = g || b;
          b.insertBefore(f, b.firstChild);
          k.appendChecked = e.checked;
          c.boxModel = k.boxModel = "CSS1Compat" === q.compatMode;
          "zoom" in a.style &&
            ((a.style.display = "inline"),
            (a.style.zoom = 1),
            (k.inlineBlockNeedsLayout = 2 === a.offsetWidth),
            (a.style.display = ""),
            (a.innerHTML = "\x3cdiv style\x3d'width:4px;'\x3e\x3c/div\x3e"),
            (k.shrinkWrapBlocks = 2 !== a.offsetWidth));
          a.innerHTML =
            "\x3ctable\x3e\x3ctr\x3e\x3ctd style\x3d'padding:0;border:0;display:none'\x3e\x3c/td\x3e\x3ctd\x3et\x3c/td\x3e\x3c/tr\x3e\x3c/table\x3e";
          g = a.getElementsByTagName("td");
          e = 0 === g[0].offsetHeight;
          g[0].style.display = "";
          g[1].style.display = "none";
          k.reliableHiddenOffsets = e && 0 === g[0].offsetHeight;
          a.innerHTML = "";
          q.defaultView &&
            q.defaultView.getComputedStyle &&
            ((e = q.createElement("div")),
            (e.style.width = "0"),
            (e.style.marginRight = "0"),
            a.appendChild(e),
            (k.reliableMarginRight =
              0 ===
              (parseInt(
                (q.defaultView.getComputedStyle(e, null) || {marginRight: 0})
                  .marginRight,
                10
              ) || 0)));
          f.innerHTML = "";
          b.removeChild(f);
          if (a.attachEvent)
            for (d in {submit: 1, change: 1, focusin: 1})
              (b = "on" + d),
                (e = b in a),
                e ||
                  (a.setAttribute(b, "return;"),
                  (e = "function" === typeof a[b])),
                (k[d + "Bubbles"] = e);
          f = f = g = h = g = e = a = e = null;
          return k;
        })();
        var hb = /^(?:\{.*\}|\[.*\])$/,
          gb = /([A-Z])/g;
        c.extend({
          cache: {},
          uuid: 0,
          expando: "jQuery" + (c.fn.jquery + Math.random()).replace(/\D/g, ""),
          noData: {
            embed: !0,
            object: "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",
            applet: !0,
          },
          hasData: function (a) {
            a = a.nodeType ? c.cache[a[c.expando]] : a[c.expando];
            return !!a && !ha(a);
          },
          data: function (a, b, d, e) {
            if (c.acceptData(a)) {
              var f = c.expando,
                g = "string" === typeof b,
                h = a.nodeType,
                k = h ? c.cache : a,
                l = h ? a[c.expando] : a[c.expando] && c.expando;
              if (!(!l || (e && l && k[l] && !k[l][f])) || !g || d !== p) {
                l || (h ? (a[c.expando] = l = ++c.uuid) : (l = c.expando));
                k[l] || ((k[l] = {}), h || (k[l].toJSON = c.noop));
                if ("object" === typeof b || "function" === typeof b)
                  e
                    ? (k[l][f] = c.extend(k[l][f], b))
                    : (k[l] = c.extend(k[l], b));
                a = k[l];
                e && (a[f] || (a[f] = {}), (a = a[f]));
                d !== p && (a[c.camelCase(b)] = d);
                if ("events" === b && !a[b]) return a[f] && a[f].events;
                g
                  ? ((d = a[b]), null == d && (d = a[c.camelCase(b)]))
                  : (d = a);
                return d;
              }
            }
          },
          removeData: function (a, b, d) {
            if (c.acceptData(a)) {
              var e,
                f = c.expando,
                g = a.nodeType,
                h = g ? c.cache : a,
                k = g ? a[c.expando] : c.expando;
              if (h[k]) {
                if (
                  (b &&
                    (e = d ? h[k][f] : h[k]) &&
                    (e[b] || (b = c.camelCase(b)), delete e[b], !ha(e))) ||
                  (d && (delete h[k][f], !ha(h[k])))
                )
                  return;
                b = h[k][f];
                c.support.deleteExpando || !h.setInterval
                  ? delete h[k]
                  : (h[k] = null);
                b
                  ? ((h[k] = {}), g || (h[k].toJSON = c.noop), (h[k][f] = b))
                  : g &&
                    (c.support.deleteExpando
                      ? delete a[c.expando]
                      : a.removeAttribute
                      ? a.removeAttribute(c.expando)
                      : (a[c.expando] = null));
              }
            }
          },
          _data: function (a, b, d) {
            return c.data(a, b, d, !0);
          },
          acceptData: function (a) {
            if (a.nodeName) {
              var b = c.noData[a.nodeName.toLowerCase()];
              if (b) return !(!0 === b || a.getAttribute("classid") !== b);
            }
            return !0;
          },
        });
        c.fn.extend({
          data: function (a, b) {
            var d = null;
            if ("undefined" === typeof a) {
              if (
                this.length &&
                ((d = c.data(this[0])), 1 === this[0].nodeType)
              )
                for (
                  var e = this[0].attributes, f, g = 0, h = e.length;
                  g < h;
                  g++
                )
                  (f = e[g].name),
                    0 === f.indexOf("data-") &&
                      ((f = c.camelCase(f.substring(5))), C(this[0], f, d[f]));
              return d;
            }
            if ("object" === typeof a)
              return this.each(function () {
                c.data(this, a);
              });
            var k = a.split(".");
            k[1] = k[1] ? "." + k[1] : "";
            return b === p
              ? ((d = this.triggerHandler("getData" + k[1] + "!", [k[0]])),
                d === p &&
                  this.length &&
                  ((d = c.data(this[0], a)), (d = C(this[0], a, d))),
                d === p && k[1] ? this.data(k[0]) : d)
              : this.each(function () {
                  var d = c(this),
                    e = [k[0], b];
                  d.triggerHandler("setData" + k[1] + "!", e);
                  c.data(this, a, b);
                  d.triggerHandler("changeData" + k[1] + "!", e);
                });
          },
          removeData: function (a) {
            return this.each(function () {
              c.removeData(this, a);
            });
          },
        });
        c.extend({
          _mark: function (a, b) {
            a &&
              ((b = (b || "fx") + "mark"),
              c.data(a, b, (c.data(a, b, p, !0) || 0) + 1, !0));
          },
          _unmark: function (a, b, d) {
            !0 !== a && ((d = b), (b = a), (a = !1));
            if (b) {
              d = d || "fx";
              var e = d + "mark";
              (a = a ? 0 : (c.data(b, e, p, !0) || 1) - 1)
                ? c.data(b, e, a, !0)
                : (c.removeData(b, e, !0), va(b, d, "mark"));
            }
          },
          queue: function (a, b, d) {
            if (a) {
              b = (b || "fx") + "queue";
              var e = c.data(a, b, p, !0);
              d &&
                (!e || c.isArray(d)
                  ? (e = c.data(a, b, c.makeArray(d), !0))
                  : e.push(d));
              return e || [];
            }
          },
          dequeue: function (a, b) {
            b = b || "fx";
            var d = c.queue(a, b),
              e = d.shift();
            "inprogress" === e && (e = d.shift());
            e &&
              ("fx" === b && d.unshift("inprogress"),
              e.call(a, function () {
                c.dequeue(a, b);
              }));
            d.length || (c.removeData(a, b + "queue", !0), va(a, b, "queue"));
          },
        });
        c.fn.extend({
          queue: function (a, b) {
            "string" !== typeof a && ((b = a), (a = "fx"));
            return b === p
              ? c.queue(this[0], a)
              : this.each(function () {
                  var d = c.queue(this, a, b);
                  "fx" === a && "inprogress" !== d[0] && c.dequeue(this, a);
                });
          },
          dequeue: function (a) {
            return this.each(function () {
              c.dequeue(this, a);
            });
          },
          delay: function (a, b) {
            a = c.fx ? c.fx.speeds[a] || a : a;
            b = b || "fx";
            return this.queue(b, function () {
              var d = this;
              setTimeout(function () {
                c.dequeue(d, b);
              }, a);
            });
          },
          clearQueue: function (a) {
            return this.queue(a || "fx", []);
          },
          promise: function (a, b) {
            function d() {
              --g || e.resolveWith(f, [f]);
            }
            "string" !== typeof a && (a = p);
            a = a || "fx";
            var e = c.Deferred(),
              f = this;
            b = f.length;
            var g = 1,
              h = a + "defer",
              k = a + "queue";
            a += "mark";
            for (var l; b--; )
              if (
                (l =
                  c.data(f[b], h, p, !0) ||
                  ((c.data(f[b], k, p, !0) || c.data(f[b], a, p, !0)) &&
                    c.data(f[b], h, c._Deferred(), !0)))
              )
                g++, l.done(d);
            d();
            return e.promise();
          },
        });
        var Oa = /[\n\t\r]/g,
          pa = /\s+/,
          xb = /\r/g,
          yb = /^(?:button|input)$/i,
          zb = /^(?:button|input|object|select|textarea)$/i,
          Ab = /^a(?:rea)?$/i,
          Pa =
            /^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i;
        c.fn.extend({
          attr: function (a, b) {
            return c.access(this, a, b, !0, c.attr);
          },
          removeAttr: function (a) {
            return this.each(function () {
              c.removeAttr(this, a);
            });
          },
          prop: function (a, b) {
            return c.access(this, a, b, !0, c.prop);
          },
          removeProp: function (a) {
            a = c.propFix[a] || a;
            return this.each(function () {
              try {
                (this[a] = p), delete this[a];
              } catch (b) {}
            });
          },
          addClass: function (a) {
            var b, d;
            if (c.isFunction(a))
              return this.each(function (b) {
                c(this).addClass(a.call(this, b, this.className));
              });
            if (a && "string" === typeof a) {
              var e = a.split(pa);
              var f = 0;
              for (b = this.length; f < b; f++) {
                var g = this[f];
                if (1 === g.nodeType)
                  if (g.className || 1 !== e.length) {
                    var h = " " + g.className + " ";
                    var k = 0;
                    for (d = e.length; k < d; k++)
                      ~h.indexOf(" " + e[k] + " ") || (h += e[k] + " ");
                    g.className = c.trim(h);
                  } else g.className = a;
              }
            }
            return this;
          },
          removeClass: function (a) {
            var b, d;
            if (c.isFunction(a))
              return this.each(function (b) {
                c(this).removeClass(a.call(this, b, this.className));
              });
            if ((a && "string" === typeof a) || a === p) {
              var e = (a || "").split(pa);
              var f = 0;
              for (b = this.length; f < b; f++) {
                var g = this[f];
                if (1 === g.nodeType && g.className)
                  if (a) {
                    var h = (" " + g.className + " ").replace(Oa, " ");
                    var k = 0;
                    for (d = e.length; k < d; k++)
                      h = h.replace(" " + e[k] + " ", " ");
                    g.className = c.trim(h);
                  } else g.className = "";
              }
            }
            return this;
          },
          toggleClass: function (a, b) {
            var d = typeof a,
              e = "boolean" === typeof b;
            return c.isFunction(a)
              ? this.each(function (d) {
                  c(this).toggleClass(a.call(this, d, this.className, b), b);
                })
              : this.each(function () {
                  if ("string" === d)
                    for (
                      var f, g = 0, h = c(this), k = b, l = a.split(pa);
                      (f = l[g++]);

                    )
                      (k = e ? k : !h.hasClass(f)),
                        h[k ? "addClass" : "removeClass"](f);
                  else if ("undefined" === d || "boolean" === d)
                    this.className &&
                      c._data(this, "__className__", this.className),
                      (this.className =
                        this.className || !1 === a
                          ? ""
                          : c._data(this, "__className__") || "");
                });
          },
          hasClass: function (a) {
            a = " " + a + " ";
            for (var b = 0, c = this.length; b < c; b++)
              if (
                1 === this[b].nodeType &&
                -1 < (" " + this[b].className + " ").replace(Oa, " ").indexOf(a)
              )
                return !0;
            return !1;
          },
          val: function (a) {
            var b,
              d,
              e = this[0];
            if (!arguments.length) {
              if (e) {
                if (
                  (b =
                    c.valHooks[e.nodeName.toLowerCase()] ||
                    c.valHooks[e.type]) &&
                  "get" in b &&
                  (d = b.get(e, "value")) !== p
                )
                  return d;
                d = e.value;
                return "string" === typeof d
                  ? d.replace(xb, "")
                  : null == d
                  ? ""
                  : d;
              }
              return p;
            }
            var f = c.isFunction(a);
            return this.each(function (d) {
              var e = c(this);
              1 === this.nodeType &&
                ((d = f ? a.call(this, d, e.val()) : a),
                null == d
                  ? (d = "")
                  : "number" === typeof d
                  ? (d += "")
                  : c.isArray(d) &&
                    (d = c.map(d, function (a) {
                      return null == a ? "" : a + "";
                    })),
                (b =
                  c.valHooks[this.nodeName.toLowerCase()] ||
                  c.valHooks[this.type]),
                (b && "set" in b && b.set(this, d, "value") !== p) ||
                  (this.value = d));
            });
          },
        });
        c.extend({
          valHooks: {
            option: {
              get: function (a) {
                var b = a.attributes.value;
                return !b || b.specified ? a.value : a.text;
              },
            },
            select: {
              get: function (a) {
                var b = a.selectedIndex,
                  d = [],
                  e = a.options;
                a = "select-one" === a.type;
                if (0 > b) return null;
                for (var f = a ? b : 0, g = a ? b + 1 : e.length; f < g; f++) {
                  var h = e[f];
                  if (
                    !(
                      !h.selected ||
                      (c.support.optDisabled
                        ? h.disabled
                        : null !== h.getAttribute("disabled")) ||
                      (h.parentNode.disabled &&
                        c.nodeName(h.parentNode, "optgroup"))
                    )
                  ) {
                    h = c(h).val();
                    if (a) return h;
                    d.push(h);
                  }
                }
                return a && !d.length && e.length ? c(e[b]).val() : d;
              },
              set: function (a, b) {
                var d = c.makeArray(b);
                c(a)
                  .find("option")
                  .each(function () {
                    this.selected = 0 <= c.inArray(c(this).val(), d);
                  });
                d.length || (a.selectedIndex = -1);
                return d;
              },
            },
          },
          attrFn: {
            val: !0,
            css: !0,
            html: !0,
            text: !0,
            data: !0,
            width: !0,
            height: !0,
            offset: !0,
          },
          attrFix: {tabindex: "tabIndex"},
          attr: function (a, b, d, e) {
            var f = a.nodeType;
            if (!a || 3 === f || 8 === f || 2 === f) return p;
            if (e && b in c.attrFn) return c(a)[b](d);
            if (!("getAttribute" in a)) return c.prop(a, b, d);
            var g, h;
            if ((e = 1 !== f || !c.isXMLDoc(a)))
              (b = c.attrFix[b] || b),
                (h = c.attrHooks[b]) || (Pa.test(b) ? (h = Bb) : L && (h = L));
            if (d !== p) {
              if (null === d) return c.removeAttr(a, b), p;
              if (h && "set" in h && e && (g = h.set(a, d, b)) !== p) return g;
              a.setAttribute(b, "" + d);
              return d;
            }
            if (h && "get" in h && e && null !== (g = h.get(a, b))) return g;
            g = a.getAttribute(b);
            return null === g ? p : g;
          },
          removeAttr: function (a, b) {
            var d;
            1 === a.nodeType &&
              ((b = c.attrFix[b] || b),
              c.attr(a, b, ""),
              a.removeAttribute(b),
              Pa.test(b) && (d = c.propFix[b] || b) in a && (a[d] = !1));
          },
          attrHooks: {
            type: {
              set: function (a, b) {
                if (yb.test(a.nodeName) && a.parentNode)
                  c.error("type property can't be changed");
                else if (
                  !c.support.radioValue &&
                  "radio" === b &&
                  c.nodeName(a, "input")
                ) {
                  var d = a.value;
                  a.setAttribute("type", b);
                  d && (a.value = d);
                  return b;
                }
              },
            },
            value: {
              get: function (a, b) {
                return L && c.nodeName(a, "button")
                  ? L.get(a, b)
                  : b in a
                  ? a.value
                  : null;
              },
              set: function (a, b, d) {
                if (L && c.nodeName(a, "button")) return L.set(a, b, d);
                a.value = b;
              },
            },
          },
          propFix: {
            tabindex: "tabIndex",
            readonly: "readOnly",
            for: "htmlFor",
            class: "className",
            maxlength: "maxLength",
            cellspacing: "cellSpacing",
            cellpadding: "cellPadding",
            rowspan: "rowSpan",
            colspan: "colSpan",
            usemap: "useMap",
            frameborder: "frameBorder",
            contenteditable: "contentEditable",
          },
          prop: function (a, b, d) {
            var e = a.nodeType;
            if (!a || 3 === e || 8 === e || 2 === e) return p;
            var f;
            if (1 !== e || !c.isXMLDoc(a)) {
              b = c.propFix[b] || b;
              var g = c.propHooks[b];
            }
            return d !== p
              ? g && "set" in g && (f = g.set(a, d, b)) !== p
                ? f
                : (a[b] = d)
              : g && "get" in g && null !== (f = g.get(a, b))
              ? f
              : a[b];
          },
          propHooks: {
            tabIndex: {
              get: function (a) {
                var b = a.getAttributeNode("tabindex");
                return b && b.specified
                  ? parseInt(b.value, 10)
                  : zb.test(a.nodeName) || (Ab.test(a.nodeName) && a.href)
                  ? 0
                  : p;
              },
            },
          },
        });
        c.attrHooks.tabIndex = c.propHooks.tabIndex;
        var Bb = {
          get: function (a, b) {
            var d;
            return !0 === c.prop(a, b) ||
              ((d = a.getAttributeNode(b)) && !1 !== d.nodeValue)
              ? b.toLowerCase()
              : p;
          },
          set: function (a, b, d) {
            !1 === b
              ? c.removeAttr(a, d)
              : ((b = c.propFix[d] || d),
                b in a && (a[b] = !0),
                a.setAttribute(d, d.toLowerCase()));
            return d;
          },
        };
        if (!c.support.getSetAttribute) {
          var L = (c.valHooks.button = {
            get: function (a, b) {
              return (a = a.getAttributeNode(b)) && "" !== a.nodeValue
                ? a.nodeValue
                : p;
            },
            set: function (a, b, c) {
              var d = a.getAttributeNode(c);
              d || ((d = q.createAttribute(c)), a.setAttributeNode(d));
              return (d.nodeValue = b + "");
            },
          });
          c.each(["width", "height"], function (a, b) {
            c.attrHooks[b] = c.extend(c.attrHooks[b], {
              set: function (a, c) {
                if ("" === c) return a.setAttribute(b, "auto"), c;
              },
            });
          });
        }
        c.support.hrefNormalized ||
          c.each(["href", "src", "width", "height"], function (a, b) {
            c.attrHooks[b] = c.extend(c.attrHooks[b], {
              get: function (a) {
                a = a.getAttribute(b, 2);
                return null === a ? p : a;
              },
            });
          });
        c.support.style ||
          (c.attrHooks.style = {
            get: function (a) {
              return a.style.cssText.toLowerCase() || p;
            },
            set: function (a, b) {
              return (a.style.cssText = "" + b);
            },
          });
        c.support.optSelected ||
          (c.propHooks.selected = c.extend(c.propHooks.selected, {
            get: function (a) {
              if ((a = a.parentNode))
                a.selectedIndex, a.parentNode && a.parentNode.selectedIndex;
              return null;
            },
          }));
        c.support.checkOn ||
          c.each(["radio", "checkbox"], function () {
            c.valHooks[this] = {
              get: function (a) {
                return null === a.getAttribute("value") ? "on" : a.value;
              },
            };
          });
        c.each(["radio", "checkbox"], function () {
          c.valHooks[this] = c.extend(c.valHooks[this], {
            set: function (a, b) {
              if (c.isArray(b))
                return (a.checked = 0 <= c.inArray(c(a).val(), b));
            },
          });
        });
        var ia = /\.(.*)$/,
          qa = /^(?:textarea|input|select)$/i,
          jb = /\./g,
          kb = / /g,
          Cb = /[^\w\s.|`]/g,
          Db = function (a) {
            return a.replace(Cb, "\\$\x26");
          };
        c.event = {
          add: function (a, b, d, e) {
            if (3 !== a.nodeType && 8 !== a.nodeType) {
              if (!1 === d) d = H;
              else if (!d) return;
              var f;
              if (d.handler) {
                var g = d;
                d = g.handler;
              }
              d.guid || (d.guid = c.guid++);
              if ((f = c._data(a))) {
                var h = f.events,
                  k = f.handle;
                h || (f.events = h = {});
                k ||
                  (f.handle = k =
                    function (a) {
                      return "undefined" === typeof c ||
                        (a && c.event.triggered === a.type)
                        ? p
                        : c.event.handle.apply(k.elem, arguments);
                    });
                k.elem = a;
                b = b.split(" ");
                for (var l, m = 0, n; (l = b[m++]); ) {
                  f = g ? c.extend({}, g) : {handler: d, data: e};
                  -1 < l.indexOf(".")
                    ? ((n = l.split(".")),
                      (l = n.shift()),
                      (f.namespace = n.slice(0).sort().join(".")))
                    : ((n = []), (f.namespace = ""));
                  f.type = l;
                  f.guid || (f.guid = d.guid);
                  var q = h[l],
                    r = c.event.special[l] || {};
                  q ||
                    ((q = h[l] = []),
                    (r.setup && !1 !== r.setup.call(a, e, n, k)) ||
                      (a.addEventListener
                        ? a.addEventListener(l, k, !1)
                        : a.attachEvent && a.attachEvent("on" + l, k)));
                  r.add &&
                    (r.add.call(a, f),
                    f.handler.guid || (f.handler.guid = d.guid));
                  q.push(f);
                  c.event.global[l] = !0;
                }
                a = null;
              }
            }
          },
          global: {},
          remove: function (a, b, d, e) {
            if (3 !== a.nodeType && 8 !== a.nodeType) {
              !1 === d && (d = H);
              var f,
                g,
                h = 0,
                k,
                l = c.hasData(a) && c._data(a),
                m = l && l.events;
              if (l && m)
                if (
                  (b && b.type && ((d = b.handler), (b = b.type)),
                  !b || ("string" === typeof b && "." === b.charAt(0)))
                )
                  for (f in ((b = b || ""), m)) c.event.remove(a, f + b);
                else {
                  for (b = b.split(" "); (f = b[h++]); ) {
                    var n = f;
                    var q = 0 > f.indexOf(".");
                    var r = [];
                    if (!q) {
                      r = f.split(".");
                      f = r.shift();
                      var G = new RegExp(
                        "(^|\\.)" +
                          c.map(r.slice(0).sort(), Db).join("\\.(?:.*\\.)?") +
                          "(\\.|$)"
                      );
                    }
                    if ((k = m[f]))
                      if (d) {
                        n = c.event.special[f] || {};
                        for (g = e || 0; g < k.length; g++) {
                          var x = k[g];
                          if (d.guid === x.guid) {
                            if (q || G.test(x.namespace))
                              null == e && k.splice(g--, 1),
                                n.remove && n.remove.call(a, x);
                            if (null != e) break;
                          }
                        }
                        if (0 === k.length || (null != e && 1 === k.length))
                          (n.teardown && !1 !== n.teardown.call(a, r)) ||
                            c.removeEvent(a, f, l.handle),
                            delete m[f];
                      } else
                        for (g = 0; g < k.length; g++)
                          if (((x = k[g]), q || G.test(x.namespace)))
                            c.event.remove(a, n, x.handler, g),
                              k.splice(g--, 1);
                  }
                  if (c.isEmptyObject(m)) {
                    if ((b = l.handle)) b.elem = null;
                    delete l.events;
                    delete l.handle;
                    c.isEmptyObject(l) && c.removeData(a, p, !0);
                  }
                }
            }
          },
          customEvent: {getData: !0, setData: !0, changeData: !0},
          trigger: function (a, b, d, e) {
            var f = a.type || a,
              g = [];
            if (0 <= f.indexOf("!")) {
              f = f.slice(0, -1);
              var h = !0;
            }
            0 <= f.indexOf(".") &&
              ((g = f.split(".")), (f = g.shift()), g.sort());
            if ((d && !c.event.customEvent[f]) || c.event.global[f]) {
              a =
                "object" === typeof a
                  ? a[c.expando]
                    ? a
                    : new c.Event(f, a)
                  : new c.Event(f);
              a.type = f;
              a.exclusive = h;
              a.namespace = g.join(".");
              a.namespace_re = new RegExp(
                "(^|\\.)" + g.join("\\.(?:.*\\.)?") + "(\\.|$)"
              );
              if (e || !d) a.preventDefault(), a.stopPropagation();
              if (!d)
                c.each(c.cache, function () {
                  var d = this[c.expando];
                  d &&
                    d.events &&
                    d.events[f] &&
                    c.event.trigger(a, b, d.handle.elem);
                });
              else if (3 !== d.nodeType && 8 !== d.nodeType) {
                a.result = p;
                a.target = d;
                b = null != b ? c.makeArray(b) : [];
                b.unshift(a);
                g = d;
                e = 0 > f.indexOf(":") ? "on" + f : "";
                do
                  (h = c._data(g, "handle")),
                    (a.currentTarget = g),
                    h && h.apply(g, b),
                    e &&
                      c.acceptData(g) &&
                      g[e] &&
                      !1 === g[e].apply(g, b) &&
                      ((a.result = !1), a.preventDefault()),
                    (g =
                      g.parentNode ||
                      g.ownerDocument ||
                      (g === a.target.ownerDocument && r));
                while (g && !a.isPropagationStopped());
                if (!a.isDefaultPrevented()) {
                  var k;
                  g = c.event.special[f] || {};
                  if (
                    !(
                      (g._default &&
                        !1 !== g._default.call(d.ownerDocument, a)) ||
                      ("click" === f && c.nodeName(d, "a"))
                    ) &&
                    c.acceptData(d)
                  ) {
                    try {
                      e &&
                        d[f] &&
                        ((k = d[e]) && (d[e] = null),
                        (c.event.triggered = f),
                        d[f]());
                    } catch (l) {}
                    k && (d[e] = k);
                    c.event.triggered = p;
                  }
                }
                return a.result;
              }
            }
          },
          handle: function (a) {
            a = c.event.fix(a || r.event);
            var b = ((c._data(this, "events") || {})[a.type] || []).slice(0),
              d = !a.exclusive && !a.namespace,
              e = Array.prototype.slice.call(arguments, 0);
            e[0] = a;
            a.currentTarget = this;
            for (var f = 0, g = b.length; f < g; f++) {
              var h = b[f];
              if (d || a.namespace_re.test(h.namespace))
                if (
                  ((a.handler = h.handler),
                  (a.data = h.data),
                  (a.handleObj = h),
                  (h = h.handler.apply(this, e)),
                  h !== p &&
                    ((a.result = h),
                    !1 === h && (a.preventDefault(), a.stopPropagation())),
                  a.isImmediatePropagationStopped())
                )
                  break;
            }
            return a.result;
          },
          props:
            "altKey attrChange attrName bubbles button cancelable charCode clientX clientY ctrlKey currentTarget data detail eventPhase fromElement handler keyCode layerX layerY metaKey newValue offsetX offsetY pageX pageY prevValue relatedNode relatedTarget screenX screenY shiftKey srcElement target toElement view wheelDelta which".split(
              " "
            ),
          fix: function (a) {
            if (a[c.expando]) return a;
            var b = a;
            a = c.Event(b);
            for (var d = this.props.length, e; d; )
              (e = this.props[--d]), (a[e] = b[e]);
            a.target || (a.target = a.srcElement || q);
            3 === a.target.nodeType && (a.target = a.target.parentNode);
            !a.relatedTarget &&
              a.fromElement &&
              (a.relatedTarget =
                a.fromElement === a.target ? a.toElement : a.fromElement);
            null == a.pageX &&
              null != a.clientX &&
              ((d = a.target.ownerDocument || q),
              (b = d.documentElement),
              (d = d.body),
              (a.pageX =
                a.clientX +
                ((b && b.scrollLeft) || (d && d.scrollLeft) || 0) -
                ((b && b.clientLeft) || (d && d.clientLeft) || 0)),
              (a.pageY =
                a.clientY +
                ((b && b.scrollTop) || (d && d.scrollTop) || 0) -
                ((b && b.clientTop) || (d && d.clientTop) || 0)));
            null != a.which ||
              (null == a.charCode && null == a.keyCode) ||
              (a.which = null != a.charCode ? a.charCode : a.keyCode);
            !a.metaKey && a.ctrlKey && (a.metaKey = a.ctrlKey);
            a.which ||
              a.button === p ||
              (a.which =
                a.button & 1 ? 1 : a.button & 2 ? 3 : a.button & 4 ? 2 : 0);
            return a;
          },
          guid: 1e8,
          proxy: c.proxy,
          special: {
            ready: {setup: c.bindReady, teardown: c.noop},
            live: {
              add: function (a) {
                c.event.add(
                  this,
                  X(a.origType, a.selector),
                  c.extend({}, a, {handler: ib, guid: a.handler.guid})
                );
              },
              remove: function (a) {
                c.event.remove(this, X(a.origType, a.selector), a);
              },
            },
            beforeunload: {
              setup: function (a, b, d) {
                c.isWindow(this) && (this.onbeforeunload = d);
              },
              teardown: function (a, b) {
                this.onbeforeunload === b && (this.onbeforeunload = null);
              },
            },
          },
        };
        c.removeEvent = q.removeEventListener
          ? function (a, b, c) {
              a.removeEventListener && a.removeEventListener(b, c, !1);
            }
          : function (a, b, c) {
              a.detachEvent && a.detachEvent("on" + b, c);
            };
        c.Event = function (a, b) {
          if (!this.preventDefault) return new c.Event(a, b);
          a && a.type
            ? ((this.originalEvent = a),
              (this.type = a.type),
              (this.isDefaultPrevented =
                a.defaultPrevented ||
                !1 === a.returnValue ||
                (a.getPreventDefault && a.getPreventDefault())
                  ? W
                  : H))
            : (this.type = a);
          b && c.extend(this, b);
          this.timeStamp = c.now();
          this[c.expando] = !0;
        };
        c.Event.prototype = {
          preventDefault: function () {
            this.isDefaultPrevented = W;
            var a = this.originalEvent;
            a && (a.preventDefault ? a.preventDefault() : (a.returnValue = !1));
          },
          stopPropagation: function () {
            this.isPropagationStopped = W;
            var a = this.originalEvent;
            a &&
              (a.stopPropagation && a.stopPropagation(), (a.cancelBubble = !0));
          },
          stopImmediatePropagation: function () {
            this.isImmediatePropagationStopped = W;
            this.stopPropagation();
          },
          isDefaultPrevented: H,
          isPropagationStopped: H,
          isImmediatePropagationStopped: H,
        };
        var Qa = function (a) {
            var b = a.relatedTarget,
              d = !1,
              e = a.type;
            a.type = a.data;
            b !== this &&
              (b && (d = c.contains(this, b)),
              d || (c.event.handle.apply(this, arguments), (a.type = e)));
          },
          Ra = function (a) {
            a.type = a.data;
            c.event.handle.apply(this, arguments);
          };
        c.each(
          {mouseenter: "mouseover", mouseleave: "mouseout"},
          function (a, b) {
            c.event.special[a] = {
              setup: function (d) {
                c.event.add(this, b, d && d.selector ? Ra : Qa, a);
              },
              teardown: function (a) {
                c.event.remove(this, b, a && a.selector ? Ra : Qa);
              },
            };
          }
        );
        c.support.submitBubbles ||
          (c.event.special.submit = {
            setup: function (a, b) {
              if (c.nodeName(this, "form")) return !1;
              c.event.add(this, "click.specialSubmit", function (a) {
                var b = a.target,
                  d =
                    c.nodeName(b, "input") || c.nodeName(b, "button")
                      ? b.type
                      : "";
                ("submit" !== d && "image" !== d) ||
                  !c(b).closest("form").length ||
                  wa("submit", this, arguments);
              });
              c.event.add(this, "keypress.specialSubmit", function (a) {
                var b = a.target,
                  d =
                    c.nodeName(b, "input") || c.nodeName(b, "button")
                      ? b.type
                      : "";
                ("text" !== d && "password" !== d) ||
                  !c(b).closest("form").length ||
                  13 !== a.keyCode ||
                  wa("submit", this, arguments);
              });
            },
            teardown: function (a) {
              c.event.remove(this, ".specialSubmit");
            },
          });
        if (!c.support.changeBubbles) {
          var Sa = function (a) {
              var b = c.nodeName(a, "input") ? a.type : "",
                d = a.value;
              "radio" === b || "checkbox" === b
                ? (d = a.checked)
                : "select-multiple" === b
                ? (d =
                    -1 < a.selectedIndex
                      ? c
                          .map(a.options, function (a) {
                            return a.selected;
                          })
                          .join("-")
                      : "")
                : c.nodeName(a, "select") && (d = a.selectedIndex);
              return d;
            },
            ca = function (a, b) {
              var d = a.target;
              if (qa.test(d.nodeName) && !d.readOnly) {
                var e = c._data(d, "_change_data");
                var f = Sa(d);
                ("focusout" === a.type && "radio" === d.type) ||
                  c._data(d, "_change_data", f);
                e === p ||
                  f === e ||
                  (null == e && !f) ||
                  ((a.type = "change"),
                  (a.liveFired = p),
                  c.event.trigger(a, b, d));
              }
            };
          c.event.special.change = {
            filters: {
              focusout: ca,
              beforedeactivate: ca,
              click: function (a) {
                var b = a.target,
                  d = c.nodeName(b, "input") ? b.type : "";
                ("radio" === d ||
                  "checkbox" === d ||
                  c.nodeName(b, "select")) &&
                  ca.call(this, a);
              },
              keydown: function (a) {
                var b = a.target,
                  d = c.nodeName(b, "input") ? b.type : "";
                ((13 === a.keyCode && !c.nodeName(b, "textarea")) ||
                  (32 === a.keyCode && ("checkbox" === d || "radio" === d)) ||
                  "select-multiple" === d) &&
                  ca.call(this, a);
              },
              beforeactivate: function (a) {
                a = a.target;
                c._data(a, "_change_data", Sa(a));
              },
            },
            setup: function (a, b) {
              if ("file" === this.type) return !1;
              for (var d in da) c.event.add(this, d + ".specialChange", da[d]);
              return qa.test(this.nodeName);
            },
            teardown: function (a) {
              c.event.remove(this, ".specialChange");
              return qa.test(this.nodeName);
            },
          };
          var da = c.event.special.change.filters;
          da.focus = da.beforeactivate;
        }
        c.support.focusinBubbles ||
          c.each({focus: "focusin", blur: "focusout"}, function (a, b) {
            function d(a) {
              var d = c.event.fix(a);
              d.type = b;
              d.originalEvent = {};
              c.event.trigger(d, null, d.target);
              d.isDefaultPrevented() && a.preventDefault();
            }
            var e = 0;
            c.event.special[b] = {
              setup: function () {
                0 === e++ && q.addEventListener(a, d, !0);
              },
              teardown: function () {
                0 === --e && q.removeEventListener(a, d, !0);
              },
            };
          });
        c.each(["bind", "one"], function (a, b) {
          c.fn[b] = function (a, e, f) {
            if ("object" === typeof a) {
              for (var d in a) this[b](d, e, a[d], f);
              return this;
            }
            if (2 === arguments.length || !1 === e) (f = e), (e = p);
            if ("one" === b) {
              var h = function (a) {
                c(this).unbind(a, h);
                return f.apply(this, arguments);
              };
              h.guid = f.guid || c.guid++;
            } else h = f;
            if ("unload" === a && "one" !== b) this.one(a, e, f);
            else {
              d = 0;
              for (var k = this.length; d < k; d++)
                c.event.add(this[d], a, h, e);
            }
            return this;
          };
        });
        c.fn.extend({
          unbind: function (a, b) {
            if ("object" !== typeof a || a.preventDefault)
              for (var d = 0, e = this.length; d < e; d++)
                c.event.remove(this[d], a, b);
            else for (d in a) this.unbind(d, a[d]);
            return this;
          },
          delegate: function (a, b, c, e) {
            return this.live(b, c, e, a);
          },
          undelegate: function (a, b, c) {
            return 0 === arguments.length
              ? this.unbind("live")
              : this.die(b, null, c, a);
          },
          trigger: function (a, b) {
            return this.each(function () {
              c.event.trigger(a, b, this);
            });
          },
          triggerHandler: function (a, b) {
            if (this[0]) return c.event.trigger(a, b, this[0], !0);
          },
          toggle: function (a) {
            var b = arguments,
              d = a.guid || c.guid++,
              e = 0,
              f = function (d) {
                var f = (c.data(this, "lastToggle" + a.guid) || 0) % e;
                c.data(this, "lastToggle" + a.guid, f + 1);
                d.preventDefault();
                return b[f].apply(this, arguments) || !1;
              };
            for (f.guid = d; e < b.length; ) b[e++].guid = d;
            return this.click(f);
          },
          hover: function (a, b) {
            return this.mouseenter(a).mouseleave(b || a);
          },
        });
        var ra = {
          focus: "focusin",
          blur: "focusout",
          mouseenter: "mouseover",
          mouseleave: "mouseout",
        };
        c.each(["live", "die"], function (a, b) {
          c.fn[b] = function (a, e, f, g) {
            var d = 0,
              k = g || this.selector,
              l = g ? this : c(this.context);
            if ("object" === typeof a && !a.preventDefault) {
              for (m in a) l[b](m, e, a[m], k);
              return this;
            }
            if ("die" === b && !a && g && "." === g.charAt(0))
              return l.unbind(g), this;
            if (!1 === e || c.isFunction(e)) (f = e || H), (e = p);
            for (a = (a || "").split(" "); null != (g = a[d++]); ) {
              var m = ia.exec(g);
              var n = "";
              m && ((n = m[0]), (g = g.replace(ia, "")));
              if ("hover" === g) a.push("mouseenter" + n, "mouseleave" + n);
              else if (
                ((m = g),
                ra[g] ? (a.push(ra[g] + n), (g += n)) : (g = (ra[g] || g) + n),
                "live" === b)
              ) {
                n = 0;
                for (var q = l.length; n < q; n++)
                  c.event.add(l[n], "live." + X(g, k), {
                    data: e,
                    selector: k,
                    handler: f,
                    origType: g,
                    origHandler: f,
                    preType: m,
                  });
              } else l.unbind("live." + X(g, k), f);
            }
            return this;
          };
        });
        c.each(
          "blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error".split(
            " "
          ),
          function (a, b) {
            c.fn[b] = function (a, c) {
              null == c && ((c = a), (a = null));
              return 0 < arguments.length
                ? this.bind(b, a, c)
                : this.trigger(b);
            };
            c.attrFn && (c.attrFn[b] = !0);
          }
        );
        (function () {
          function a(a, b, c, d, e, f) {
            e = 0;
            for (var t = d.length; e < t; e++) {
              var g = d[e];
              if (g) {
                var h = !1;
                for (g = g[a]; g; ) {
                  if (g.sizcache === c) {
                    h = d[g.sizset];
                    break;
                  }
                  1 !== g.nodeType || f || ((g.sizcache = c), (g.sizset = e));
                  if (g.nodeName.toLowerCase() === b) {
                    h = g;
                    break;
                  }
                  g = g[a];
                }
                d[e] = h;
              }
            }
          }
          function b(a, b, c, d, e, f) {
            e = 0;
            for (var t = d.length; e < t; e++) {
              var g = d[e];
              if (g) {
                var h = !1;
                for (g = g[a]; g; ) {
                  if (g.sizcache === c) {
                    h = d[g.sizset];
                    break;
                  }
                  if (1 === g.nodeType)
                    if (
                      (f || ((g.sizcache = c), (g.sizset = e)),
                      "string" !== typeof b)
                    ) {
                      if (g === b) {
                        h = !0;
                        break;
                      }
                    } else if (0 < m.filter(b, [g]).length) {
                      h = g;
                      break;
                    }
                  g = g[a];
                }
                d[e] = h;
              }
            }
          }
          var d =
              /((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^\[\]]*\]|['"][^'"]*['"]|[^\[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?((?:.|\r|\n)*)/g,
            e = 0,
            f = Object.prototype.toString,
            g = !1,
            h = !0,
            k = /\\/g,
            l = /\W/;
          [0, 0].sort(function () {
            h = !1;
            return 0;
          });
          var m = function (a, b, c, e) {
            c = c || [];
            var g = (b = b || q);
            if (1 !== b.nodeType && 9 !== b.nodeType) return [];
            if (!a || "string" !== typeof a) return c;
            var t,
              h,
              y,
              k = !0,
              l = m.isXML(b),
              u = [],
              A = a;
            do
              if ((d.exec(""), (t = d.exec(A))))
                if (((A = t[3]), u.push(t[1]), t[2])) {
                  var p = t[3];
                  break;
                }
            while (t);
            if (1 < u.length && r.exec(a))
              if (2 === u.length && n.relative[u[0]]) var z = v(u[0] + u[1], b);
              else
                for (z = n.relative[u[0]] ? [b] : m(u.shift(), b); u.length; )
                  (a = u.shift()),
                    n.relative[a] && (a += u.shift()),
                    (z = v(a, z));
            else if (
              (!e &&
                1 < u.length &&
                9 === b.nodeType &&
                !l &&
                n.match.ID.test(u[0]) &&
                !n.match.ID.test(u[u.length - 1]) &&
                ((t = m.find(u.shift(), b, l)),
                (b = t.expr ? m.filter(t.expr, t.set)[0] : t.set[0])),
              b)
            )
              for (
                t = e
                  ? {expr: u.pop(), set: x(e)}
                  : m.find(
                      u.pop(),
                      1 !== u.length ||
                        ("~" !== u[0] && "+" !== u[0]) ||
                        !b.parentNode
                        ? b
                        : b.parentNode,
                      l
                    ),
                  z = t.expr ? m.filter(t.expr, t.set) : t.set,
                  0 < u.length ? (h = x(z)) : (k = !1);
                u.length;

              )
                (t = y = u.pop()),
                  n.relative[y] ? (t = u.pop()) : (y = ""),
                  null == t && (t = b),
                  n.relative[y](h, t, l);
            else h = [];
            h || (h = z);
            h || m.error(y || a);
            if ("[object Array]" === f.call(h))
              if (k)
                if (b && 1 === b.nodeType)
                  for (a = 0; null != h[a]; a++)
                    h[a] &&
                      (!0 === h[a] ||
                        (1 === h[a].nodeType && m.contains(b, h[a]))) &&
                      c.push(z[a]);
                else
                  for (a = 0; null != h[a]; a++)
                    h[a] && 1 === h[a].nodeType && c.push(z[a]);
              else c.push.apply(c, h);
            else x(h, c);
            p && (m(p, g, c, e), m.uniqueSort(c));
            return c;
          };
          m.uniqueSort = function (a) {
            if (E && ((g = h), a.sort(E), g))
              for (var b = 1; b < a.length; b++)
                a[b] === a[b - 1] && a.splice(b--, 1);
            return a;
          };
          m.matches = function (a, b) {
            return m(a, null, null, b);
          };
          m.matchesSelector = function (a, b) {
            return 0 < m(b, null, null, [a]).length;
          };
          m.find = function (a, b, c) {
            if (!a) return [];
            for (var d = 0, e = n.order.length; d < e; d++) {
              var f,
                g = n.order[d];
              if ((f = n.leftMatch[g].exec(a))) {
                var t = f[1];
                f.splice(1, 1);
                if ("\\" !== t.substr(t.length - 1)) {
                  f[1] = (f[1] || "").replace(k, "");
                  var h = n.find[g](f, b, c);
                  if (null != h) {
                    a = a.replace(n.match[g], "");
                    break;
                  }
                }
              }
            }
            h ||
              (h =
                "undefined" !== typeof b.getElementsByTagName
                  ? b.getElementsByTagName("*")
                  : []);
            return {set: h, expr: a};
          };
          m.filter = function (a, b, c, d) {
            for (
              var e, f, g = a, t = [], h = b, y = b && b[0] && m.isXML(b[0]);
              a && b.length;

            ) {
              for (var k in n.filter)
                if (null != (e = n.leftMatch[k].exec(a)) && e[2]) {
                  var u,
                    l = n.filter[k];
                  var A = e[1];
                  f = !1;
                  e.splice(1, 1);
                  if ("\\" !== A.substr(A.length - 1)) {
                    h === t && (t = []);
                    if (n.preFilter[k])
                      if (((e = n.preFilter[k](e, h, c, t, d, y)), !e))
                        f = u = !0;
                      else if (!0 === e) continue;
                    if (e)
                      for (var q = 0; null != (A = h[q]); q++)
                        if (A) {
                          u = l(A, e, q, h);
                          var r = d ^ !!u;
                          c && null != u
                            ? r
                              ? (f = !0)
                              : (h[q] = !1)
                            : r && (t.push(A), (f = !0));
                        }
                    if (u !== p) {
                      c || (h = t);
                      a = a.replace(n.match[k], "");
                      if (!f) return [];
                      break;
                    }
                  }
                }
              if (a === g)
                if (null == f) m.error(a);
                else break;
              g = a;
            }
            return h;
          };
          m.error = function (a) {
            throw "Syntax error, unrecognized expression: " + a;
          };
          var n = (m.selectors = {
              order: ["ID", "NAME", "TAG"],
              match: {
                ID: /#((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,
                CLASS: /\.((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,
                NAME: /\[name=['"]*((?:[\w\u00c0-\uFFFF\-]|\\.)+)['"]*\]/,
                ATTR: /\[\s*((?:[\w\u00c0-\uFFFF\-]|\\.)+)\s*(?:(\S?=)\s*(?:(['"])(.*?)\3|(#?(?:[\w\u00c0-\uFFFF\-]|\\.)*)|)|)\s*\]/,
                TAG: /^((?:[\w\u00c0-\uFFFF\*\-]|\\.)+)/,
                CHILD:
                  /:(only|nth|last|first)-child(?:\(\s*(even|odd|(?:[+\-]?\d+|(?:[+\-]?\d*)?n\s*(?:[+\-]\s*\d+)?))\s*\))?/,
                POS: /:(nth|eq|gt|lt|first|last|even|odd)(?:\((\d*)\))?(?=[^\-]|$)/,
                PSEUDO:
                  /:((?:[\w\u00c0-\uFFFF\-]|\\.)+)(?:\((['"]?)((?:\([^\)]+\)|[^\(\)]*)+)\2\))?/,
              },
              leftMatch: {},
              attrMap: {class: "className", for: "htmlFor"},
              attrHandle: {
                href: function (a) {
                  return a.getAttribute("href");
                },
                type: function (a) {
                  return a.getAttribute("type");
                },
              },
              relative: {
                "+": function (a, b) {
                  var c = "string" === typeof b,
                    d = c && !l.test(b);
                  c = c && !d;
                  d && (b = b.toLowerCase());
                  d = 0;
                  for (var e = a.length, f; d < e; d++)
                    if ((f = a[d])) {
                      for (; (f = f.previousSibling) && 1 !== f.nodeType; );
                      a[d] =
                        c || (f && f.nodeName.toLowerCase() === b)
                          ? f || !1
                          : f === b;
                    }
                  c && m.filter(b, a, !0);
                },
                "\x3e": function (a, b) {
                  var c,
                    d = "string" === typeof b,
                    e = 0,
                    f = a.length;
                  if (d && !l.test(b))
                    for (b = b.toLowerCase(); e < f; e++) {
                      if ((c = a[e]))
                        (c = c.parentNode),
                          (a[e] = c.nodeName.toLowerCase() === b ? c : !1);
                    }
                  else {
                    for (; e < f; e++)
                      (c = a[e]) &&
                        (a[e] = d ? c.parentNode : c.parentNode === b);
                    d && m.filter(b, a, !0);
                  }
                },
                "": function (c, d, f) {
                  var g = e++,
                    h = b;
                  if ("string" === typeof d && !l.test(d)) {
                    var t = (d = d.toLowerCase());
                    h = a;
                  }
                  h("parentNode", d, g, c, t, f);
                },
                "~": function (c, d, f) {
                  var g = e++,
                    h = b;
                  if ("string" === typeof d && !l.test(d)) {
                    var t = (d = d.toLowerCase());
                    h = a;
                  }
                  h("previousSibling", d, g, c, t, f);
                },
              },
              find: {
                ID: function (a, b, c) {
                  if ("undefined" !== typeof b.getElementById && !c)
                    return (a = b.getElementById(a[1])) && a.parentNode
                      ? [a]
                      : [];
                },
                NAME: function (a, b) {
                  if ("undefined" !== typeof b.getElementsByName) {
                    var c = [];
                    b = b.getElementsByName(a[1]);
                    for (var d = 0, e = b.length; d < e; d++)
                      b[d].getAttribute("name") === a[1] && c.push(b[d]);
                    return 0 === c.length ? null : c;
                  }
                },
                TAG: function (a, b) {
                  if ("undefined" !== typeof b.getElementsByTagName)
                    return b.getElementsByTagName(a[1]);
                },
              },
              preFilter: {
                CLASS: function (a, b, c, d, e, f) {
                  a = " " + a[1].replace(k, "") + " ";
                  if (f) return a;
                  f = 0;
                  for (var g; null != (g = b[f]); f++)
                    g &&
                      (e ^
                      (g.className &&
                        0 <=
                          (" " + g.className + " ")
                            .replace(/[\t\n\r]/g, " ")
                            .indexOf(a))
                        ? c || d.push(g)
                        : c && (b[f] = !1));
                  return !1;
                },
                ID: function (a) {
                  return a[1].replace(k, "");
                },
                TAG: function (a, b) {
                  return a[1].replace(k, "").toLowerCase();
                },
                CHILD: function (a) {
                  if ("nth" === a[1]) {
                    a[2] || m.error(a[0]);
                    a[2] = a[2].replace(/^\+|\s*/g, "");
                    var b = /(-?)(\d*)(?:n([+\-]?\d*))?/.exec(
                      ("even" === a[2] && "2n") ||
                        ("odd" === a[2] && "2n+1") ||
                        (!/\D/.test(a[2]) && "0n+" + a[2]) ||
                        a[2]
                    );
                    a[2] = b[1] + (b[2] || 1) - 0;
                    a[3] = b[3] - 0;
                  } else a[2] && m.error(a[0]);
                  a[0] = e++;
                  return a;
                },
                ATTR: function (a, b, c, d, e, f) {
                  b = a[1] = a[1].replace(k, "");
                  !f && n.attrMap[b] && (a[1] = n.attrMap[b]);
                  a[4] = (a[4] || a[5] || "").replace(k, "");
                  "~\x3d" === a[2] && (a[4] = " " + a[4] + " ");
                  return a;
                },
                PSEUDO: function (a, b, c, e, f) {
                  if ("not" === a[1])
                    if (1 < (d.exec(a[3]) || "").length || /^\w/.test(a[3]))
                      a[3] = m(a[3], null, null, b);
                    else
                      return (
                        (a = m.filter(a[3], b, c, 1 ^ f)),
                        c || e.push.apply(e, a),
                        !1
                      );
                  else if (n.match.POS.test(a[0]) || n.match.CHILD.test(a[0]))
                    return !0;
                  return a;
                },
                POS: function (a) {
                  a.unshift(!0);
                  return a;
                },
              },
              filters: {
                enabled: function (a) {
                  return !1 === a.disabled && "hidden" !== a.type;
                },
                disabled: function (a) {
                  return !0 === a.disabled;
                },
                checked: function (a) {
                  return !0 === a.checked;
                },
                selected: function (a) {
                  a.parentNode && a.parentNode.selectedIndex;
                  return !0 === a.selected;
                },
                parent: function (a) {
                  return !!a.firstChild;
                },
                empty: function (a) {
                  return !a.firstChild;
                },
                has: function (a, b, c) {
                  return !!m(c[3], a).length;
                },
                header: function (a) {
                  return /h\d/i.test(a.nodeName);
                },
                text: function (a) {
                  var b = a.getAttribute("type"),
                    c = a.type;
                  return (
                    "input" === a.nodeName.toLowerCase() &&
                    "text" === c &&
                    (b === c || null === b)
                  );
                },
                radio: function (a) {
                  return (
                    "input" === a.nodeName.toLowerCase() && "radio" === a.type
                  );
                },
                checkbox: function (a) {
                  return (
                    "input" === a.nodeName.toLowerCase() &&
                    "checkbox" === a.type
                  );
                },
                file: function (a) {
                  return (
                    "input" === a.nodeName.toLowerCase() && "file" === a.type
                  );
                },
                password: function (a) {
                  return (
                    "input" === a.nodeName.toLowerCase() &&
                    "password" === a.type
                  );
                },
                submit: function (a) {
                  var b = a.nodeName.toLowerCase();
                  return (
                    ("input" === b || "button" === b) && "submit" === a.type
                  );
                },
                image: function (a) {
                  return (
                    "input" === a.nodeName.toLowerCase() && "image" === a.type
                  );
                },
                reset: function (a) {
                  var b = a.nodeName.toLowerCase();
                  return (
                    ("input" === b || "button" === b) && "reset" === a.type
                  );
                },
                button: function (a) {
                  var b = a.nodeName.toLowerCase();
                  return (
                    ("input" === b && "button" === a.type) || "button" === b
                  );
                },
                input: function (a) {
                  return /input|select|textarea|button/i.test(a.nodeName);
                },
                focus: function (a) {
                  return a === a.ownerDocument.activeElement;
                },
              },
              setFilters: {
                first: function (a, b) {
                  return 0 === b;
                },
                last: function (a, b, c, d) {
                  return b === d.length - 1;
                },
                even: function (a, b) {
                  return 0 === b % 2;
                },
                odd: function (a, b) {
                  return 1 === b % 2;
                },
                lt: function (a, b, c) {
                  return b < c[3] - 0;
                },
                gt: function (a, b, c) {
                  return b > c[3] - 0;
                },
                nth: function (a, b, c) {
                  return c[3] - 0 === b;
                },
                eq: function (a, b, c) {
                  return c[3] - 0 === b;
                },
              },
              filter: {
                PSEUDO: function (a, b, c, d) {
                  var e = b[1],
                    f = n.filters[e];
                  if (f) return f(a, c, b, d);
                  if ("contains" === e)
                    return (
                      0 <=
                      (
                        a.textContent ||
                        a.innerText ||
                        m.getText([a]) ||
                        ""
                      ).indexOf(b[3])
                    );
                  if ("not" === e) {
                    b = b[3];
                    c = 0;
                    for (d = b.length; c < d; c++) if (b[c] === a) return !1;
                    return !0;
                  }
                  m.error(e);
                },
                CHILD: function (a, b) {
                  var c = b[1],
                    d = a;
                  switch (c) {
                    case "only":
                    case "first":
                      for (; (d = d.previousSibling); )
                        if (1 === d.nodeType) return !1;
                      if ("first" === c) return !0;
                      d = a;
                    case "last":
                      for (; (d = d.nextSibling); )
                        if (1 === d.nodeType) return !1;
                      return !0;
                    case "nth":
                      c = b[2];
                      var e = b[3];
                      if (1 === c && 0 === e) return !0;
                      b = b[0];
                      var f = a.parentNode;
                      if (f && (f.sizcache !== b || !a.nodeIndex)) {
                        var g = 0;
                        for (d = f.firstChild; d; d = d.nextSibling)
                          1 === d.nodeType && (d.nodeIndex = ++g);
                        f.sizcache = b;
                      }
                      a = a.nodeIndex - e;
                      return 0 === c ? 0 === a : 0 === a % c && 0 <= a / c;
                  }
                },
                ID: function (a, b) {
                  return 1 === a.nodeType && a.getAttribute("id") === b;
                },
                TAG: function (a, b) {
                  return (
                    ("*" === b && 1 === a.nodeType) ||
                    a.nodeName.toLowerCase() === b
                  );
                },
                CLASS: function (a, b) {
                  return (
                    -1 <
                    (
                      " " +
                      (a.className || a.getAttribute("class")) +
                      " "
                    ).indexOf(b)
                  );
                },
                ATTR: function (a, b) {
                  var c = b[1];
                  a = n.attrHandle[c]
                    ? n.attrHandle[c](a)
                    : null != a[c]
                    ? a[c]
                    : a.getAttribute(c);
                  c = a + "";
                  var d = b[2];
                  b = b[4];
                  return null == a
                    ? "!\x3d" === d
                    : "\x3d" === d
                    ? c === b
                    : "*\x3d" === d
                    ? 0 <= c.indexOf(b)
                    : "~\x3d" === d
                    ? 0 <= (" " + c + " ").indexOf(b)
                    : b
                    ? "!\x3d" === d
                      ? c !== b
                      : "^\x3d" === d
                      ? 0 === c.indexOf(b)
                      : "$\x3d" === d
                      ? c.substr(c.length - b.length) === b
                      : "|\x3d" === d
                      ? c === b || c.substr(0, b.length + 1) === b + "-"
                      : !1
                    : c && !1 !== a;
                },
                POS: function (a, b, c, d) {
                  var e = n.setFilters[b[2]];
                  if (e) return e(a, c, b, d);
                },
              },
            }),
            r = n.match.POS,
            z = function (a, b) {
              return "\\" + (b - 0 + 1);
            },
            G;
          for (G in n.match)
            (n.match[G] = new RegExp(
              n.match[G].source + /(?![^\[]*\])(?![^\(]*\))/.source
            )),
              (n.leftMatch[G] = new RegExp(
                /(^(?:.|\r|\n)*?)/.source +
                  n.match[G].source.replace(/\\(\d+)/g, z)
              ));
          var x = function (a, b) {
            a = Array.prototype.slice.call(a, 0);
            return b ? (b.push.apply(b, a), b) : a;
          };
          try {
            Array.prototype.slice.call(q.documentElement.childNodes, 0)[0]
              .nodeType;
          } catch (t) {
            x = function (a, b) {
              var c = 0;
              b = b || [];
              if ("[object Array]" === f.call(a))
                Array.prototype.push.apply(b, a);
              else if ("number" === typeof a.length)
                for (var d = a.length; c < d; c++) b.push(a[c]);
              else for (; a[c]; c++) b.push(a[c]);
              return b;
            };
          }
          if (q.documentElement.compareDocumentPosition)
            var E = function (a, b) {
              return a === b
                ? ((g = !0), 0)
                : a.compareDocumentPosition && b.compareDocumentPosition
                ? a.compareDocumentPosition(b) & 4
                  ? -1
                  : 1
                : a.compareDocumentPosition
                ? -1
                : 1;
            };
          else {
            E = function (a, b) {
              if (a === b) return (g = !0), 0;
              if (a.sourceIndex && b.sourceIndex)
                return a.sourceIndex - b.sourceIndex;
              var c = [],
                d = [];
              var e = a.parentNode;
              var f = b.parentNode;
              var h = e;
              if (e === f) return w(a, b);
              if (!e) return -1;
              if (!f) return 1;
              for (; h; ) c.unshift(h), (h = h.parentNode);
              for (h = f; h; ) d.unshift(h), (h = h.parentNode);
              e = c.length;
              f = d.length;
              for (h = 0; h < e && h < f; h++)
                if (c[h] !== d[h]) return w(c[h], d[h]);
              return h === e ? w(a, d[h], -1) : w(c[h], b, 1);
            };
            var w = function (a, b, c) {
              if (a === b) return c;
              for (a = a.nextSibling; a; ) {
                if (a === b) return -1;
                a = a.nextSibling;
              }
              return 1;
            };
          }
          m.getText = function (a) {
            for (var b = "", c, d = 0; a[d]; d++)
              (c = a[d]),
                3 === c.nodeType || 4 === c.nodeType
                  ? (b += c.nodeValue)
                  : 8 !== c.nodeType && (b += m.getText(c.childNodes));
            return b;
          };
          (function () {
            var a = q.createElement("div"),
              b = "script" + new Date().getTime(),
              c = q.documentElement;
            a.innerHTML = "\x3ca name\x3d'" + b + "'/\x3e";
            c.insertBefore(a, c.firstChild);
            q.getElementById(b) &&
              ((n.find.ID = function (a, b, c) {
                if ("undefined" !== typeof b.getElementById && !c)
                  return (b = b.getElementById(a[1]))
                    ? b.id === a[1] ||
                      ("undefined" !== typeof b.getAttributeNode &&
                        b.getAttributeNode("id").nodeValue === a[1])
                      ? [b]
                      : p
                    : [];
              }),
              (n.filter.ID = function (a, b) {
                var c =
                  "undefined" !== typeof a.getAttributeNode &&
                  a.getAttributeNode("id");
                return 1 === a.nodeType && c && c.nodeValue === b;
              }));
            c.removeChild(a);
            c = a = null;
          })();
          (function () {
            var a = q.createElement("div");
            a.appendChild(q.createComment(""));
            0 < a.getElementsByTagName("*").length &&
              (n.find.TAG = function (a, b) {
                b = b.getElementsByTagName(a[1]);
                if ("*" === a[1]) {
                  a = [];
                  for (var c = 0; b[c]; c++)
                    1 === b[c].nodeType && a.push(b[c]);
                  b = a;
                }
                return b;
              });
            a.innerHTML = "\x3ca href\x3d'#'\x3e\x3c/a\x3e";
            a.firstChild &&
              "undefined" !== typeof a.firstChild.getAttribute &&
              "#" !== a.firstChild.getAttribute("href") &&
              (n.attrHandle.href = function (a) {
                return a.getAttribute("href", 2);
              });
            a = null;
          })();
          q.querySelectorAll &&
            (function () {
              var a = m,
                b = q.createElement("div");
              b.innerHTML = "\x3cp class\x3d'TEST'\x3e\x3c/p\x3e";
              if (
                !b.querySelectorAll ||
                0 !== b.querySelectorAll(".TEST").length
              ) {
                m = function (b, c, d, e) {
                  c = c || q;
                  if (!e && !m.isXML(c)) {
                    var f = /^(\w+$)|^\.([\w\-]+$)|^#([\w\-]+$)/.exec(b);
                    if (f && (1 === c.nodeType || 9 === c.nodeType)) {
                      if (f[1]) return x(c.getElementsByTagName(b), d);
                      if (f[2] && n.find.CLASS && c.getElementsByClassName)
                        return x(c.getElementsByClassName(f[2]), d);
                    }
                    if (9 === c.nodeType) {
                      if ("body" === b && c.body) return x([c.body], d);
                      if (f && f[3]) {
                        var g = c.getElementById(f[3]);
                        if (g && g.parentNode) {
                          if (g.id === f[3]) return x([g], d);
                        } else return x([], d);
                      }
                      try {
                        return x(c.querySelectorAll(b), d);
                      } catch (B) {}
                    } else if (
                      1 === c.nodeType &&
                      "object" !== c.nodeName.toLowerCase()
                    ) {
                      f = c;
                      var h = (g = c.getAttribute("id")) || "__sizzle__",
                        k = c.parentNode,
                        l = /^\s*[+~]/.test(b);
                      g
                        ? (h = h.replace(/'/g, "\\$\x26"))
                        : c.setAttribute("id", h);
                      l && k && (c = c.parentNode);
                      try {
                        if (!l || k)
                          return x(
                            c.querySelectorAll("[id\x3d'" + h + "'] " + b),
                            d
                          );
                      } catch (B) {
                      } finally {
                        g || f.removeAttribute("id");
                      }
                    }
                  }
                  return a(b, c, d, e);
                };
                for (var c in a) m[c] = a[c];
                b = null;
              }
            })();
          (function () {
            var a = q.documentElement,
              b =
                a.matchesSelector ||
                a.mozMatchesSelector ||
                a.webkitMatchesSelector ||
                a.msMatchesSelector;
            if (b) {
              var c = !b.call(q.createElement("div"), "div"),
                d = !1;
              try {
                b.call(q.documentElement, "[test!\x3d'']:sizzle");
              } catch (Q) {
                d = !0;
              }
              m.matchesSelector = function (a, e) {
                e = e.replace(/=\s*([^'"\]]*)\s*\]/g, "\x3d'$1']");
                if (!m.isXML(a))
                  try {
                    if (d || (!n.match.PSEUDO.test(e) && !/!=/.test(e))) {
                      var f = b.call(a, e);
                      if (f || !c || (a.document && 11 !== a.document.nodeType))
                        return f;
                    }
                  } catch (ba) {}
                return 0 < m(e, null, null, [a]).length;
              };
            }
          })();
          (function () {
            var a = q.createElement("div");
            a.innerHTML =
              "\x3cdiv class\x3d'test e'\x3e\x3c/div\x3e\x3cdiv class\x3d'test'\x3e\x3c/div\x3e";
            a.getElementsByClassName &&
              0 !== a.getElementsByClassName("e").length &&
              ((a.lastChild.className = "e"),
              1 !== a.getElementsByClassName("e").length &&
                (n.order.splice(1, 0, "CLASS"),
                (n.find.CLASS = function (a, b, c) {
                  if ("undefined" !== typeof b.getElementsByClassName && !c)
                    return b.getElementsByClassName(a[1]);
                }),
                (a = null)));
          })();
          m.contains = q.documentElement.contains
            ? function (a, b) {
                return a !== b && (a.contains ? a.contains(b) : !0);
              }
            : q.documentElement.compareDocumentPosition
            ? function (a, b) {
                return !!(a.compareDocumentPosition(b) & 16);
              }
            : function () {
                return !1;
              };
          m.isXML = function (a) {
            return (a = (a ? a.ownerDocument || a : 0).documentElement)
              ? "HTML" !== a.nodeName
              : !1;
          };
          var v = function (a, b) {
            var c,
              d = [],
              e = "";
            for (b = b.nodeType ? [b] : b; (c = n.match.PSEUDO.exec(a)); )
              (e += c[0]), (a = a.replace(n.match.PSEUDO, ""));
            a = n.relative[a] ? a + "*" : a;
            c = 0;
            for (var f = b.length; c < f; c++) m(a, b[c], d);
            return m.filter(e, d);
          };
          c.find = m;
          c.expr = m.selectors;
          c.expr[":"] = c.expr.filters;
          c.unique = m.uniqueSort;
          c.text = m.getText;
          c.isXMLDoc = m.isXML;
          c.contains = m.contains;
        })();
        var Eb = /Until$/,
          Fb = /^(?:parents|prevUntil|prevAll)/,
          Gb = /,/,
          lb = /^.[^:#\[\.,]*$/,
          Hb = Array.prototype.slice,
          Ta = c.expr.match.POS,
          Ib = {children: !0, contents: !0, next: !0, prev: !0};
        c.fn.extend({
          find: function (a) {
            var b = this,
              d;
            if ("string" !== typeof a)
              return c(a).filter(function () {
                h = 0;
                for (d = b.length; h < d; h++)
                  if (c.contains(b[h], this)) return !0;
              });
            var e = this.pushStack("", "find", a),
              f,
              g;
            var h = 0;
            for (d = this.length; h < d; h++) {
              var k = e.length;
              c.find(a, this[h], e);
              if (0 < h)
                for (f = k; f < e.length; f++)
                  for (g = 0; g < k; g++)
                    if (e[g] === e[f]) {
                      e.splice(f--, 1);
                      break;
                    }
            }
            return e;
          },
          has: function (a) {
            var b = c(a);
            return this.filter(function () {
              for (var a = 0, e = b.length; a < e; a++)
                if (c.contains(this, b[a])) return !0;
            });
          },
          not: function (a) {
            return this.pushStack(ya(this, a, !1), "not", a);
          },
          filter: function (a) {
            return this.pushStack(ya(this, a, !0), "filter", a);
          },
          is: function (a) {
            return (
              !!a &&
              ("string" === typeof a
                ? 0 < c.filter(a, this).length
                : 0 < this.filter(a).length)
            );
          },
          closest: function (a, b) {
            var d = [],
              e,
              f = this[0];
            if (c.isArray(a)) {
              var g = {},
                h = 1;
              if (f && a.length) {
                var k = 0;
                for (e = a.length; k < e; k++) {
                  var l = a[k];
                  g[l] || (g[l] = Ta.test(l) ? c(l, b || this.context) : l);
                }
                for (; f && f.ownerDocument && f !== b; ) {
                  for (l in g)
                    (a = g[l]),
                      (a.jquery ? -1 < a.index(f) : c(f).is(a)) &&
                        d.push({selector: l, elem: f, level: h});
                  f = f.parentNode;
                  h++;
                }
              }
              return d;
            }
            l =
              Ta.test(a) || "string" !== typeof a ? c(a, b || this.context) : 0;
            k = 0;
            for (e = this.length; k < e; k++)
              for (f = this[k]; f; )
                if (l ? -1 < l.index(f) : c.find.matchesSelector(f, a)) {
                  d.push(f);
                  break;
                } else if (
                  ((f = f.parentNode),
                  !f || !f.ownerDocument || f === b || 11 === f.nodeType)
                )
                  break;
            d = 1 < d.length ? c.unique(d) : d;
            return this.pushStack(d, "closest", a);
          },
          index: function (a) {
            return a
              ? "string" === typeof a
                ? c.inArray(this[0], c(a))
                : c.inArray(a.jquery ? a[0] : a, this)
              : this[0] && this[0].parentNode
              ? this.prevAll().length
              : -1;
          },
          add: function (a, b) {
            a =
              "string" === typeof a
                ? c(a, b)
                : c.makeArray(a && a.nodeType ? [a] : a);
            b = c.merge(this.get(), a);
            return this.pushStack(xa(a[0]) || xa(b[0]) ? b : c.unique(b));
          },
          andSelf: function () {
            return this.add(this.prevObject);
          },
        });
        c.each(
          {
            parent: function (a) {
              return (a = a.parentNode) && 11 !== a.nodeType ? a : null;
            },
            parents: function (a) {
              return c.dir(a, "parentNode");
            },
            parentsUntil: function (a, b, d) {
              return c.dir(a, "parentNode", d);
            },
            next: function (a) {
              return c.nth(a, 2, "nextSibling");
            },
            prev: function (a) {
              return c.nth(a, 2, "previousSibling");
            },
            nextAll: function (a) {
              return c.dir(a, "nextSibling");
            },
            prevAll: function (a) {
              return c.dir(a, "previousSibling");
            },
            nextUntil: function (a, b, d) {
              return c.dir(a, "nextSibling", d);
            },
            prevUntil: function (a, b, d) {
              return c.dir(a, "previousSibling", d);
            },
            siblings: function (a) {
              return c.sibling(a.parentNode.firstChild, a);
            },
            children: function (a) {
              return c.sibling(a.firstChild);
            },
            contents: function (a) {
              return c.nodeName(a, "iframe")
                ? a.contentDocument || a.contentWindow.document
                : c.makeArray(a.childNodes);
            },
          },
          function (a, b) {
            c.fn[a] = function (d, e) {
              var f = c.map(this, b, d),
                g = Hb.call(arguments);
              Eb.test(a) || (e = d);
              e && "string" === typeof e && (f = c.filter(e, f));
              f = 1 < this.length && !Ib[a] ? c.unique(f) : f;
              (1 < this.length || Gb.test(e)) &&
                Fb.test(a) &&
                (f = f.reverse());
              return this.pushStack(f, a, g.join(","));
            };
          }
        );
        c.extend({
          filter: function (a, b, d) {
            d && (a = ":not(" + a + ")");
            return 1 === b.length
              ? c.find.matchesSelector(b[0], a)
                ? [b[0]]
                : []
              : c.find.matches(a, b);
          },
          dir: function (a, b, d) {
            var e = [];
            for (
              a = a[b];
              a &&
              9 !== a.nodeType &&
              (d === p || 1 !== a.nodeType || !c(a).is(d));

            )
              1 === a.nodeType && e.push(a), (a = a[b]);
            return e;
          },
          nth: function (a, b, c, e) {
            b = b || 1;
            for (e = 0; a && (1 !== a.nodeType || ++e !== b); a = a[c]);
            return a;
          },
          sibling: function (a, b) {
            for (var c = []; a; a = a.nextSibling)
              1 === a.nodeType && a !== b && c.push(a);
            return c;
          },
        });
        var Jb = / jQuery\d+="(?:\d+|null)"/g,
          sa = /^\s+/,
          Ua =
            /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
          Va = /<([\w:]+)/,
          Kb = /<tbody/i,
          Lb = /<|&#?\w+;/,
          Wa = /<(?:script|object|embed|option|style)/i,
          Xa = /checked\s*(?:[^=]|=\s*.checked.)/i,
          Mb = /\/(java|ecma)script/i,
          ob = /^\s*<!(?:\[CDATA\[|\-\-)/,
          w = {
            option: [
              1,
              "\x3cselect multiple\x3d'multiple'\x3e",
              "\x3c/select\x3e",
            ],
            legend: [1, "\x3cfieldset\x3e", "\x3c/fieldset\x3e"],
            thead: [1, "\x3ctable\x3e", "\x3c/table\x3e"],
            tr: [
              2,
              "\x3ctable\x3e\x3ctbody\x3e",
              "\x3c/tbody\x3e\x3c/table\x3e",
            ],
            td: [
              3,
              "\x3ctable\x3e\x3ctbody\x3e\x3ctr\x3e",
              "\x3c/tr\x3e\x3c/tbody\x3e\x3c/table\x3e",
            ],
            col: [
              2,
              "\x3ctable\x3e\x3ctbody\x3e\x3c/tbody\x3e\x3ccolgroup\x3e",
              "\x3c/colgroup\x3e\x3c/table\x3e",
            ],
            area: [1, "\x3cmap\x3e", "\x3c/map\x3e"],
            _default: [0, "", ""],
          };
        w.optgroup = w.option;
        w.tbody = w.tfoot = w.colgroup = w.caption = w.thead;
        w.th = w.td;
        c.support.htmlSerialize ||
          (w._default = [1, "div\x3cdiv\x3e", "\x3c/div\x3e"]);
        c.fn.extend({
          text: function (a) {
            return c.isFunction(a)
              ? this.each(function (b) {
                  var d = c(this);
                  d.text(a.call(this, b, d.text()));
                })
              : "object" !== typeof a && a !== p
              ? this.empty().append(
                  ((this[0] && this[0].ownerDocument) || q).createTextNode(a)
                )
              : c.text(this);
          },
          wrapAll: function (a) {
            if (c.isFunction(a))
              return this.each(function (b) {
                c(this).wrapAll(a.call(this, b));
              });
            if (this[0]) {
              var b = c(a, this[0].ownerDocument).eq(0).clone(!0);
              this[0].parentNode && b.insertBefore(this[0]);
              b.map(function () {
                for (
                  var a = this;
                  a.firstChild && 1 === a.firstChild.nodeType;

                )
                  a = a.firstChild;
                return a;
              }).append(this);
            }
            return this;
          },
          wrapInner: function (a) {
            return c.isFunction(a)
              ? this.each(function (b) {
                  c(this).wrapInner(a.call(this, b));
                })
              : this.each(function () {
                  var b = c(this),
                    d = b.contents();
                  d.length ? d.wrapAll(a) : b.append(a);
                });
          },
          wrap: function (a) {
            return this.each(function () {
              c(this).wrapAll(a);
            });
          },
          unwrap: function () {
            return this.parent()
              .each(function () {
                c.nodeName(this, "body") ||
                  c(this).replaceWith(this.childNodes);
              })
              .end();
          },
          append: function () {
            return this.domManip(arguments, !0, function (a) {
              1 === this.nodeType && this.appendChild(a);
            });
          },
          prepend: function () {
            return this.domManip(arguments, !0, function (a) {
              1 === this.nodeType && this.insertBefore(a, this.firstChild);
            });
          },
          before: function () {
            if (this[0] && this[0].parentNode)
              return this.domManip(arguments, !1, function (a) {
                this.parentNode.insertBefore(a, this);
              });
            if (arguments.length) {
              var a = c(arguments[0]);
              a.push.apply(a, this.toArray());
              return this.pushStack(a, "before", arguments);
            }
          },
          after: function () {
            if (this[0] && this[0].parentNode)
              return this.domManip(arguments, !1, function (a) {
                this.parentNode.insertBefore(a, this.nextSibling);
              });
            if (arguments.length) {
              var a = this.pushStack(this, "after", arguments);
              a.push.apply(a, c(arguments[0]).toArray());
              return a;
            }
          },
          remove: function (a, b) {
            for (var d = 0, e; null != (e = this[d]); d++)
              if (!a || c.filter(a, [e]).length)
                b ||
                  1 !== e.nodeType ||
                  (c.cleanData(e.getElementsByTagName("*")), c.cleanData([e])),
                  e.parentNode && e.parentNode.removeChild(e);
            return this;
          },
          empty: function () {
            for (var a = 0, b; null != (b = this[a]); a++)
              for (
                1 === b.nodeType && c.cleanData(b.getElementsByTagName("*"));
                b.firstChild;

              )
                b.removeChild(b.firstChild);
            return this;
          },
          clone: function (a, b) {
            a = null == a ? !1 : a;
            b = null == b ? a : b;
            return this.map(function () {
              return c.clone(this, a, b);
            });
          },
          html: function (a) {
            if (a === p)
              return this[0] && 1 === this[0].nodeType
                ? this[0].innerHTML.replace(Jb, "")
                : null;
            if (
              "string" !== typeof a ||
              Wa.test(a) ||
              (!c.support.leadingWhitespace && sa.test(a)) ||
              w[(Va.exec(a) || ["", ""])[1].toLowerCase()]
            )
              c.isFunction(a)
                ? this.each(function (b) {
                    var d = c(this);
                    d.html(a.call(this, b, d.html()));
                  })
                : this.empty().append(a);
            else {
              a = a.replace(Ua, "\x3c$1\x3e\x3c/$2\x3e");
              try {
                for (var b = 0, d = this.length; b < d; b++)
                  1 === this[b].nodeType &&
                    (c.cleanData(this[b].getElementsByTagName("*")),
                    (this[b].innerHTML = a));
              } catch (e) {
                this.empty().append(a);
              }
            }
            return this;
          },
          replaceWith: function (a) {
            if (this[0] && this[0].parentNode) {
              if (c.isFunction(a))
                return this.each(function (b) {
                  var d = c(this),
                    e = d.html();
                  d.replaceWith(a.call(this, b, e));
                });
              "string" !== typeof a && (a = c(a).detach());
              return this.each(function () {
                var b = this.nextSibling,
                  d = this.parentNode;
                c(this).remove();
                b ? c(b).before(a) : c(d).append(a);
              });
            }
            return this.length
              ? this.pushStack(c(c.isFunction(a) ? a() : a), "replaceWith", a)
              : this;
          },
          detach: function (a) {
            return this.remove(a, !0);
          },
          domManip: function (a, b, d) {
            var e,
              f = a[0],
              g = [];
            if (
              !c.support.checkClone &&
              3 === arguments.length &&
              "string" === typeof f &&
              Xa.test(f)
            )
              return this.each(function () {
                c(this).domManip(a, b, d, !0);
              });
            if (c.isFunction(f))
              return this.each(function (e) {
                var g = c(this);
                a[0] = f.call(this, e, b ? g.html() : p);
                g.domManip(a, b, d);
              });
            if (this[0]) {
              var h = f && f.parentNode;
              h =
                c.support.parentNode &&
                h &&
                11 === h.nodeType &&
                h.childNodes.length === this.length
                  ? {fragment: h}
                  : c.buildFragment(a, this, g);
              var k = h.fragment;
              if (
                (e =
                  1 === k.childNodes.length ? (k = k.firstChild) : k.firstChild)
              ) {
                b = b && c.nodeName(e, "tr");
                for (var l = 0, m = this.length, n = m - 1; l < m; l++)
                  d.call(
                    b ? mb(this[l], e) : this[l],
                    h.cacheable || (1 < m && l < n) ? c.clone(k, !0, !0) : k
                  );
              }
              g.length && c.each(g, nb);
            }
            return this;
          },
        });
        c.buildFragment = function (a, b, d) {
          var e, f, g;
          b && b[0] && (g = b[0].ownerDocument || b[0]);
          g.createDocumentFragment || (g = q);
          if (
            1 === a.length &&
            "string" === typeof a[0] &&
            512 > a[0].length &&
            g === q &&
            "\x3c" === a[0].charAt(0) &&
            !Wa.test(a[0]) &&
            (c.support.checkClone || !Xa.test(a[0]))
          ) {
            var h = !0;
            (f = c.fragments[a[0]]) && 1 !== f && (e = f);
          }
          e || ((e = g.createDocumentFragment()), c.clean(a, g, e, d));
          h && (c.fragments[a[0]] = f ? e : 1);
          return {fragment: e, cacheable: h};
        };
        c.fragments = {};
        c.each(
          {
            appendTo: "append",
            prependTo: "prepend",
            insertBefore: "before",
            insertAfter: "after",
            replaceAll: "replaceWith",
          },
          function (a, b) {
            c.fn[a] = function (d) {
              var e = [];
              d = c(d);
              var f = 1 === this.length && this[0].parentNode;
              if (
                f &&
                11 === f.nodeType &&
                1 === f.childNodes.length &&
                1 === d.length
              )
                return d[b](this[0]), this;
              f = 0;
              for (var g = d.length; f < g; f++) {
                var h = (0 < f ? this.clone(!0) : this).get();
                c(d[f])[b](h);
                e = e.concat(h);
              }
              return this.pushStack(e, a, d.selector);
            };
          }
        );
        c.extend({
          clone: function (a, b, d) {
            var e = a.cloneNode(!0),
              f;
            if (
              !(
                (c.support.noCloneEvent && c.support.noCloneChecked) ||
                (1 !== a.nodeType && 11 !== a.nodeType) ||
                c.isXMLDoc(a)
              )
            ) {
              Aa(a, e);
              var g = Y(a);
              var h = Y(e);
              for (f = 0; g[f]; ++f) h[f] && Aa(g[f], h[f]);
            }
            if (b && (za(a, e), d))
              for (g = Y(a), h = Y(e), f = 0; g[f]; ++f) za(g[f], h[f]);
            return e;
          },
          clean: function (a, b, d, e) {
            b = b || q;
            "undefined" === typeof b.createElement &&
              (b = b.ownerDocument || (b[0] && b[0].ownerDocument) || q);
            for (var f = [], g, h = 0, k; null != (k = a[h]); h++)
              if (("number" === typeof k && (k += ""), k)) {
                if ("string" === typeof k)
                  if (Lb.test(k)) {
                    k = k.replace(Ua, "\x3c$1\x3e\x3c/$2\x3e");
                    g = (Va.exec(k) || ["", ""])[1].toLowerCase();
                    var l = w[g] || w._default,
                      m = l[0],
                      n = b.createElement("div");
                    for (n.innerHTML = l[1] + k + l[2]; m--; ) n = n.lastChild;
                    if (!c.support.tbody)
                      for (
                        m = Kb.test(k),
                          l =
                            "table" !== g || m
                              ? "\x3ctable\x3e" !== l[1] || m
                                ? []
                                : n.childNodes
                              : n.firstChild && n.firstChild.childNodes,
                          g = l.length - 1;
                        0 <= g;
                        --g
                      )
                        c.nodeName(l[g], "tbody") &&
                          !l[g].childNodes.length &&
                          l[g].parentNode.removeChild(l[g]);
                    !c.support.leadingWhitespace &&
                      sa.test(k) &&
                      n.insertBefore(
                        b.createTextNode(sa.exec(k)[0]),
                        n.firstChild
                      );
                    k = n.childNodes;
                  } else k = b.createTextNode(k);
                var p;
                if (!c.support.appendChecked)
                  if (k[0] && "number" === typeof (p = k.length))
                    for (g = 0; g < p; g++) Ca(k[g]);
                  else Ca(k);
                k.nodeType ? f.push(k) : (f = c.merge(f, k));
              }
            if (d)
              for (
                a = function (a) {
                  return !a.type || Mb.test(a.type);
                },
                  h = 0;
                f[h];
                h++
              )
                !e ||
                !c.nodeName(f[h], "script") ||
                (f[h].type && "text/javascript" !== f[h].type.toLowerCase())
                  ? (1 === f[h].nodeType &&
                      ((b = c.grep(f[h].getElementsByTagName("script"), a)),
                      f.splice.apply(f, [h + 1, 0].concat(b))),
                    d.appendChild(f[h]))
                  : e.push(
                      f[h].parentNode ? f[h].parentNode.removeChild(f[h]) : f[h]
                    );
            return f;
          },
          cleanData: function (a) {
            for (
              var b,
                d,
                e = c.cache,
                f = c.expando,
                g = c.event.special,
                h = c.support.deleteExpando,
                k = 0,
                l;
              null != (l = a[k]);
              k++
            )
              if (!l.nodeName || !c.noData[l.nodeName.toLowerCase()])
                if ((d = l[c.expando])) {
                  if ((b = e[d] && e[d][f]) && b.events) {
                    for (var m in b.events)
                      g[m]
                        ? c.event.remove(l, m)
                        : c.removeEvent(l, m, b.handle);
                    b.handle && (b.handle.elem = null);
                  }
                  h
                    ? delete l[c.expando]
                    : l.removeAttribute && l.removeAttribute(c.expando);
                  delete e[d];
                }
          },
        });
        var ta = /alpha\([^)]*\)/i,
          Nb = /opacity=([^)]*)/,
          Ob = /([A-Z]|^ms)/g,
          Ya = /^-?\d+(?:px)?$/i,
          Pb = /^-?\d/,
          Qb = /^([\-+])=([\-+.\de]+)/,
          Rb = {position: "absolute", visibility: "hidden", display: "block"},
          pb = ["Left", "Right"],
          qb = ["Top", "Bottom"],
          Za,
          $a;
        c.fn.css = function (a, b) {
          return 2 === arguments.length && b === p
            ? this
            : c.access(this, a, b, !0, function (a, b, f) {
                return f !== p ? c.style(a, b, f) : c.css(a, b);
              });
        };
        c.extend({
          cssHooks: {
            opacity: {
              get: function (a, b) {
                return b
                  ? ((a = U(a, "opacity", "opacity")), "" === a ? "1" : a)
                  : a.style.opacity;
              },
            },
          },
          cssNumber: {
            fillOpacity: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0,
          },
          cssProps: {float: c.support.cssFloat ? "cssFloat" : "styleFloat"},
          style: function (a, b, d, e) {
            if (a && 3 !== a.nodeType && 8 !== a.nodeType && a.style) {
              var f,
                g = c.camelCase(b),
                h = a.style,
                k = c.cssHooks[g];
              b = c.cssProps[g] || g;
              if (d !== p) {
                if (
                  ((e = typeof d),
                  "string" === e &&
                    (f = Qb.exec(d)) &&
                    ((d = +(f[1] + 1) * +f[2] + parseFloat(c.css(a, b))),
                    (e = "number")),
                  !(
                    null == d ||
                    ("number" === e && isNaN(d)) ||
                    ("number" !== e || c.cssNumber[g] || (d += "px"),
                    k && "set" in k && (d = k.set(a, d)) === p)
                  ))
                )
                  try {
                    h[b] = d;
                  } catch (l) {}
              } else
                return k && "get" in k && (f = k.get(a, !1, e)) !== p
                  ? f
                  : h[b];
            }
          },
          css: function (a, b, d) {
            var e;
            b = c.camelCase(b);
            var f = c.cssHooks[b];
            b = c.cssProps[b] || b;
            "cssFloat" === b && (b = "float");
            if (f && "get" in f && (e = f.get(a, !0, d)) !== p) return e;
            if (U) return U(a, b);
          },
          swap: function (a, b, c) {
            var d = {},
              f;
            for (f in b) (d[f] = a.style[f]), (a.style[f] = b[f]);
            c.call(a);
            for (f in b) a.style[f] = d[f];
          },
        });
        c.curCSS = c.css;
        c.each(["height", "width"], function (a, b) {
          c.cssHooks[b] = {
            get: function (a, e, f) {
              var d;
              if (e) {
                if (0 !== a.offsetWidth) return Da(a, b, f);
                c.swap(a, Rb, function () {
                  d = Da(a, b, f);
                });
                return d;
              }
            },
            set: function (a, b) {
              if (Ya.test(b)) {
                if (((b = parseFloat(b)), 0 <= b)) return b + "px";
              } else return b;
            },
          };
        });
        c.support.opacity ||
          (c.cssHooks.opacity = {
            get: function (a, b) {
              return Nb.test(
                (b && a.currentStyle
                  ? a.currentStyle.filter
                  : a.style.filter) || ""
              )
                ? parseFloat(RegExp.$1) / 100 + ""
                : b
                ? "1"
                : "";
            },
            set: function (a, b) {
              var d = a.style;
              a = a.currentStyle;
              var e = c.isNaN(b) ? "" : "alpha(opacity\x3d" + 100 * b + ")",
                f = (a && a.filter) || d.filter || "";
              d.zoom = 1;
              if (
                1 <= b &&
                "" === c.trim(f.replace(ta, "")) &&
                (d.removeAttribute("filter"), a && !a.filter)
              )
                return;
              d.filter = ta.test(f) ? f.replace(ta, e) : f + " " + e;
            },
          });
        c(function () {
          c.support.reliableMarginRight ||
            (c.cssHooks.marginRight = {
              get: function (a, b) {
                var d;
                c.swap(a, {display: "inline-block"}, function () {
                  d = b
                    ? U(a, "margin-right", "marginRight")
                    : a.style.marginRight;
                });
                return d;
              },
            });
        });
        q.defaultView &&
          q.defaultView.getComputedStyle &&
          (Za = function (a, b) {
            var d;
            b = b.replace(Ob, "-$1").toLowerCase();
            if (!(d = a.ownerDocument.defaultView)) return p;
            if ((d = d.getComputedStyle(a, null))) {
              var e = d.getPropertyValue(b);
              "" !== e ||
                c.contains(a.ownerDocument.documentElement, a) ||
                (e = c.style(a, b));
            }
            return e;
          });
        q.documentElement.currentStyle &&
          ($a = function (a, b) {
            var c = a.currentStyle && a.currentStyle[b],
              e = a.runtimeStyle && a.runtimeStyle[b],
              f = a.style;
            if (!Ya.test(c) && Pb.test(c)) {
              var g = f.left;
              e && (a.runtimeStyle.left = a.currentStyle.left);
              f.left = "fontSize" === b ? "1em" : c || 0;
              c = f.pixelLeft + "px";
              f.left = g;
              e && (a.runtimeStyle.left = e);
            }
            return "" === c ? "auto" : c;
          });
        var U = Za || $a;
        c.expr &&
          c.expr.filters &&
          ((c.expr.filters.hidden = function (a) {
            var b = a.offsetHeight;
            return (
              (0 === a.offsetWidth && 0 === b) ||
              (!c.support.reliableHiddenOffsets &&
                "none" === (a.style.display || c.css(a, "display")))
            );
          }),
          (c.expr.filters.visible = function (a) {
            return !c.expr.filters.hidden(a);
          }));
        var Sb = /%20/g,
          rb = /\[\]$/,
          ab = /\r?\n/g,
          Tb = /#.*$/,
          Ub = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm,
          Vb =
            /^(?:color|date|datetime|datetime-local|email|hidden|month|number|password|range|search|tel|text|time|url|week)$/i,
          Wb = /^(?:GET|HEAD)$/,
          Xb = /^\/\//,
          bb = /\?/,
          Yb = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
          Zb = /^(?:select|textarea)/i,
          Fa = /\s+/,
          $b = /([?&])_=[^&]*/,
          cb = /^([\w\+\.\-]+:)(?:\/\/([^\/?#:]*)(?::(\d+))?)?/,
          db = c.fn.load,
          ja = {},
          eb = {};
        try {
          var I = ub.href;
        } catch (a) {
          (I = q.createElement("a")), (I.href = ""), (I = I.href);
        }
        var P = cb.exec(I.toLowerCase()) || [];
        c.fn.extend({
          load: function (a, b, d) {
            if ("string" !== typeof a && db) return db.apply(this, arguments);
            if (!this.length) return this;
            var e = a.indexOf(" ");
            if (0 <= e) {
              var f = a.slice(e, a.length);
              a = a.slice(0, e);
            }
            e = "GET";
            b &&
              (c.isFunction(b)
                ? ((d = b), (b = p))
                : "object" === typeof b &&
                  ((b = c.param(b, c.ajaxSettings.traditional)), (e = "POST")));
            var g = this;
            c.ajax({
              url: a,
              type: e,
              dataType: "html",
              data: b,
              complete: function (a, b, e) {
                e = a.responseText;
                a.isResolved() &&
                  (a.done(function (a) {
                    e = a;
                  }),
                  g.html(
                    f ? c("\x3cdiv\x3e").append(e.replace(Yb, "")).find(f) : e
                  ));
                d && g.each(d, [e, b, a]);
              },
            });
            return this;
          },
          serialize: function () {
            return c.param(this.serializeArray());
          },
          serializeArray: function () {
            return this.map(function () {
              return this.elements ? c.makeArray(this.elements) : this;
            })
              .filter(function () {
                return (
                  this.name &&
                  !this.disabled &&
                  (this.checked || Zb.test(this.nodeName) || Vb.test(this.type))
                );
              })
              .map(function (a, b) {
                a = c(this).val();
                return null == a
                  ? null
                  : c.isArray(a)
                  ? c.map(a, function (a, c) {
                      return {name: b.name, value: a.replace(ab, "\r\n")};
                    })
                  : {name: b.name, value: a.replace(ab, "\r\n")};
              })
              .get();
          },
        });
        c.each(
          "ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(
            " "
          ),
          function (a, b) {
            c.fn[b] = function (a) {
              return this.bind(b, a);
            };
          }
        );
        c.each(["get", "post"], function (a, b) {
          c[b] = function (a, e, f, g) {
            c.isFunction(e) && ((g = g || f), (f = e), (e = p));
            return c.ajax({type: b, url: a, data: e, success: f, dataType: g});
          };
        });
        c.extend({
          getScript: function (a, b) {
            return c.get(a, p, b, "script");
          },
          getJSON: function (a, b, d) {
            return c.get(a, b, d, "json");
          },
          ajaxSetup: function (a, b) {
            b ? Ga(a, c.ajaxSettings) : ((b = a), (a = c.ajaxSettings));
            Ga(a, b);
            return a;
          },
          ajaxSettings: {
            url: I,
            isLocal:
              /^(?:about|app|app\-storage|.+\-extension|file|res|widget):$/.test(
                P[1]
              ),
            global: !0,
            type: "GET",
            contentType: "application/x-www-form-urlencoded",
            processData: !0,
            async: !0,
            accepts: {
              xml: "application/xml, text/xml",
              html: "text/html",
              text: "text/plain",
              json: "application/json, text/javascript",
              "*": "*/*",
            },
            contents: {xml: /xml/, html: /html/, json: /json/},
            responseFields: {xml: "responseXML", text: "responseText"},
            converters: {
              "* text": r.String,
              "text html": !0,
              "text json": c.parseJSON,
              "text xml": c.parseXML,
            },
            flatOptions: {context: !0, url: !0},
          },
          ajaxPrefilter: Ea(ja),
          ajaxTransport: Ea(eb),
          ajax: function (a, b) {
            function d(a, b, d, m) {
              if (2 !== E) {
                E = 2;
                x && clearTimeout(x);
                w = p;
                q = m || "";
                v.readyState = 0 < a ? 4 : 0;
                m = b;
                if (d) {
                  var n = e,
                    r = v,
                    u = n.contents,
                    z = n.dataTypes,
                    Q = n.responseFields,
                    B,
                    C;
                  for (D in Q) D in d && (r[Q[D]] = d[D]);
                  for (; "*" === z[0]; )
                    z.shift(),
                      B === p &&
                        (B = n.mimeType || r.getResponseHeader("content-type"));
                  if (B)
                    for (D in u)
                      if (u[D] && u[D].test(B)) {
                        z.unshift(D);
                        break;
                      }
                  if (z[0] in d) var A = z[0];
                  else {
                    for (D in d) {
                      if (!z[0] || n.converters[D + " " + z[0]]) {
                        A = D;
                        break;
                      }
                      C || (C = D);
                    }
                    A = A || C;
                  }
                  A ? (A !== z[0] && z.unshift(A), (d = d[A])) : (d = void 0);
                } else d = p;
                if ((200 <= a && 300 > a) || 304 === a) {
                  if (e.ifModified) {
                    if ((B = v.getResponseHeader("Last-Modified")))
                      c.lastModified[y] = B;
                    if ((B = v.getResponseHeader("Etag"))) c.etag[y] = B;
                  }
                  if (304 === a) {
                    m = "notmodified";
                    var G = !0;
                  } else
                    try {
                      B = e;
                      B.dataFilter && (d = B.dataFilter(d, B.dataType));
                      var T = B.dataTypes;
                      var D = {};
                      var F,
                        K,
                        N = T.length,
                        R = T[0];
                      for (F = 1; F < N; F++) {
                        if (1 === F)
                          for (K in B.converters)
                            "string" === typeof K &&
                              (D[K.toLowerCase()] = B.converters[K]);
                        var H = R;
                        R = T[F];
                        if ("*" === R) R = H;
                        else if ("*" !== H && H !== R) {
                          var O = H + " " + R;
                          var S = D[O] || D["* " + R];
                          if (!S) {
                            var J = p;
                            for (I in D) {
                              var L = I.split(" ");
                              if (L[0] === H || "*" === L[0])
                                if ((J = D[L[1] + " " + R])) {
                                  var I = D[I];
                                  !0 === I ? (S = J) : !0 === J && (S = I);
                                  break;
                                }
                            }
                          }
                          S ||
                            J ||
                            c.error(
                              "No conversion from " + O.replace(" ", " to ")
                            );
                          !0 !== S && (d = S ? S(d) : J(I(d)));
                        }
                      }
                      var P = d;
                      m = "success";
                      G = !0;
                    } catch (ac) {
                      m = "parsererror";
                      var M = ac;
                    }
                } else if (((M = m), !m || a)) (m = "error"), 0 > a && (a = 0);
                v.status = a;
                v.statusText = "" + (b || m);
                G ? h.resolveWith(f, [P, m, v]) : h.rejectWith(f, [v, m, M]);
                v.statusCode(l);
                l = p;
                t &&
                  g.trigger("ajax" + (G ? "Success" : "Error"), [
                    v,
                    e,
                    G ? P : M,
                  ]);
                k.resolveWith(f, [v, m]);
                t &&
                  (g.trigger("ajaxComplete", [v, e]),
                  --c.active || c.event.trigger("ajaxStop"));
              }
            }
            "object" === typeof a && ((b = a), (a = p));
            b = b || {};
            var e = c.ajaxSetup({}, b),
              f = e.context || e,
              g = f !== e && (f.nodeType || f instanceof c) ? c(f) : c.event,
              h = c.Deferred(),
              k = c._Deferred(),
              l = e.statusCode || {},
              m = {},
              n = {},
              q,
              r,
              w,
              x,
              E = 0,
              C,
              v = {
                readyState: 0,
                setRequestHeader: function (a, b) {
                  if (!E) {
                    var c = a.toLowerCase();
                    a = n[c] = n[c] || a;
                    m[a] = b;
                  }
                  return this;
                },
                getAllResponseHeaders: function () {
                  return 2 === E ? q : null;
                },
                getResponseHeader: function (a) {
                  var b;
                  if (2 === E) {
                    if (!r)
                      for (r = {}; (b = Ub.exec(q)); )
                        r[b[1].toLowerCase()] = b[2];
                    b = r[a.toLowerCase()];
                  }
                  return b === p ? null : b;
                },
                overrideMimeType: function (a) {
                  E || (e.mimeType = a);
                  return this;
                },
                abort: function (a) {
                  a = a || "abort";
                  w && w.abort(a);
                  d(0, a);
                  return this;
                },
              };
            h.promise(v);
            v.success = v.done;
            v.error = v.fail;
            v.complete = k.done;
            v.statusCode = function (a) {
              if (a)
                if (2 > E) for (b in a) l[b] = [l[b], a[b]];
                else {
                  var b = a[v.status];
                  v.then(b, b);
                }
              return this;
            };
            e.url = ((a || e.url) + "")
              .replace(Tb, "")
              .replace(Xb, P[1] + "//");
            e.dataTypes = c
              .trim(e.dataType || "*")
              .toLowerCase()
              .split(Fa);
            null == e.crossDomain &&
              ((a = cb.exec(e.url.toLowerCase())),
              (e.crossDomain = !(
                !a ||
                (a[1] == P[1] &&
                  a[2] == P[2] &&
                  (a[3] || ("http:" === a[1] ? 80 : 443)) ==
                    (P[3] || ("http:" === P[1] ? 80 : 443)))
              )));
            e.data &&
              e.processData &&
              "string" !== typeof e.data &&
              (e.data = c.param(e.data, e.traditional));
            Z(ja, e, b, v);
            if (2 === E) return !1;
            var t = e.global;
            e.type = e.type.toUpperCase();
            e.hasContent = !Wb.test(e.type);
            t && 0 === c.active++ && c.event.trigger("ajaxStart");
            if (!e.hasContent) {
              e.data &&
                ((e.url += (bb.test(e.url) ? "\x26" : "?") + e.data),
                delete e.data);
              var y = e.url;
              if (!1 === e.cache) {
                a = c.now();
                var A = e.url.replace($b, "$1_\x3d" + a);
                e.url =
                  A +
                  (A === e.url
                    ? (bb.test(e.url) ? "\x26" : "?") + "_\x3d" + a
                    : "");
              }
            }
            ((e.data && e.hasContent && !1 !== e.contentType) ||
              b.contentType) &&
              v.setRequestHeader("Content-Type", e.contentType);
            e.ifModified &&
              ((y = y || e.url),
              c.lastModified[y] &&
                v.setRequestHeader("If-Modified-Since", c.lastModified[y]),
              c.etag[y] && v.setRequestHeader("If-None-Match", c.etag[y]));
            v.setRequestHeader(
              "Accept",
              e.dataTypes[0] && e.accepts[e.dataTypes[0]]
                ? e.accepts[e.dataTypes[0]] +
                    ("*" !== e.dataTypes[0] ? ", */*; q\x3d0.01" : "")
                : e.accepts["*"]
            );
            for (C in e.headers) v.setRequestHeader(C, e.headers[C]);
            if (e.beforeSend && (!1 === e.beforeSend.call(f, v, e) || 2 === E))
              return v.abort(), !1;
            for (C in {success: 1, error: 1, complete: 1}) v[C](e[C]);
            if ((w = Z(eb, e, b, v))) {
              v.readyState = 1;
              t && g.trigger("ajaxSend", [v, e]);
              e.async &&
                0 < e.timeout &&
                (x = setTimeout(function () {
                  v.abort("timeout");
                }, e.timeout));
              try {
                (E = 1), w.send(m, d);
              } catch (u) {
                2 > E ? d(-1, u) : c.error(u);
              }
            } else d(-1, "No Transport");
            return v;
          },
          param: function (a, b) {
            var d = [],
              e = function (a, b) {
                b = c.isFunction(b) ? b() : b;
                d[d.length] =
                  encodeURIComponent(a) + "\x3d" + encodeURIComponent(b);
              };
            b === p && (b = c.ajaxSettings.traditional);
            if (c.isArray(a) || (a.jquery && !c.isPlainObject(a)))
              c.each(a, function () {
                e(this.name, this.value);
              });
            else for (var f in a) ka(f, a[f], b, e);
            return d.join("\x26").replace(Sb, "+");
          },
        });
        c.extend({active: 0, lastModified: {}, etag: {}});
        var bc = c.now(),
          ea = /(=)\?(&|$)|\?\?/i;
        c.ajaxSetup({
          jsonp: "callback",
          jsonpCallback: function () {
            return c.expando + "_" + bc++;
          },
        });
        c.ajaxPrefilter("json jsonp", function (a, b, d) {
          b =
            "application/x-www-form-urlencoded" === a.contentType &&
            "string" === typeof a.data;
          if (
            "jsonp" === a.dataTypes[0] ||
            (!1 !== a.jsonp && (ea.test(a.url) || (b && ea.test(a.data))))
          ) {
            var e,
              f = (a.jsonpCallback = c.isFunction(a.jsonpCallback)
                ? a.jsonpCallback()
                : a.jsonpCallback),
              g = r[f],
              h = a.url,
              k = a.data,
              l = "$1" + f + "$2";
            !1 !== a.jsonp &&
              ((h = h.replace(ea, l)),
              a.url === h &&
                (b && (k = k.replace(ea, l)),
                a.data === k &&
                  (h += (/\?/.test(h) ? "\x26" : "?") + a.jsonp + "\x3d" + f)));
            a.url = h;
            a.data = k;
            r[f] = function (a) {
              e = [a];
            };
            d.always(function () {
              r[f] = g;
              if (e && c.isFunction(g)) r[f](e[0]);
            });
            a.converters["script json"] = function () {
              e || c.error(f + " was not called");
              return e[0];
            };
            a.dataTypes[0] = "json";
            return "script";
          }
        });
        c.ajaxSetup({
          accepts: {
            script:
              "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript",
          },
          contents: {script: /javascript|ecmascript/},
          converters: {
            "text script": function (a) {
              c.globalEval(a);
              return a;
            },
          },
        });
        c.ajaxPrefilter("script", function (a) {
          a.cache === p && (a.cache = !1);
          a.crossDomain && ((a.type = "GET"), (a.global = !1));
        });
        c.ajaxTransport("script", function (a) {
          if (a.crossDomain) {
            var b,
              c =
                q.head ||
                q.getElementsByTagName("head")[0] ||
                q.documentElement;
            return {
              send: function (d, f) {
                b = q.createElement("script");
                b.async = "async";
                a.scriptCharset && (b.charset = a.scriptCharset);
                b.src = a.url;
                b.onload = b.onreadystatechange = function (a, d) {
                  if (
                    d ||
                    !b.readyState ||
                    /loaded|complete/.test(b.readyState)
                  )
                    (b.onload = b.onreadystatechange = null),
                      c && b.parentNode && c.removeChild(b),
                      (b = p),
                      d || f(200, "success");
                };
                c.insertBefore(b, c.firstChild);
              },
              abort: function () {
                if (b) b.onload(0, 1);
              },
            };
          }
        });
        var ua = r.ActiveXObject
            ? function () {
                for (var a in M) M[a](0, 1);
              }
            : !1,
          cc = 0,
          M;
        c.ajaxSettings.xhr = r.ActiveXObject
          ? function () {
              var a;
              if (!(a = !this.isLocal && Ha()))
                a: {
                  try {
                    a = new r.ActiveXObject("Microsoft.XMLHTTP");
                    break a;
                  } catch (b) {}
                  a = void 0;
                }
              return a;
            }
          : Ha;
        (function (a) {
          c.extend(c.support, {ajax: !!a, cors: !!a && "withCredentials" in a});
        })(c.ajaxSettings.xhr());
        c.support.ajax &&
          c.ajaxTransport(function (a) {
            if (!a.crossDomain || c.support.cors) {
              var b;
              return {
                send: function (d, e) {
                  var f = a.xhr(),
                    g;
                  a.username
                    ? f.open(a.type, a.url, a.async, a.username, a.password)
                    : f.open(a.type, a.url, a.async);
                  if (a.xhrFields) for (g in a.xhrFields) f[g] = a.xhrFields[g];
                  a.mimeType &&
                    f.overrideMimeType &&
                    f.overrideMimeType(a.mimeType);
                  a.crossDomain ||
                    d["X-Requested-With"] ||
                    (d["X-Requested-With"] = "XMLHttpRequest");
                  try {
                    for (g in d) f.setRequestHeader(g, d[g]);
                  } catch (k) {}
                  f.send((a.hasContent && a.data) || null);
                  b = function (d, g) {
                    var k;
                    try {
                      if (b && (g || 4 === f.readyState))
                        if (
                          ((b = p),
                          h &&
                            ((f.onreadystatechange = c.noop),
                            ua && delete M[h]),
                          g)
                        )
                          4 !== f.readyState && f.abort();
                        else {
                          var l = f.status;
                          var q = f.getAllResponseHeaders();
                          var r = {};
                          (k = f.responseXML) &&
                            k.documentElement &&
                            (r.xml = k);
                          r.text = f.responseText;
                          try {
                            var w = f.statusText;
                          } catch (x) {
                            w = "";
                          }
                          l || !a.isLocal || a.crossDomain
                            ? 1223 === l && (l = 204)
                            : (l = r.text ? 200 : 404);
                        }
                    } catch (x) {
                      g || e(-1, x);
                    }
                    r && e(l, w, r, q);
                  };
                  if (a.async && 4 !== f.readyState) {
                    var h = ++cc;
                    ua && (M || ((M = {}), c(r).unload(ua)), (M[h] = b));
                    f.onreadystatechange = b;
                  } else b();
                },
                abort: function () {
                  b && b(0, 1);
                },
              };
            }
          });
        var la = {},
          F,
          J,
          dc = /^(?:toggle|show|hide)$/,
          ec = /^([+\-]=)?([\d+.\-]+)([a-z%]*)$/i,
          fa,
          Ja = [
            [
              "height",
              "marginTop",
              "marginBottom",
              "paddingTop",
              "paddingBottom",
            ],
            [
              "width",
              "marginLeft",
              "marginRight",
              "paddingLeft",
              "paddingRight",
            ],
            ["opacity"],
          ],
          aa;
        c.fn.extend({
          show: function (a, b, d) {
            if (a || 0 === a) return this.animate(O("show", 3), a, b, d);
            d = 0;
            for (var e = this.length; d < e; d++)
              (a = this[d]),
                a.style &&
                  ((b = a.style.display),
                  c._data(a, "olddisplay") ||
                    "none" !== b ||
                    (b = a.style.display = ""),
                  "" === b &&
                    "none" === c.css(a, "display") &&
                    c._data(a, "olddisplay", Ka(a.nodeName)));
            for (d = 0; d < e; d++)
              if (
                ((a = this[d]),
                a.style && ((b = a.style.display), "" === b || "none" === b))
              )
                a.style.display = c._data(a, "olddisplay") || "";
            return this;
          },
          hide: function (a, b, d) {
            if (a || 0 === a) return this.animate(O("hide", 3), a, b, d);
            a = 0;
            for (b = this.length; a < b; a++)
              this[a].style &&
                ((d = c.css(this[a], "display")),
                "none" === d ||
                  c._data(this[a], "olddisplay") ||
                  c._data(this[a], "olddisplay", d));
            for (a = 0; a < b; a++)
              this[a].style && (this[a].style.display = "none");
            return this;
          },
          _toggle: c.fn.toggle,
          toggle: function (a, b, d) {
            var e = "boolean" === typeof a;
            c.isFunction(a) && c.isFunction(b)
              ? this._toggle.apply(this, arguments)
              : null == a || e
              ? this.each(function () {
                  var b = e ? a : c(this).is(":hidden");
                  c(this)[b ? "show" : "hide"]();
                })
              : this.animate(O("toggle", 3), a, b, d);
            return this;
          },
          fadeTo: function (a, b, c, e) {
            return this.filter(":hidden")
              .css("opacity", 0)
              .show()
              .end()
              .animate({opacity: b}, a, c, e);
          },
          animate: function (a, b, d, e) {
            var f = c.speed(b, d, e);
            if (c.isEmptyObject(a)) return this.each(f.complete, [!1]);
            a = c.extend({}, a);
            return this[!1 === f.queue ? "each" : "queue"](function () {
              !1 === f.queue && c._mark(this);
              var b = c.extend({}, f),
                d = 1 === this.nodeType,
                e = d && c(this).is(":hidden"),
                l;
              b.animatedProperties = {};
              for (l in a) {
                var m = c.camelCase(l);
                l !== m && ((a[m] = a[l]), delete a[l]);
                var n = a[m];
                c.isArray(n)
                  ? ((b.animatedProperties[m] = n[1]), (n = a[m] = n[0]))
                  : (b.animatedProperties[m] =
                      (b.specialEasing && b.specialEasing[m]) ||
                      b.easing ||
                      "swing");
                if (("hide" === n && e) || ("show" === n && !e))
                  return b.complete.call(this);
                !d ||
                  ("height" !== m && "width" !== m) ||
                  ((b.overflow = [
                    this.style.overflow,
                    this.style.overflowX,
                    this.style.overflowY,
                  ]),
                  "inline" === c.css(this, "display") &&
                    "none" === c.css(this, "float") &&
                    (c.support.inlineBlockNeedsLayout
                      ? ((n = Ka(this.nodeName)),
                        "inline" === n
                          ? (this.style.display = "inline-block")
                          : ((this.style.display = "inline"),
                            (this.style.zoom = 1)))
                      : (this.style.display = "inline-block")));
              }
              null != b.overflow && (this.style.overflow = "hidden");
              for (l in a)
                if (((d = new c.fx(this, b, l)), (n = a[l]), dc.test(n)))
                  d["toggle" === n ? (e ? "show" : "hide") : n]();
                else {
                  m = ec.exec(n);
                  var q = d.cur();
                  if (m) {
                    n = parseFloat(m[2]);
                    var p = m[3] || (c.cssNumber[l] ? "" : "px");
                    "px" !== p &&
                      (c.style(this, l, (n || 1) + p),
                      (q *= (n || 1) / d.cur()),
                      c.style(this, l, q + p));
                    m[1] && (n = ("-\x3d" === m[1] ? -1 : 1) * n + q);
                    d.custom(q, n, p);
                  } else d.custom(q, n, "");
                }
              return !0;
            });
          },
          stop: function (a, b) {
            a && this.queue([]);
            this.each(function () {
              var a = c.timers,
                e = a.length;
              for (b || c._unmark(!0, this); e--; )
                if (a[e].elem === this) {
                  if (b) a[e](!0);
                  a.splice(e, 1);
                }
            });
            b || this.dequeue();
            return this;
          },
        });
        c.each(
          {
            slideDown: O("show", 1),
            slideUp: O("hide", 1),
            slideToggle: O("toggle", 1),
            fadeIn: {opacity: "show"},
            fadeOut: {opacity: "hide"},
            fadeToggle: {opacity: "toggle"},
          },
          function (a, b) {
            c.fn[a] = function (a, c, f) {
              return this.animate(b, a, c, f);
            };
          }
        );
        c.extend({
          speed: function (a, b, d) {
            var e =
              a && "object" === typeof a
                ? c.extend({}, a)
                : {
                    complete: d || (!d && b) || (c.isFunction(a) && a),
                    duration: a,
                    easing: (d && b) || (b && !c.isFunction(b) && b),
                  };
            e.duration = c.fx.off
              ? 0
              : "number" === typeof e.duration
              ? e.duration
              : e.duration in c.fx.speeds
              ? c.fx.speeds[e.duration]
              : c.fx.speeds._default;
            e.old = e.complete;
            e.complete = function (a) {
              c.isFunction(e.old) && e.old.call(this);
              !1 !== e.queue ? c.dequeue(this) : !1 !== a && c._unmark(this);
            };
            return e;
          },
          easing: {
            linear: function (a, b, c, e) {
              return c + e * a;
            },
            swing: function (a, b, c, e) {
              return (-Math.cos(a * Math.PI) / 2 + 0.5) * e + c;
            },
          },
          timers: [],
          fx: function (a, b, c) {
            this.options = b;
            this.elem = a;
            this.prop = c;
            b.orig = b.orig || {};
          },
        });
        c.fx.prototype = {
          update: function () {
            this.options.step &&
              this.options.step.call(this.elem, this.now, this);
            (c.fx.step[this.prop] || c.fx.step._default)(this);
          },
          cur: function () {
            if (
              null != this.elem[this.prop] &&
              (!this.elem.style || null == this.elem.style[this.prop])
            )
              return this.elem[this.prop];
            var a,
              b = c.css(this.elem, this.prop);
            return isNaN((a = parseFloat(b))) ? (b && "auto" !== b ? b : 0) : a;
          },
          custom: function (a, b, d) {
            function e(a) {
              return f.step(a);
            }
            var f = this,
              g = c.fx;
            this.startTime = aa || Ia();
            this.start = a;
            this.end = b;
            this.unit = d || this.unit || (c.cssNumber[this.prop] ? "" : "px");
            this.now = this.start;
            this.pos = this.state = 0;
            e.elem = this.elem;
            e() &&
              c.timers.push(e) &&
              !fa &&
              (fa = setInterval(g.tick, g.interval));
          },
          show: function () {
            this.options.orig[this.prop] = c.style(this.elem, this.prop);
            this.options.show = !0;
            this.custom(
              "width" === this.prop || "height" === this.prop ? 1 : 0,
              this.cur()
            );
            c(this.elem).show();
          },
          hide: function () {
            this.options.orig[this.prop] = c.style(this.elem, this.prop);
            this.options.hide = !0;
            this.custom(this.cur(), 0);
          },
          step: function (a) {
            var b = aa || Ia(),
              d = !0,
              e = this.elem,
              f = this.options,
              g;
            if (a || b >= f.duration + this.startTime) {
              this.now = this.end;
              this.pos = this.state = 1;
              this.update();
              f.animatedProperties[this.prop] = !0;
              for (g in f.animatedProperties)
                !0 !== f.animatedProperties[g] && (d = !1);
              if (d) {
                null == f.overflow ||
                  c.support.shrinkWrapBlocks ||
                  c.each(["", "X", "Y"], function (a, b) {
                    e.style["overflow" + b] = f.overflow[a];
                  });
                f.hide && c(e).hide();
                if (f.hide || f.show)
                  for (var h in f.animatedProperties) c.style(e, h, f.orig[h]);
                f.complete.call(e);
              }
              return !1;
            }
            Infinity == f.duration
              ? (this.now = b)
              : ((a = b - this.startTime),
                (this.state = a / f.duration),
                (this.pos = c.easing[f.animatedProperties[this.prop]](
                  this.state,
                  a,
                  0,
                  1,
                  f.duration
                )),
                (this.now = this.start + (this.end - this.start) * this.pos));
            this.update();
            return !0;
          },
        };
        c.extend(c.fx, {
          tick: function () {
            for (var a = c.timers, b = 0; b < a.length; ++b)
              a[b]() || a.splice(b--, 1);
            a.length || c.fx.stop();
          },
          interval: 13,
          stop: function () {
            clearInterval(fa);
            fa = null;
          },
          speeds: {slow: 600, fast: 200, _default: 400},
          step: {
            opacity: function (a) {
              c.style(a.elem, "opacity", a.now);
            },
            _default: function (a) {
              a.elem.style && null != a.elem.style[a.prop]
                ? (a.elem.style[a.prop] =
                    ("width" === a.prop || "height" === a.prop
                      ? Math.max(0, a.now)
                      : a.now) + a.unit)
                : (a.elem[a.prop] = a.now);
            },
          },
        });
        c.expr &&
          c.expr.filters &&
          (c.expr.filters.animated = function (a) {
            return c.grep(c.timers, function (b) {
              return a === b.elem;
            }).length;
          });
        var fc = /^t(?:able|d|h)$/i,
          fb = /^(?:body|html)$/i;
        c.fn.offset =
          "getBoundingClientRect" in q.documentElement
            ? function (a) {
                var b = this[0];
                if (a)
                  return this.each(function (b) {
                    c.offset.setOffset(this, a, b);
                  });
                if (!b || !b.ownerDocument) return null;
                if (b === b.ownerDocument.body) return c.offset.bodyOffset(b);
                try {
                  var d = b.getBoundingClientRect();
                } catch (g) {}
                var e = b.ownerDocument,
                  f = e.documentElement;
                if (!d || !c.contains(f, b))
                  return d ? {top: d.top, left: d.left} : {top: 0, left: 0};
                b = e.body;
                e = ma(e);
                return {
                  top:
                    d.top +
                    (e.pageYOffset ||
                      (c.support.boxModel && f.scrollTop) ||
                      b.scrollTop) -
                    (f.clientTop || b.clientTop || 0),
                  left:
                    d.left +
                    (e.pageXOffset ||
                      (c.support.boxModel && f.scrollLeft) ||
                      b.scrollLeft) -
                    (f.clientLeft || b.clientLeft || 0),
                };
              }
            : function (a) {
                var b = this[0];
                if (a)
                  return this.each(function (b) {
                    c.offset.setOffset(this, a, b);
                  });
                if (!b || !b.ownerDocument) return null;
                if (b === b.ownerDocument.body) return c.offset.bodyOffset(b);
                c.offset.initialize();
                var d = b.offsetParent,
                  e = b.ownerDocument,
                  f = e.documentElement,
                  g = e.body;
                var h = (e = e.defaultView)
                  ? e.getComputedStyle(b, null)
                  : b.currentStyle;
                for (
                  var k = b.offsetTop, l = b.offsetLeft;
                  (b = b.parentNode) &&
                  b !== g &&
                  b !== f &&
                  (!c.offset.supportsFixedPosition || "fixed" !== h.position);

                )
                  (h = e ? e.getComputedStyle(b, null) : b.currentStyle),
                    (k -= b.scrollTop),
                    (l -= b.scrollLeft),
                    b === d &&
                      ((k += b.offsetTop),
                      (l += b.offsetLeft),
                      !c.offset.doesNotAddBorder ||
                        (c.offset.doesAddBorderForTableAndCells &&
                          fc.test(b.nodeName)) ||
                        ((k += parseFloat(h.borderTopWidth) || 0),
                        (l += parseFloat(h.borderLeftWidth) || 0)),
                      (d = b.offsetParent)),
                    c.offset.subtractsBorderForOverflowNotVisible &&
                      "visible" !== h.overflow &&
                      ((k += parseFloat(h.borderTopWidth) || 0),
                      (l += parseFloat(h.borderLeftWidth) || 0));
                if ("relative" === h.position || "static" === h.position)
                  (k += g.offsetTop), (l += g.offsetLeft);
                c.offset.supportsFixedPosition &&
                  "fixed" === h.position &&
                  ((k += Math.max(f.scrollTop, g.scrollTop)),
                  (l += Math.max(f.scrollLeft, g.scrollLeft)));
                return {top: k, left: l};
              };
        c.offset = {
          initialize: function () {
            var a = q.body,
              b = q.createElement("div"),
              d = parseFloat(c.css(a, "marginTop")) || 0;
            c.extend(b.style, {
              position: "absolute",
              top: 0,
              left: 0,
              margin: 0,
              border: 0,
              width: "1px",
              height: "1px",
              visibility: "hidden",
            });
            b.innerHTML =
              "\x3cdiv style\x3d'position:absolute;top:0;left:0;margin:0;border:5px solid #000;padding:0;width:1px;height:1px;'\x3e\x3cdiv\x3e\x3c/div\x3e\x3c/div\x3e\x3ctable style\x3d'position:absolute;top:0;left:0;margin:0;border:5px solid #000;padding:0;width:1px;height:1px;' cellpadding\x3d'0' cellspacing\x3d'0'\x3e\x3ctr\x3e\x3ctd\x3e\x3c/td\x3e\x3c/tr\x3e\x3c/table\x3e";
            a.insertBefore(b, a.firstChild);
            var e = b.firstChild;
            var f = e.firstChild;
            var g = e.nextSibling.firstChild.firstChild;
            this.doesNotAddBorder = 5 !== f.offsetTop;
            this.doesAddBorderForTableAndCells = 5 === g.offsetTop;
            f.style.position = "fixed";
            f.style.top = "20px";
            this.supportsFixedPosition =
              20 === f.offsetTop || 15 === f.offsetTop;
            f.style.position = f.style.top = "";
            e.style.overflow = "hidden";
            e.style.position = "relative";
            this.subtractsBorderForOverflowNotVisible = -5 === f.offsetTop;
            this.doesNotIncludeMarginInBodyOffset = a.offsetTop !== d;
            a.removeChild(b);
            c.offset.initialize = c.noop;
          },
          bodyOffset: function (a) {
            var b = a.offsetTop,
              d = a.offsetLeft;
            c.offset.initialize();
            c.offset.doesNotIncludeMarginInBodyOffset &&
              ((b += parseFloat(c.css(a, "marginTop")) || 0),
              (d += parseFloat(c.css(a, "marginLeft")) || 0));
            return {top: b, left: d};
          },
          setOffset: function (a, b, d) {
            var e = c.css(a, "position");
            "static" === e && (a.style.position = "relative");
            var f = c(a),
              g = f.offset(),
              h = c.css(a, "top"),
              k = c.css(a, "left"),
              l = {};
            ("absolute" === e || "fixed" === e) &&
            -1 < c.inArray("auto", [h, k])
              ? ((k = f.position()), (e = k.top), (k = k.left))
              : ((e = parseFloat(h) || 0), (k = parseFloat(k) || 0));
            c.isFunction(b) && (b = b.call(a, d, g));
            null != b.top && (l.top = b.top - g.top + e);
            null != b.left && (l.left = b.left - g.left + k);
            "using" in b ? b.using.call(a, l) : f.css(l);
          },
        };
        c.fn.extend({
          position: function () {
            if (!this[0]) return null;
            var a = this[0],
              b = this.offsetParent(),
              d = this.offset(),
              e = fb.test(b[0].nodeName) ? {top: 0, left: 0} : b.offset();
            d.top -= parseFloat(c.css(a, "marginTop")) || 0;
            d.left -= parseFloat(c.css(a, "marginLeft")) || 0;
            e.top += parseFloat(c.css(b[0], "borderTopWidth")) || 0;
            e.left += parseFloat(c.css(b[0], "borderLeftWidth")) || 0;
            return {top: d.top - e.top, left: d.left - e.left};
          },
          offsetParent: function () {
            return this.map(function () {
              for (
                var a = this.offsetParent || q.body;
                a && !fb.test(a.nodeName) && "static" === c.css(a, "position");

              )
                a = a.offsetParent;
              return a;
            });
          },
        });
        c.each(["Left", "Top"], function (a, b) {
          var d = "scroll" + b;
          c.fn[d] = function (b) {
            var e;
            if (b === p) {
              var g = this[0];
              return g
                ? (e = ma(g))
                  ? "pageXOffset" in e
                    ? e[a ? "pageYOffset" : "pageXOffset"]
                    : (c.support.boxModel && e.document.documentElement[d]) ||
                      e.document.body[d]
                  : g[d]
                : null;
            }
            return this.each(function () {
              (e = ma(this))
                ? e.scrollTo(
                    a ? c(e).scrollLeft() : b,
                    a ? b : c(e).scrollTop()
                  )
                : (this[d] = b);
            });
          };
        });
        c.each(["Height", "Width"], function (a, b) {
          var d = b.toLowerCase();
          c.fn["inner" + b] = function () {
            var a = this[0];
            return a && a.style ? parseFloat(c.css(a, d, "padding")) : null;
          };
          c.fn["outer" + b] = function (a) {
            var b = this[0];
            return b && b.style
              ? parseFloat(c.css(b, d, a ? "margin" : "border"))
              : null;
          };
          c.fn[d] = function (a) {
            var e = this[0];
            if (!e) return null == a ? null : this;
            if (c.isFunction(a))
              return this.each(function (b) {
                var e = c(this);
                e[d](a.call(this, b, e[d]()));
              });
            if (c.isWindow(e)) {
              var g = e.document.documentElement["client" + b];
              e = e.document.body;
              return (c.support.boxModel && g) || (e && e["client" + b]) || g;
            }
            return 9 === e.nodeType
              ? Math.max(
                  e.documentElement["client" + b],
                  e.body["scroll" + b],
                  e.documentElement["scroll" + b],
                  e.body["offset" + b],
                  e.documentElement["offset" + b]
                )
              : a === p
              ? ((g = c.css(e, d)), (e = parseFloat(g)), c.isNaN(e) ? g : e)
              : this.css(d, "string" === typeof a ? a : a + "px");
          };
        });
        (function () {
          c.find.error = function (a) {
            throw Error("Syntax error, unrecognized expression: " + a);
          };
          c.error = function (a) {
            throw "object" === typeof a ? a : Error(a);
          };
        })();
        (function () {
          var a = c._Deferred;
          c._Deferred = function () {
            var b = a(),
              c = b.done;
            b.done = function () {
              for (var a = Array(arguments.length), b = 0; b < a.length; b++) {
                var d = b;
                var h = arguments[b];
                h =
                  "function" === typeof h &&
                  "function" === typeof N.guardCurrent
                    ? N.guardCurrent(h)
                    : h;
                a[d] = h;
              }
              return c.apply(this, a);
            };
            return b;
          };
        })();
        (function () {
          var a;
          c.event.special.beforeunload = {
            setup: function (b, d, e) {
              a = this.onbeforeunload;
              c.isWindow(this) &&
                (this.onbeforeunload = function () {
                  var b = !1;
                  try {
                    b = c.isFunction(a);
                  } catch (g) {}
                  b && a.apply(this, arguments);
                  e.apply(this, arguments);
                });
            },
            teardown: function (b, c) {
              this.onbeforeunload = a;
            },
          };
        })();
        return c;
      })()
    );
  N.when("jQuery").execute("rtl-jquery-plugin", function (p) {
    p.withoutRtl = function (p) {
      p.apply(this);
    };
  });
});
/* ******** */
(function (f) {
  var g = window.AmazonUIPageJS || window.P,
    l = g._namespace || g.attributeErrors,
    e = l ? l("AmazonUIPromise", "AmazonUI") : g;
  e.guardFatal
    ? e.guardFatal(f)(e, window)
    : e.execute(function () {
        f(e, window);
      });
})(function (f, g, l) {
  f.register("3p-promise", function () {
    function e() {}
    function f(a, b) {
      return function () {
        a.apply(b, arguments);
      };
    }
    function d(a) {
      if ("object" !== typeof this)
        throw new TypeError("Promises must be constructed via new");
      if ("function" !== typeof a) throw new TypeError("not a function");
      this._state = 0;
      this._handled = !1;
      this._value = l;
      this._deferreds = [];
      q(a, this);
    }
    function r(a, b) {
      for (; 3 === a._state; ) a = a._value;
      0 === a._state
        ? a._deferreds.push(b)
        : ((a._handled = !0),
          m(function () {
            var c = 1 === a._state ? b.onFulfilled : b.onRejected;
            if (null === c) (1 === a._state ? n : k)(b.promise, a._value);
            else {
              try {
                var h = c(a._value);
              } catch (u) {
                k(b.promise, u);
                return;
              }
              n(b.promise, h);
            }
          }));
    }
    function n(a, b) {
      try {
        if (b === a)
          throw new TypeError("A promise cannot be resolved with itself.");
        if (b && ("object" === typeof b || "function" === typeof b)) {
          var c = b.then;
          if (b instanceof d) {
            a._state = 3;
            a._value = b;
            p(a);
            return;
          }
          if ("function" === typeof c) {
            q(f(c, b), a);
            return;
          }
        }
        a._state = 1;
        a._value = b;
        p(a);
      } catch (h) {
        k(a, h);
      }
    }
    function k(a, b) {
      a._state = 2;
      a._value = b;
      p(a);
    }
    function p(a) {
      2 === a._state &&
        0 === a._deferreds.length &&
        m(function () {
          a._handled || t(a._value);
        });
      for (var b = 0, c = a._deferreds.length; b < c; b++)
        r(a, a._deferreds[b]);
      a._deferreds = null;
    }
    function v(a, b, c) {
      this.onFulfilled = "function" === typeof a ? a : null;
      this.onRejected = "function" === typeof b ? b : null;
      this.promise = c;
    }
    function q(a, b) {
      var c = !1;
      try {
        a(
          function (a) {
            c || ((c = !0), n(b, a));
          },
          function (a) {
            c || ((c = !0), k(b, a));
          }
        );
      } catch (h) {
        c || ((c = !0), k(b, h));
      }
    }
    if ("function" === typeof g.Promise) return g.Promise;
    var w = setTimeout,
      m =
        ("function" === typeof setImmediate && setImmediate) ||
        function (a) {
          w(a, 0);
        },
      t = function (a) {
        "undefined" !== typeof console &&
          console &&
          console.warn("Possible Unhandled Promise Rejection:", a);
      };
    d.prototype["catch"] = function (a) {
      return this.then(null, a);
    };
    d.prototype.then = function (a, b) {
      var c = new this.constructor(e);
      r(this, new v(a, b, c));
      return c;
    };
    d.all = function (a) {
      var b = Array.prototype.slice.call(a);
      return new d(function (a, d) {
        function c(e, f) {
          try {
            if (f && ("object" === typeof f || "function" === typeof f)) {
              var g = f.then;
              if ("function" === typeof g) {
                g.call(
                  f,
                  function (a) {
                    c(e, a);
                  },
                  d
                );
                return;
              }
            }
            b[e] = f;
            0 === --h && a(b);
          } catch (x) {
            d(x);
          }
        }
        if (0 === b.length) return a([]);
        for (var h = b.length, e = 0; e < b.length; e++) c(e, b[e]);
      });
    };
    d.resolve = function (a) {
      return a && "object" === typeof a && a.constructor === d
        ? a
        : new d(function (b) {
            b(a);
          });
    };
    d.reject = function (a) {
      return new d(function (b, c) {
        c(a);
      });
    };
    d.race = function (a) {
      return new d(function (b, c) {
        for (var d = 0, e = a.length; d < e; d++) a[d].then(b, c);
      });
    };
    d._setImmediateFn = function (a) {
      m = a;
    };
    d._setUnhandledRejectionFn = function (a) {
      t = a;
    };
    return d;
  });
});
/* ******** */
(function (n) {
  var m = window.AmazonUIPageJS || window.P,
    q = m._namespace || m.attributeErrors,
    a = q ? q("AmazonUIBaseJS@base", "AmazonUI") : m;
  a.guardFatal
    ? a.guardFatal(n)(a, window)
    : a.execute(function () {
        n(a, window);
      });
})(function (n, m, q) {
  "use strict";
  n.register("a-polyfill", function () {});
  ("use strict");
  n.when("jQuery").register("a-base", function (a) {
    return {
      version: function () {
        return "3.0";
      },
      $: a,
    };
  });
  ("use strict");
  n.declare("prv:a-declarative-analytics", {
    notify: function () {},
    setOptions: function () {},
  });
  ("use strict");
  n.register("prv:a-guard", function () {
    function a(a, e) {
      return a._guard && "function" === typeof e ? a._guard(e) : e;
    }
    return {
      fn: a,
      guardTimeFn: function (a, e) {
        return a._guardTime && "function" === typeof e ? a._guardTime(e) : e;
      },
      obj: function (l, e) {
        if (!l._guard) return e;
        var h = {},
          k;
        for (k in e) e.hasOwnProperty(k) && (h[k] = a(l, e[k]));
        return h;
      },
    };
  });
  ("use strict");
  n.declare("a-timing-analytics", {
    startWidgetLogging: function () {},
    stopWidgetLogging: function () {},
  });
  ("use strict");
  n.declare("a-event-analytics", {
    handle: function () {},
    notifyDeclarativeAction: function () {},
    notifyJquery: function () {},
  });
  ("use strict");
  n.register("priv:a-visibility", function () {
    function a(a) {
      for (
        var e = ["hidden", "webkitHidden", "mozHidden", "msHidden", "oHidden"],
          h = 0;
        h < e.length;
        h += 1
      )
        if (e[h] in a) return e[h];
    }
    return function (l) {
      var e = a(l);
      return e
        ? function () {
            return l[e];
          }
        : function () {
            return !1;
          };
    };
  });
  ("use strict");
  n.register("prv:a-private-util", function () {
    try {
      var a = navigator.userAgent;
    } catch (l) {
      a = "";
    }
    return {
      ua: a,
      safeFeatureTest: function (a) {
        try {
          return a();
        } catch (e) {
          return !1;
        }
      },
    };
  });
  ("use strict");
  n.when("priv:a-visibility", "prv:a-guard", "prv:a-private-util").register(
    "a-util",
    function (a, l, e) {
      function h(a) {
        if (k(a)) return [a];
        if (a.jQuery) return a.get();
        var b = Object.prototype.toString.call(a);
        return "[object String]" === b
          ? Array.prototype.slice.call(document.querySelectorAll(a))
          : "[object Array]" === b
          ? a.filter(a, k)
          : "object" === typeof a &&
            /^\[object (HTMLCollection|NodeList|Object)\]$/.test(b) &&
            "number" === typeof a.length &&
            (0 === a.length || ("object" === typeof a[0] && 0 < a[0].nodeType))
          ? Array.prototype.slice.call(a)
          : [];
      }
      function k(a) {
        return a instanceof Element || a instanceof HTMLDocument;
      }
      var d = e.ua;
      a = {now: Date.now, isPageHidden: a(document)};
      e = [
        function (a) {
          return {
            each: function (b, g, c) {
              if (null !== b)
                if (
                  Array.prototype.forEach &&
                  b.forEach === Array.prototype.forEach
                )
                  b.forEach(g, c);
                else if (b.length === +b.length)
                  for (var f = 0, a = b.length; f < a; f++)
                    f in b && g.call(c, b[f], f, b);
                else for (f in b) b.hasOwnProperty(f) && g.call(c, b[f], f, b);
            },
            map: function (b, g, c) {
              var f = [];
              if (null === b) return f;
              if (Array.prototype.map && b.map === Array.prototype.map)
                return b.map(g, c);
              a.each(b, function (b, a, d) {
                f[f.length] = g.call(c, b, a, d);
              });
              b.length === +b.length && (f.length = b.length);
              return f;
            },
            reduce: function (b, g, c, f) {
              var x = 2 < arguments.length;
              null === b && (b = []);
              if (Array.prototype.reduce && b.reduce === Array.prototype.reduce)
                return x ? b.reduce(g, c) : b.reduce(g);
              a.each(b, function (b, a, d) {
                x ? (c = g.call(f, c, b, a, d)) : ((c = b), (x = !0));
              });
              x ||
                n.error(
                  "Reduce of empty array with no initial value",
                  "A.util",
                  "reduce"
                );
              return c;
            },
            filter: function (b, g, c) {
              var f = [];
              if (null === b) return f;
              if (Array.prototype.filter && b.filter === Array.prototype.filter)
                return b.filter(g, c || b);
              a.each(b, function (a, v, d) {
                g.call(c || b, a, v, d) && f.push(a);
              });
              return f;
            },
            range: function (b, g, c) {
              g === q && ((g = b || 0), (b = 0));
              c = c || 1;
              g = Math.max(Math.ceil((g - b) / c), 0);
              for (var f = Array(g), a = 0; a < g; a++, b += c) f[a] = b;
              return f;
            },
            breaker: {},
          };
        },
        function (a) {
          return {
            throttle: function (b, g, c) {
              var f,
                x,
                v,
                d = l.fn(this, b),
                e = null,
                u = 0;
              c = c || {};
              var z = function () {
                u = !1 === c.leading ? 0 : a.now();
                e = null;
                v = d.apply(f, x);
                f = x = null;
              };
              return function () {
                var d = a.now();
                u || !1 !== c.leading || (u = d);
                var A = g - (d - u);
                f = this;
                x = arguments;
                0 >= A
                  ? (clearTimeout(e),
                    (e = null),
                    (u = d),
                    (v = b.apply(f, x)),
                    (f = x = null))
                  : e || !1 === c.trailing || (e = setTimeout(z, A));
                return v;
              };
            },
            sequence: function () {
              var b = [].slice,
                g = b.call(arguments).reverse(),
                c = this;
              return a.reduce(
                g,
                function (f, g) {
                  return function () {
                    var a = b.call(arguments);
                    a.push(f);
                    g.apply(c, a);
                  };
                },
                function () {}
              );
            },
            debounce: function (b, g, c) {
              var f,
                d,
                v,
                e,
                k,
                u = l.fn(this, b),
                z = function () {
                  var b = a.now() - e;
                  b < g
                    ? (f = setTimeout(z, g - b))
                    : ((f = null), c || ((k = u.apply(v, d)), (v = d = null)));
                };
              return function () {
                v = this;
                d = arguments;
                e = a.now();
                var u = c && !f;
                f || (f = setTimeout(z, g));
                u && ((k = b.apply(v, d)), (v = d = null));
                return k;
              };
            },
            delay: function (b, g) {
              var c = this,
                f = l.fn(this, function () {
                  return l.guardTimeFn(c, b).apply(this, arguments);
                }),
                a = Array.prototype.slice.call(arguments, 2);
              return setTimeout(function () {
                return f.apply(null, a);
              }, g);
            },
            animationFrameDelay: function (b) {
              return this.delay(b, 16);
            },
            interval: function (b, g) {
              var c = this,
                f = l.fn(this, function () {
                  return l.guardTimeFn(c, b).apply(this, arguments);
                });
              return setInterval(f, g);
            },
            once: function (b) {
              var g = !1,
                c = l.fn(this, b),
                f;
              return function () {
                g || ((g = !0), (f = c.apply(this, arguments)));
                return f;
              };
            },
            rest: function (b, g) {
              if (b) {
                var c = Math.max(g === q ? b.length - 1 : g, 0);
                return function () {
                  for (
                    var f = arguments,
                      g = -1,
                      a = Math.max(f.length - c, 0),
                      d = Array(a);
                    ++g < a;

                  )
                    d[g] = f[g + c];
                  switch (c) {
                    case 0:
                      return b.call(this, d);
                    case 1:
                      return b.call(this, f[0], d);
                    case 2:
                      return b.call(this, f[0], f[1], d);
                  }
                  a = Array(c + 1);
                  for (g = -1; ++g < c; ) a[g] = f[g];
                  a[c] = d;
                  return b.apply(this, a);
                };
              }
            },
            parseFunctionName: function (b) {
              return b.name
                ? "anonymous" === b.name
                  ? ""
                  : b.name
                : (b = b.toString().match(/^function\s*([^\s(]+)/))
                ? b[1]
                : "";
            },
          };
        },
        function (a) {
          function b(c) {
            var f;
            "object" !== typeof c && "function" !== typeof c && (c = {});
            for (var g = 1; g < arguments.length; g++) {
              var a = arguments[g];
              if (null != a)
                for (var d in a) {
                  var u = a[d];
                  if (c !== u && u !== q) {
                    var z = c[d];
                    e(u) || (f = v(u))
                      ? (f && !v(z) ? (z = []) : f || e(z) || (z = {}),
                        (f = !1),
                        b(z, u))
                      : (z = u);
                    c[d] = z;
                  }
                }
            }
            return c;
          }
          function g(b, c) {
            b = b || {};
            c = c || {};
            var f = {},
              a;
            for (a in b)
              b.hasOwnProperty(a) &&
                (f[a] =
                  "object" === typeof b[a] && b[a]
                    ? g(b[a], c[a])
                    : b[a] !== c[a]);
            for (a in c)
              c.hasOwnProperty(a) &&
                !f[a] &&
                (f[a] =
                  "object" === typeof c[a] && c[a]
                    ? g(c[a], b[a])
                    : c[a] !== b[a]);
            return f;
          }
          function c(b, a) {
            var g;
            if (b === a) return !0;
            if (v(b)) {
              if (!v(a) || b.length !== a.length) return !1;
              for (g = b.length; g--; ) if (!c(b[g], a[g])) return !1;
              return !0;
            }
            if (e(b)) {
              if (!e(a) || (f(b) && !f(a))) return !1;
              for (g in b) if (!c(b[g], a[g])) return !1;
              return !0;
            }
            return !1;
          }
          function f(b) {
            for (var c in b) if (b.hasOwnProperty(c)) return !1;
            return !0;
          }
          function d(b) {
            if (!("function" === typeof b || ("object" === typeof b && b)))
              return [];
            if (Object.keys) return Object.keys(b);
            var c = [],
              a;
            for (a in b) b.hasOwnProperty(a) && c.push(a);
            return c;
          }
          function v(b) {
            return Array.isArray
              ? Array.isArray(b)
              : "[object Array]" === Object.prototype.toString.call(b);
          }
          function e(b) {
            if (!b || "object" !== typeof b || b.nodeType || b === m) return !1;
            try {
              if (
                b.constructor &&
                !b.hasOwnProperty("constructor") &&
                !b.constructor.prototype.hasOwnProperty("isPrototypeOf")
              )
                return !1;
            } catch (A) {
              return !1;
            }
            for (var c in b);
            return c === q || b.hasOwnProperty(c);
          }
          function k(b, c, a) {
            Object.defineProperty(b, c, {value: a, writable: !1});
            return a;
          }
          function u(b, c, a) {
            b.hasOwnProperty(c) || (b[c] = a);
            return a;
          }
          return {
            keys: d,
            values: function (b) {
              for (var c = d(b), a = Array(c.length), f = 0; f < c.length; f++)
                a[f] = b[c[f]];
              return a;
            },
            extend: b,
            mixin: function (b, c, a) {
              if (a)
                for (var f = 0, g = a.length; f < g; f++) b[a[f]] = c[a[f]];
              else for (f in c) "function" === typeof c[f] && (b[f] = c[f]);
            },
            diff: g,
            equals: c,
            copy: function (c) {
              return v(c) ? b([], c) : e(c) ? b({}, c) : c;
            },
            indexOfArray: function (b, c, a) {
              if (
                Array.prototype.indexOf &&
                b.indexOf === Array.prototype.indexOf
              )
                return b.indexOf(c, a);
              (b && b instanceof Array) ||
                n.error(
                  "Invalid arr passed to A.indexOfArray: " + b,
                  "A.util",
                  "indexOfArray"
                );
              a = parseInt(a, 10);
              a = isNaN(a) ? 0 : a;
              if (!isFinite(a)) return -1;
              for (var f = b.length; a < f; a++) if (b[a] === c) return a;
              return -1;
            },
            isArray: v,
            isPlainObject: e,
            isFiniteNumber: function (b) {
              return "number" === typeof b && !isNaN(b) && isFinite(b);
            },
            objectIsEmpty: f,
            constProp: "function" === typeof Object.defineProperty ? k : u,
          };
        },
        function (a) {
          var b = {
              "\x26": "\x26amp;",
              "\x3c": "\x26lt;",
              "\x3e": "\x26gt;",
              '"': "\x26quot;",
              "'": "\x26#39;",
              "/": "\x26#x2F;",
            },
            g = /^\s+/,
            c = /\s+$/,
            f = new RegExp("[" + a.keys(b).join("") + "]", "g"),
            d = /([!"#$%&'\(\)*+,./:;<=>?@\[\\\]^`{|}~])/g;
          return {
            trim: function (b) {
              return String.prototype.trim
                ? String.prototype.trim.call(b)
                : b.replace(g, "").replace(c, "");
            },
            contains: function (b, c) {
              return -1 !== ("" + b).indexOf(c);
            },
            escapeHtml: function (c) {
              return ("" + c).replace(f, function (c) {
                return b[c];
              });
            },
            escapeJquerySelector: function (b) {
              return ("" + b).replace(d, "\\$1");
            },
            parseJSON: function (b) {
              return JSON.parse(b);
            },
          };
        },
        function (a) {
          function b(b) {
            return a
              .map(g, function (c) {
                var a = b.getAttribute(c);
                return a && "[" + c + "\x3d" + a + "]";
              })
              .join("");
          }
          var g = [
            "id",
            "cel_widget_id",
            "data-feature-name",
            "data-action",
            "data-aui-build-date",
          ];
          return {
            xpath: function (b) {
              if ("" !== b.id) return '//*[@id\x3d"' + b.id + '"]';
              if (b === document.documentElement) return "/html";
              var c = a.indexOfArray(
                a.filter(b.parentNode.childNodes, function (c) {
                  return c.tagName === b.tagName;
                }),
                b
              );
              if (-1 === c)
                throw Error(
                  "can not evaluate xpath of element `" +
                    b.tagName +
                    (b.id ? "#" + b.id : "") +
                    "`"
                );
              return (
                a.xpath(b.parentNode) + "/" + b.tagName + "[" + (c + 1) + "]"
              );
            },
            cssSelector: function (b) {
              var c = [b.tagName || ""];
              b.className &&
                b.className.trim &&
                c.push("." + b.className.trim().replace(/\s+/g, "."));
              b.id && c.push("#" + b.id);
              return c.join("");
            },
            attributionChain: function (c) {
              var f = [];
              do f.push(b(c)), (c = c.parentElement);
              while (c);
              return a.filter(f, Boolean).reverse().join(" ");
            },
          };
        },
        function (a) {
          return {
            hide: function (b) {
              a.each(h(b), function (b) {
                a.addClass(b, "aok-hidden");
              });
            },
            show: function (b) {
              a.each(h(b), function (b) {
                a.removeClass(b, "aok-hidden");
              });
            },
          };
        },
        function (a) {
          function b() {
            g = {};
            for (
              var b = (document.cookie || "").split(";"), f = b.length - 1;
              0 <= f;
              f--
            ) {
              var d = b[f].split("\x3d"),
                e = a.trim(d[0]);
              if (e) {
                var k = g;
                d = d.slice(1).join("\x3d");
                d = a.trim(d);
                /^"/.test(d) && (d = d.slice(1, -1).replace(/\\(.)/g, "$1"));
                d = m.decodeURIComponent(d);
                k[e] = d;
              }
            }
          }
          var g;
          return {
            cookies: {
              get: function (c) {
                g || b();
                return g[c];
              },
              getAll: function () {
                g || b();
                return a.extend({}, g);
              },
              refresh: function () {
                g = null;
              },
            },
          };
        },
        function (a) {
          return {
            onScreen: function (b, g) {
              if (!b) return !1;
              b.jquery && (b = b[0]);
              if (!b) return !1;
              g = "number" === typeof g && !isNaN(g) && isFinite(g) ? g : 100;
              if (
                1 !== b.nodeType ||
                !(b.offsetWidth || b.offsetHeight || b.getClientRects().length)
              )
                return !1;
              var c = a.size(m),
                f = a.scroll(m),
                d = f.top,
                e = m.innerHeight ? m.innerHeight : c.height,
                k = d + e;
              f = f.left;
              c = m.innerWidth ? m.innerWidth : c.width;
              var h = f + c;
              d -= g;
              k += g;
              f -= g;
              h += g;
              var u = a.offset(b),
                r = a.size(b);
              b = u.top;
              g = r.height;
              var p = b + g;
              u = u.left;
              r = r.width;
              var A = u + r;
              return (
                ((b >= d && b < k) ||
                  (p > d && p <= k) ||
                  (g > e && b <= d && p >= k)) &&
                ((u >= f && u < h) ||
                  (A > f && A <= h) ||
                  (r > c && u <= f && A >= h))
              );
            },
          };
        },
        function (a) {
          return {
            isATF: function (b, g) {
              g = "number" === typeof g && !isNaN(g) && isFinite(g) ? g : 100;
              g = a.size(m).height + g;
              b = a.offset(b).top;
              return 0 <= b && b < g;
            },
          };
        },
        function (a) {
          function b(b, a) {
            return b.classList
              ? b.classList.contains(a)
              : 0 <= (" " + b.className + " ").indexOf(" " + a + " ");
          }
          var g = document.createElement("fakeelement"),
            c = {
              transition: "transitionend",
              OTransition: "oTransitionEnd",
              MozTransition: "transitionend",
              WebkitTransition: "webkitTransitionEnd",
            },
            f = null;
          return {
            setCssImportant: function (b, a, c) {
              b = b.jquery ? b[0] : b;
              "undefined" !== typeof b &&
                ((b = b.style),
                (b.cssText = b.cssText.replace(
                  new RegExp(a + "\\s*:\\s*[.^;]*(\\s*;)?", "gmi"),
                  ""
                )),
                (b.cssText += a + ": " + c + " !important;"));
            },
            hasClass: b,
            addClass: function (a, c) {
              b(a, c) ||
                (a.classList ? a.classList.add(c) : (a.className += " " + c));
            },
            removeClass: function (a, c) {
              b(a, c) &&
                (a.classList
                  ? a.classList.remove(c)
                  : (a.className = (" " + a.className + " ")
                      .replace(new RegExp(" " + c + " ", "g"), " ")
                      .replace(/  /g, " ")
                      .replace(/^ | $/g, "")));
            },
            offset: function (b) {
              b.jquery && (b = b[0]);
              b = b.getBoundingClientRect();
              var a = document.documentElement,
                c = document.body;
              return {
                top:
                  b.top +
                  (m.pageYOffset || a.scrollTop) -
                  ((a && a.clientTop) || (c && c.clientTop) || 0),
                left:
                  b.left +
                  (m.pageXOffset || a.scrollLeft) -
                  ((a && a.clientLeft) || (c && c.clientLeft) || 0),
              };
            },
            size: function (b) {
              var a = document.documentElement,
                c = document.body;
              if (b === m)
                return {width: a.clientWidth, height: a.clientHeight};
              if (9 === b.nodeType)
                return {
                  width: Math.max(
                    a.clientWidth,
                    c.scrollWidth,
                    a.scrollWidth,
                    c.offsetWidth,
                    a.offsetWidth
                  ),
                  height: Math.max(
                    a.clientHeight,
                    c.scrollHeight,
                    a.scrollHeight,
                    c.offsetHeight,
                    a.offsetHeight
                  ),
                };
              var f = m.getComputedStyle(b);
              a = parseFloat(f.borderTopWidth);
              c = parseFloat(f.borderBottomWidth);
              var g = parseFloat(f.borderLeftWidth),
                d = parseFloat(f.borderRightWidth),
                e = parseFloat(f.paddingTop),
                k = parseFloat(f.paddingBottom),
                h = parseFloat(f.paddingLeft);
              f = parseFloat(f.paddingRight);
              return {
                width: b.offsetWidth - g - d - h - f,
                height: b.offsetHeight - c - a - e - k,
              };
            },
            scroll: function (b) {
              var a = document.documentElement,
                c = document.body;
              return b
                ? b === m || 9 === b.nodeType
                  ? {
                      top:
                        "pageYOffset" in m
                          ? m.pageYOffset
                          : a.scrollTop || c.scrollTop,
                      left:
                        "pageXOffset" in m
                          ? m.pageXOffset
                          : a.scrollLeft || c.scrollLeft,
                    }
                  : {top: b.scrollTop, left: b.scrollLeft}
                : null;
            },
            getTransitionEndEvent: function () {
              /UCBrowser/.exec(d) && (f = c.WebkitTransition);
              if (null === f)
                for (var b in c)
                  if (g.style[b] !== q) {
                    f = c[b];
                    break;
                  }
              return f;
            },
            reflowCssChanges: function (b) {
              a.each(b, function (b) {});
            },
          };
        },
        function (a) {
          return {
            widescreen: function () {
              return a.hasClass(document.documentElement, "a-ws");
            },
          };
        },
      ];
      for (var p = 0; p < e.length; p++) {
        var r = e[p](a),
          y;
        for (y in r) a[y] = r[y];
      }
      return a;
    }
  );
  ("use strict");
  n.when("p-detect", "a-util", "prv:a-private-util").register(
    "prv:a-capabilities",
    function (a, l, e) {
      var h = {},
        k = /Trident/.test(e.ua);
      l.each(
        {
          isChrome: function () {
            return /Chrome/.test(e.ua);
          },
          isUCBrowser: function () {
            return /UCBrowser/.test(e.ua);
          },
          isSafari: function () {
            var a = document.documentElement.style;
            return (
              !("MozAppearance" in a) &&
              "webkitAppearance" in a &&
              /^Apple/.test(navigator.vendor)
            );
          },
          isAndroidStockGuess: function () {
            var d = !1;
            a.capabilities.android &&
              !/Chrome|Opera|Firefox|UCBrowser/.test(e.ua) &&
              ((d = /AppleWebKit\/(\d+\.\d+)/.exec(e.ua)),
              (d = d[1] && "535" > d[1]));
            return d;
          },
          isFirefox: function () {
            return /Firefox/.test(e.ua);
          },
          isIE: function () {
            return k;
          },
          isIE10: function () {
            return (
              k && "onmspointerup" in document && !("onpointerup" in document)
            );
          },
          isIE10Plus: function () {
            return (
              k && ("onpointerup" in document || "onmspointerup" in document)
            );
          },
          isIE11Plus: function () {
            return k && "onpointerup" in document;
          },
          isiOS8: function () {
            return a.capabilities.ios && /Version\/8\./.test(e.ua);
          },
          isIETouchCapable: function () {
            return h.isIE10Plus && /Touch;/.test(e.ua);
          },
          isMetroIEGuess: function () {
            var d = !0;
            try {
              d = new ActiveXObject("htmlfile");
            } catch (p) {
              d = !1;
            }
            return h.isIE10Plus && !a.capabilities.mobile && !d;
          },
        },
        function (a, k) {
          h[k] = e.safeFeatureTest(a);
        }
      );
      return h;
    }
  );
  ("use strict");
  n.when(
    "p-detect",
    "prv:a-capabilities",
    "a-util",
    "prv:a-private-util"
  ).register("a-detect", function (a, l, e, h) {
    var k = e.copy(a),
      d = function () {
        var a =
          /(?:Android\s+|Windowshop.*Android\/|Android\/)(\d+(?:\.\d+)*)/.exec(
            h.ua
          );
        return a && a[1];
      },
      p = {};
    e.each(
      {
        isAmazonApp: function () {
          return /(Windowshop|Amazon|Amazon\.com)\//.test(
            e.cookies.get("amzn-app-id")
          );
        },
        isGen5App: function () {
          return /Windowshop.*(?:KFOT|KFTH|KFJWA|KFJWI|KFTT)/.test(h.ua);
        },
        isAndroid: function () {
          return k.capabilities.android;
        },
        androidVersion: function () {
          return d();
        },
        isAndroidKitkatPlus: function () {
          var a = d();
          return a && null !== a.match(/(^4\.[4-9]|^[5-9]|^\d\d)/);
        },
        isOldAndroid: function () {
          return /Android\s[12]/.test(h.ua);
        },
        pointerPrefix: function () {
          return "onmspointerup" in document || "onpointerup" in document
            ? "onpointerup" in document
              ? "pointer"
              : "MSPointer"
            : !1;
        },
        actionMode: function () {
          var a = k.capabilities.pointerPrefix;
          return a ? a : k.capabilities.touch ? "touch" : "mouse";
        },
      },
      function (a, d) {
        k.capabilities[d] = h.safeFeatureTest(a);
      }
    );
    e.extend(k.capabilities, l);
    e.each(
      {
        start: {
          mouse: "down",
          touch: "start",
          pointer: "down",
          MSPointer: "Down",
        },
        end: {mouse: "up", touch: "end", pointer: "up", MSPointer: "Up"},
        move: {
          mouse: "move",
          touch: "move",
          pointer: "move",
          MSPointer: "Move",
        },
        enter: {mouse: "enter", touch: "enter", pointer: "enter"},
        leave: {mouse: "leave", touch: "leave", pointer: "leave"},
        cancel: {touch: "cancel", pointer: "cancel", MSPointer: "Cancel"},
        over: {mouse: "over", pointer: "over", MSPointer: "Over"},
        out: {mouse: "out", pointer: "out", MSPointer: "Out"},
      },
      function (a, d) {
        var e = k.capabilities.actionMode,
          b = "string" === typeof a ? a : a[e];
        p[d] = b ? e + b : a.mouse === q ? "" : "mouse" + a.mouse;
      }
    );
    k.action = p;
    a = {};
    "pointer" === k.capabilities.pointerPrefix
      ? ((a.touch = "touch"),
        (a.pen = "pen"),
        (a.mouse = "mouse"),
        (a.unknown = ""))
      : "MSPointer" === k.capabilities.pointerPrefix &&
        ((a.touch = 2), (a.pen = 3), (a.mouse = 4));
    k.pointerType = a;
    return k;
  });
  ("use strict");
  n.when("prv:a-guard").register("a-defer", function (a) {
    function l(a) {
      var d = 0,
        e = setTimeout(function () {
          l(a);
        }, 0);
      if (0 === a.length) clearTimeout(e), (h = !1);
      else {
        var n = Date.now();
        a.shift().call();
        k += Date.now() - n;
        50 < k && ((d = 50), (k = 0));
        setTimeout(function () {
          l(a);
        }, d);
        clearTimeout(e);
      }
    }
    var e = [],
      h = !1,
      k = 0;
    return {
      defer: function (d) {
        var k = this,
          r = a.fn(this, function () {
            return a.guardTimeFn(k, d).apply(this, arguments);
          });
        e.push(r);
        h ||
          ((h = !0),
          setTimeout(function () {
            l(e);
          }, 0));
      },
      pauseDeferred: function () {},
      executeDeferred: function () {},
    };
  });
  ("use strict");
  n.when("a-util").register("a-events", function (a, l) {
    function e(b, a) {
      for (var c = b.length; c--; ) a(b[c], c, b) || b.splice(c, 1);
    }
    function h(b) {
      var a = b.shift();
      if (a === q) return f;
      try {
        !1 === a.fn.apply(m, a.args) &&
          e(b, function (b) {
            return b.id !== a.id;
          });
      } catch (C) {
        (a.logError ? a : n).logError(
          C,
          "Event execution failed for event " + a.topic,
          "FATAL"
        );
      }
    }
    function k(b, f) {
      if (y(b)) {
        var g = B++,
          d = c[b];
        f = f || [];
        var e = a.map(d, function (a) {
          return {
            topic: b,
            id: g,
            fn: a.guard ? a.guard(a.fn) : a.fn,
            args: f,
            logError: a.logError,
          };
        });
        d.occurred && p(b);
        d.isTimeSliced ? x(e) : v(e);
      }
    }
    function d(b, a, f) {
      if ("function" === typeof a)
        return (
          (f = {fn: a, logError: f && f.logError, guard: f && f.guard}),
          (c[b] = c[b] || []).unshift(f),
          {event: b, callback: a}
        );
    }
    function p(b) {
      c[b].length = 0;
    }
    function r(b, f) {
      function g(b) {
        e(c[b], function (b) {
          return b.fn !== f;
        });
      }
      a.each(a.filter(b.split(" "), y), f ? g : p);
    }
    function y(b) {
      return c.hasOwnProperty(b) && 0 < c[b].length;
    }
    function t(b, f) {
      var g = function () {
          n.register(b, function () {
            var b = m.aPageStart;
            return {time: b ? a.now() - b : 0};
          });
        },
        e = (c[b] = c[b] || []);
      e.occurred ||
        ((e.isTimeSliced = !1 !== f), (e.occurred = !0), d(b, g), k(b));
    }
    function b(b, a) {
      var c = this.on;
      this.on = function () {
        return c.apply(this, arguments);
      };
      this.on._guard = b;
      this.on._logError = a;
      for (var f in c) c.hasOwnProperty(f) && (this.on[f] = c[f]);
      this.constructor = q;
    }
    function g(b, a) {
      m.attachEvent ? m.attachEvent("on" + b, a) : m.addEventListener(b, a, !1);
    }
    var c = {},
      f = {},
      x = (function () {
        function b() {
          c = !0;
          for (var d = a.now(); 50 > a.now() - d; )
            if (h(g) === f) {
              c = !1;
              return;
            }
          a.delay(b, 15);
        }
        var c = !1,
          g = [];
        return function (a) {
          Array.prototype.push.apply(g, a);
          c || b();
        };
      })(),
      v = (function () {
        var b = !1,
          a = [];
        return function (c) {
          Array.prototype.push.apply(a, c);
          if (!b) {
            for (b = !0; h(a) !== f; );
            b = !1;
          }
        };
      })(),
      B = 0,
      w = (function () {
        var b = function (b, f, g) {
          var e = b.split(" "),
            h = [],
            u = f;
          !0 === g &&
            (u = function () {
              f.apply(m, arguments);
              r(b, u);
            });
          var l = this ? {logError: this._logError, guard: this._guard} : {};
          a.each(e, function (b) {
            (c[b] || []).occurred
              ? (d(b, f, l), k(b))
              : h.push(d(b, u, l).event);
          });
          return {event: h.join(" "), callback: u};
        };
        a.each(
          "ready load unload afterLoad scroll resize orientationchange zoom".split(
            " "
          ),
          function (a) {
            b[a] = function (c, f) {
              b.call(this, a, c, f);
            };
          }
        );
        return b;
      })();
    b.prototype = {
      isListening: y,
      on: w,
      one: function (b, a) {
        var c = b.split(" ");
        if (1 < c.length)
          n.error(
            "A.one only accepts a single event name, but was provided with: " +
              c.length +
              ", (" +
              b +
              ")",
            "A.events",
            "one"
          );
        else return w(b, a, !0);
      },
      off: function (b, a) {
        if ("object" === typeof b) {
          var c = b.event;
          b = b.callback;
        } else (c = b), (b = a);
        return r(c, b);
      },
      trigger: function (b) {
        for (var a = arguments.length, c = Array(a), f = 0; f < a; f++)
          c[f] = arguments[f];
        c.shift();
        k(b, c);
      },
      events: {
        defaults: {
          input: "change",
          select: "change",
          a: "click",
          button: "click",
          form: "submit",
        },
      },
    };
    b.prototype.constructor = b;
    n.when("a-bodyBegin").execute(function () {
      t("bodyBegin");
    });
    g("unload", function () {
      t("unload", !1);
    });
    n.when("p-detect").execute(function (b) {
      var c = a.once(function () {
          t("beforeLoad");
          t("load");
          a.delay(function () {
            t("beforeAfterLoad");
            t("afterLoad");
          }, 1500);
        }),
        f = a.once(function () {
          b.responsiveGridEnabled() && b.toggleResponsiveGrid(!0);
          t("beforeReady");
          t("ready");
          t("afterReady");
          "complete" === document.readyState && c();
        });
      (function (b) {
        "loading" != document.readyState
          ? b()
          : document.addEventListener
          ? document.addEventListener("DOMContentLoaded", b)
          : document.attachEvent("onreadystatechange", function () {
              "loading" != document.readyState && b();
            });
      })(f);
      n.when("a-domready").execute(f);
      g("load", c);
    });
    return b.prototype;
  });
  ("use strict");
  n.when("a-util", "a-events").register("a-prefix", function (a, l) {
    function e(a) {
      return a.toLowerCase().replace(/-(.)/g, function (a, d) {
        return d.toUpperCase();
      });
    }
    var h = {transitionend: null},
      k = document.createElement("div").style,
      d = {},
      p = ["o", "ms", "moz", "webkit"];
    l.on("beforeReady", function () {
      if (m.addEventListener) {
        var d = document.createElement("div"),
          e = function (a) {
            h.transitionend = a.type;
            this.removeEventListener("webkitTransitionEnd", e, !1);
            this.removeEventListener("transitionend", e, !1);
            this.removeEventListener("otransitionend", e, !1);
            this.removeEventListener("oTransitionEnd", e, !1);
          };
        d.setAttribute(
          "style",
          "position:absolute;top:0px;z-index:-1;transition:top 1ms ease;-webkit-transition:top 1ms ease;-moz-transition:top 1ms ease;-o-transition:top 1ms ease;"
        );
        d.addEventListener("transitionend", e, !1);
        d.addEventListener("webkitTransitionEnd", e, !1);
        d.addEventListener("otransitionend", e, !1);
        this.addEventListener("oTransitionEnd", e, !1);
        document.body.appendChild(d);
        a.delay(function () {
          d.style.top = "100px";
          a.delay(function () {
            d.parentNode.removeChild(d);
            d = e = null;
            a.each(h, function (a) {});
          }, 100);
        }, 0);
      }
    });
    return {
      prefixes: {
        getStyle: function (a) {
          if (!d[a]) {
            var h = e(a);
            if (h in k) d[a] = h;
            else {
              h = h.charAt(0).toUpperCase() + h.slice(1);
              for (var l = p.length; l--; ) {
                var b = p[l] + h;
                b in k && (d[a] = b);
              }
            }
          }
          return d[a];
        },
        getEvent: function (a) {
          return a ? h[a.toLowerCase()] : q;
        },
      },
    };
  });
  ("use strict");
  n.when("a-util", "jQuery", "a-declarative").register(
    "a-draggable",
    function (a, l, e) {
      var h,
        k = {
          _maxZIndex: 0,
          _isInit: !1,
          _draggables: [],
          _init: function () {
            this._isInit || ((this._isInit = !0), (this._maxZIndex = 975));
          },
          create: function (a) {
            this._init();
            a._zimIndex ||
              ((a._zimIndex = 975),
              (this._maxZIndex += 1),
              this._draggables.push(a));
            this.acquireFocus(a);
          },
          acquireFocus: function (a) {
            a.css("zIndex", this._maxZIndex);
            h.css("zIndex", this._maxZIndex - 1);
            for (var b = 0; b < this._draggables.length; b++) {
              var g = this._draggables[b];
              g[0] !== a[0] &&
                g._zimIndex > a._zimIndex &&
                ((g._zimIndex -= g._zimIndex > this._maxZIndex - 1 ? 2 : 1),
                g.css("zIndex", g._zimIndex));
            }
            a._zimIndex = this._maxZIndex;
          },
        },
        d = function (d) {
          var b = d.$event;
          a.contains("touchstart touchend touchmove", d.type) &&
            (b = b.originalEvent.touches[0]);
          return {x: b.clientX, y: b.clientY};
        },
        p = function (a) {
          var b = a.data.$draggable,
            g = b.data("a-draggables"),
            c = d(a);
          g.isMouseDown &&
            (b.css({left: c.x - g.clickOffset.x, top: c.y - g.clickOffset.y}),
            a.$event.preventDefault());
        },
        r = function (a) {
          var b = a.$event.target || a.$event.srcElement,
            g = a.data.$draggable,
            c = g.data("a-draggables");
          k.acquireFocus(g);
          b = l(b).closest(c.$handle, g);
          c.isMouseDown = 0 < b.length;
          c.isMouseDown &&
            (h && h.removeClass("aok-hidden"),
            (b = d(a)),
            (c.clickOffset = {
              x: b.x - parseFloat(g.css("left")),
              y: b.y - parseFloat(g.css("top")),
            }),
            g.data("a-draggables", c),
            h.data("a-draggables", c),
            a.$event.preventDefault());
        },
        n = function (a) {
          a = a.data.$draggable;
          var b = a.data("a-draggables");
          b.isMouseDown = !1;
          a.data("a-draggables", b);
          h && h.addClass("aok-hidden");
        };
      return {
        draggable: function (a, b) {
          a = a.jquery ? a : l(a);
          b = {
            isMouseDown: !1,
            $draggable: a,
            $handle: b && b.handle ? b.handle : a,
          };
          b.$handle = b.$handle.jquery ? b.$handle : l(b.handle);
          b.$handle.css("cursor", "move");
          h ||
            ((h = l("\x3cdiv\x3e", {
              id: "a-draggables-mousedown-layer",
              class: "aok-hidden",
            }).appendTo("body")),
            e.declarative.create(h, "a-draggables", b));
          k.create(b.$draggable);
          e.declarative.create(b.$draggable, "a-draggables", b);
          e.declarative("a-draggables", ["mousedown", "touchstart"], r);
          e.declarative("a-draggables", ["mouseup", "touchend"], n);
          e.declarative("a-draggables", ["mousemove", "touchmove"], p);
        },
      };
    }
  );
  ("use strict");
  n.when(
    "jQuery",
    "a-util",
    "a-events",
    "a-declarative",
    "a-constants",
    "a-analytics"
  ).register("a-state", function (a, l, e, h, k, d) {
    function p(b, g, c, f) {
      var d = !(b in t);
      if (null === g || a.isArray(g) || a.isPlainObject(g)) {
        var h = l.copy(t[b]);
        h && g && !f && (a.isArray(h) || a.isPlainObject(h))
          ? l.extend(t[b], g)
          : (t[b] = l.copy(g));
        g = l.diff(h, t[b]);
        f = l.copy(t[b]);
        c || e.trigger("a:state:update:" + b, f, g, h);
        d && n.declare(k.constants.PAGESTATE_LOADED_MODULE_PREFIX + b, f);
        return f;
      }
      n.error(
        "Invalid value passed to A.state with a namespace of " +
          b +
          ".  Value: " +
          g,
        "A.state",
        "updateNamespace"
      );
    }
    function r(b, a, c) {
      if (1 === a.length) return (b[a.shift()] = c), b;
      b[a.shift()] = r({}, a, c);
      return b;
    }
    function m() {
      for (
        var b = document.getElementsByTagName("script"), g = 0, c = b.length;
        g < c;
        g++
      )
        if (!a.data(b[g], "a-eval")) {
          var f = a(b[g]),
            e = f.attr("data-a-state");
          if (e) {
            try {
              var h = l.parseJSON(e);
            } catch (w) {
              throw (
                (d.logError(
                  "[AUI] key value interface for accessing state data parsing failed",
                  "ERROR",
                  JSON.stringify({
                    xpath: l.xpath(b[g]),
                    cssSelector: l.cssSelector(b[g]),
                    custody: l.attributionChain(b[g]),
                  })
                ),
                w)
              );
            }
            if (h.key) {
              try {
                var k = l.parseJSON(f.html());
              } catch (w) {
                n.logError(
                  w,
                  "State parsing failed for state " + h.key,
                  "ERROR"
                );
                continue;
              }
              a.data(b[g], "a-eval", !0);
              (f = t[h.key]) && l.extend(k, f);
              p(h.key, k);
            }
          }
        }
    }
    var t = {};
    h.declarative("a-state", function (b) {
      var a = b.$target,
        c = b.data.key,
        f = b.data[b.type];
      f || e.events.defaults[b.targetTag] !== b.type || (f = a.attr("name"));
      f &&
        c &&
        (a.is("select") && (a = a.find(":selected")),
        typeof a.val() !== q &&
          "string" === typeof f &&
          ((b = a.val()),
          a.is("input[type\x3dcheckbox]") && !a.prop("checked") && (b = null),
          (f = r({}, f.split("."), b))),
        p(c, f));
    });
    h = function (b, a, c) {
      return a === q ? l.copy(t[b]) : p(b, a, !!c);
    };
    h.bind = function (b, a) {
      e.on("a:state:update:" + b, a);
    };
    h.replace = function (b, a, c) {
      return p(b, a, !!c, !0);
    };
    e.on("beforeReady", m);
    h.parse = m;
    return {state: h};
  });
  ("use strict");
  n.when(
    "prv:a-guard",
    "jQuery",
    "a-util",
    "a-events",
    "a-declarative",
    "a-state"
  ).register("a-ajax", function (a, l, e, h, k, d) {
    function p(b, a) {
      if (!b) return "";
      var c = "string" === typeof b;
      if ("string" === a) return c ? b : "";
      if ("json" === a) {
        if (c) return b;
        try {
          return JSON && JSON.stringify ? JSON.stringify(b) : "";
        } catch (v) {
          n.logError(v, "AJAX POST failed to convert JSON object to string");
        }
        return "";
      }
      return c ? "" : l.param(b);
    }
    function r(b, a) {
      b &&
        0 !== b.length &&
        ("string" === typeof b && "" === e.trim(b)
          ? a && a(b)
          : (b[0] instanceof Array || (b = [b]),
            e.each(b, function (c) {
              var f = t[c[0]];
              f
                ? f.apply(m, c)
                : ((f = a) ||
                    n.error(
                      "There is no handler for the streaming ajax command: " +
                        b[0],
                      "A.ajax",
                      "chunkHandler"
                    ),
                  f(c));
            })));
    }
    var y = (function () {
        m.XMLHttpRequest ||
          (m.XMLHttpRequest = function () {
            return new ActiveXObject("Microsoft.XMLHTTP");
          });
        var b = (function () {
            function b() {
              0 < a.length ? a.pop().send() : c--;
            }
            var a = [],
              c = 0,
              f = 0,
              d = 0;
            return {
              add: function (b) {
                4 > c
                  ? (b.send(), c++)
                  : (a.push(b),
                    f++,
                    a.length > d && (d = a.length),
                    (b = m.ue) &&
                      b.count &&
                      (b.count("aui:ajax:queued", f),
                      b.count("aui:ajax:maxQueued", d)));
              },
              complete: b,
              abort: function (c) {
                c = e.indexOfArray(a, c);
                -1 !== c && a.splice(c, 1);
                b();
              },
            };
          })(),
          a = function () {},
          d = function (a) {
            var c = a.http,
              f = !1,
              d = !1;
            switch (c.readyState) {
              case 4:
                d = !0;
                break;
              case 3:
                f = !0;
            }
            var g = 200 === c.status || 304 === c.status,
              k = a.responsePosition;
            if (f || (d && g)) {
              var l = c.responseText;
              if (k < l.length) {
                k = l.substring(k, l.length);
                l = k.split("\x26\x26\x26");
                var p = k.lastIndexOf("\x26\x26\x26");
                if (-1 === p && f) return;
                p < k.length - 3 && f && l.pop();
                e.each(l, function (b, c) {
                  if ("" !== e.trim(b))
                    try {
                      var f = e.parseJSON(b);
                    } catch (D) {
                      n.logError(
                        D,
                        "Invalid streaming ajax JSON response: " + b
                      );
                    }
                  else f = b;
                  a.callbacks.chunk(f);
                });
                a.responsePosition += p;
              }
            }
            d &&
              (clearInterval(a.pollTimer),
              clearTimeout(a.timeoutTimer),
              b.complete(),
              g
                ? a.callbacks.success(null, c.statusText, a)
                : a.callbacks.failure(a, c.statusText, c.statusText),
              h.trigger("a:pageUpdate"),
              h.trigger("a:ajax:complete"));
          },
          g = function (a) {
            var c = a.http;
            if (4 === c.readyState) {
              clearInterval(a.pollTimer);
              clearTimeout(a.timeoutTimer);
              b.complete();
              var f = c.responseText;
              try {
                f = e.parseJSON(f);
              } catch (z) {}
              200 !== c.status && 304 !== c.status
                ? a.callbacks.failure(a, c.statusText, c.statusText)
                : a.callbacks.success(f, c.statusText, a);
              h.trigger("a:ajax:complete");
            }
          };
        return (function () {
          function c(a) {
            4 > a.http.readyState &&
              (clearInterval(a.pollTimer),
              a.callbacks.failure(a, "Request Timeout", "Request Timeout"),
              b.complete());
          }
          function f(b, a, c) {
            c = c || {};
            c = e.extend({}, h.all, h[a], c);
            e.each(c, function (a, c) {
              (a || "" === a) && b.setRequestHeader(c, a);
            });
            return b;
          }
          function k(a, c, d, g, e, k, h, l, p, u) {
            var v = a.http;
            v.open(c, d);
            f(v, c, p);
            a.timeout = g;
            a.callbacks.chunk = e || a.callbacks.chunk;
            a.callbacks.success = k || a.callbacks.success;
            a.callbacks.failure = h || a.callbacks.failure;
            a.callbacks.abort = l || a.callbacks.abort;
            u && (v.withCredentials = !0);
            b.add(a);
            return {
              abort: function () {
                a.abort();
              },
            };
          }
          var h = {
              all: {"X-Requested-With": "XMLHttpRequest"},
              get: {Accept: "text/html,*/*"},
              post: {
                Accept: "text/html,*/*",
                "Content-Type": "application/x-www-form-urlencoded",
              },
            },
            l = function () {
              var b = new XMLHttpRequest();
              this.pollTimer = null;
              this.http = b;
              this.responsePosition = 0;
              this.buffer = "";
              this.callbacks = {success: a, failure: a, chunk: a, abort: a};
            };
          l.prototype = {
            send: function () {
              var b = this;
              b.http.send(b.params);
              b.pollTimer = setInterval(function () {
                if (
                  2 <= b.http.readyState &&
                  "unknown" !== typeof b.http.responseText
                ) {
                  var a = b.http.getResponseHeader("Content-Type");
                  a = a ? a.toLowerCase() : "";
                  (-1 !== a.indexOf("application/json-amazonui-streaming") ||
                    -1 !== a.indexOf("application/amazonui-streaming-json")
                    ? d
                    : g)(b);
                }
              }, 25);
              b.timeout = "undefined" === typeof b.timeout ? 2e4 : b.timeout;
              b.timeoutTimer = e.delay(c, b.timeout, b);
            },
            get: function (b, a, c, f, d, g, e, h, l) {
              if (a) {
                var p = b.indexOf("?"),
                  u = b.charAt(b.length - 1);
                -1 < p
                  ? "?" !== u && "\x26" !== u && (b += "\x26")
                  : (b += "?");
                b += a;
              }
              return k(this, "get", b, c, f, d, g, e, h, l);
            },
            abort: function () {
              this.http && this.http.abort();
              clearInterval(this.pollTimer);
              clearTimeout(this.timeoutTimer);
              b.abort(this);
              this.callbacks.abort(this);
            },
            post: function (b, a, c, f, d, g, e, h, l) {
              this.params = a;
              return k(this, "post", b, c, f, d, g, e, h, l);
            },
          };
          return l;
        })();
      })(),
      t = {
        update: function (b, a, d) {
          l(a).html(d);
        },
        append: function (b, a, d) {
          b = l(a);
          b.html(b.html() + d);
        },
        prepend: function (b, a, d) {
          b = l(a);
          b.html(d + b.html());
        },
        state: function (b, a, g) {
          d.state(a, g);
        },
        script: function (b, a) {
          eval(a);
        },
        trigger: function (b, a) {
          var c = Array.prototype.slice.call(arguments, 1);
          h.trigger.apply(void 0, c);
        },
      },
      b = {
        "a-ajax-update": function (b) {
          var a = new y(),
            c = function () {
              var b = m.ue;
              b && b.tag && (b.tag("aui"), b.tag("aui:ajax"));
            },
            d = b.abort,
            g = l(b.indicator),
            h = g.hasClass("aok-hidden");
          g.removeClass("aok-hidden").show();
          var k = function (b, a) {
              g.hide();
              h && g.addClass("aok-hidden");
              c();
              b && b.apply(m, a);
            },
            p =
              "string" === typeof b.method && "post" === b.method.toLowerCase()
                ? "post"
                : "get";
          "get" === p &&
            !1 === b.cache &&
            (b.params += ["" === b.params ? "" : "\x26", "_\x3d", e.now()].join(
              ""
            ));
          return a[p](
            b.url,
            b.params,
            b.timeout,
            function (a) {
              c();
              r(a, b.chunk);
            },
            function () {
              k(b.success, arguments);
            },
            function () {
              k(b.failure, arguments);
            },
            d,
            b.headers,
            b.withCredentials
          );
        },
      };
    k.declarative("a-ajax-update", function (a) {
      var c = a.$target,
        d = a.action,
        g = a.data;
      if (g || h.events.defaults[a.targetTag] === a.type)
        if ("object" !== typeof g || g[a.type]) {
          g = g || {};
          var e = g.url || c.attr("href") || c.attr("action"),
            k = p(g.params, g.paramsFormat),
            l = c.attr("method") || g.method,
            r = g.indicator;
          g = g.timeout;
          e || n.error("No ajax url provided.", "A.ajax", "declarativeHandler");
          "form" === a.targetTag &&
            a.type === h.events.defaults.form &&
            ((c = c.serialize()), (k += c));
          a.$event.preventDefault();
          return b[d]({
            url: e,
            params: k,
            method: l,
            indicator: r,
            operation: d,
            timeout: g,
          });
        }
    });
    var g = function (c, f) {
      f = f || {};
      var d = this,
        g = f.headers || {};
      f.accepts !== q && (g.Accept = f.accepts);
      f.contentType !== q && (g["Content-Type"] = f.contentType);
      var e = p(f.params, f.paramsFormat);
      return b["a-ajax-update"](
        a.obj(this, {
          url: c,
          cache: f.cache,
          params: e,
          method: f.method,
          chunk: f.chunk,
          success:
            f.success &&
            function () {
              return a.guardTimeFn(d, f.success).apply(this, arguments);
            },
          failure:
            (f.failure || f.error) &&
            function () {
              return a
                .guardTimeFn(d, f.failure || f.error)
                .apply(this, arguments);
            },
          abort: f.abort,
          indicator: f.indicator,
          timeout: f.timeout,
          headers: g,
          withCredentials: !!f.withCredentials,
        })
      );
    };
    return {
      ajax: g,
      get: function (b, a) {
        a = a || {};
        a.method = "get";
        return g.call(this, b, a);
      },
      post: function (b, a) {
        a = a || {};
        a.method = "post";
        return g.call(this, b, a);
      },
    };
  });
  ("use strict");
  n.when("a-util", "p-detect", "a-prefix").register(
    "a-animate",
    function (a, l, e) {
      function h(b, a, c) {
        b = b.jquery ? b[0] : b;
        a = e.prefixes.getStyle(a);
        b.style[a] = c;
      }
      function k(b) {
        var a = "",
          c = l.capabilities.transform3d;
        b.top !== q && b.left !== q
          ? ((a = "translate"),
            c && (a += "3d"),
            (a += "(" + b.left + ", " + b.top),
            c && (a += ", 0"),
            (a += ")"))
          : (b.top !== q
              ? (a = "translateY(" + b.top + ")")
              : b.left !== q && (a = "translateX(" + b.left + ")"),
            c && (a += " translateZ(0)"));
        b.scale !== q && (a += " scale(" + b.scale + ")");
        return a;
      }
      function d(b) {
        var d = {},
          c = !1;
        a.each(r, function (a) {
          a in b && ((c = !0), (d[a] = b[a]), delete b[a]);
        });
        return c ? d : null;
      }
      function p(b, d, c) {
        l.capabilities.transform
          ? ("string" === typeof c && (c = parseInt(c, 10)),
            a.isFiniteNumber(c) || (c = 0),
            (b = parseInt(b.css(d), 10)),
            a.isFiniteNumber(b) || (b = 0),
            (c = c - b + "px"))
          : a.isFiniteNumber(c) && (c += "px");
        return c;
      }
      var r = ["top", "left", "scale"],
        n = {
          animate: function (b, a, c, f, d) {
            b._a || (b._a = 0);
            b._a++;
            var g = function () {
              b._a--;
              d && d();
            };
            b.queue("fx", [
              function () {
                b.animate(a, {
                  duration: c,
                  easing: "linear" === f ? f : "swing",
                  complete: g,
                  queue: !1,
                });
              },
            ]);
          },
          fadeIn: function (b, a, c, f) {
            (b.hasClass("aok-hidden") || b.hasClass("a-hidden")) &&
              b.css("display", "none").removeClass("aok-hidden a-hidden");
            this.stopAnimation(b, !0, !0);
            b.fadeIn({
              duration: a,
              easing: "linear" === c ? c : "swing",
              complete: f,
              queue: !1,
            });
          },
          fadeOut: function (b, a, c, f) {
            this.stopAnimation(b, !0, !0);
            var d = b.css("opacity");
            b.fadeOut({
              duration: a,
              easing: "linear" === c ? c : "swing",
              complete: function () {
                b.css("opacity", d);
                f && f();
              },
              queue: !1,
            });
          },
          fadeToggle: function (b, a, c, f) {
            b.fadeToggle({
              duration: a,
              easing: "linear" === c ? c : "swing",
              complete: f,
              queue: !1,
            });
          },
          slideUp: function (b, a, c, f) {
            b.slideUp({
              duration: a,
              easing: "linear" === c ? c : "swing",
              complete: f,
              queue: !1,
            });
          },
          slideDown: function (b, a, c, f) {
            b.slideDown({
              duration: a,
              easing: "linear" === c ? c : "swing",
              complete: f,
              queue: !1,
            });
          },
          slideToggle: function (b, a, c, f) {
            b.slideToggle({
              duration: a,
              easing: "linear" === c ? c : "swing",
              complete: f,
              queue: !1,
            });
          },
          isAnimated: function (b) {
            b = b.jquery ? b[0] : b;
            return b._a && 0 < b._a;
          },
          stopAnimation: function (b, a, c) {
            b.stop(a, c);
          },
        },
        m = {
          animate: function (b, g, c, f, e) {
            if (b && b.length) {
              var r = b[0];
              g = a.copy(g);
              c = c === q ? 250 : c;
              f = f || "linear";
              g.top !== q && (g.top = p(b, "top", g.top));
              g.left !== q && (g.left = p(b, "left", g.left));
              h(b, "transition", 4 > c ? "all 0ms" : "all " + c + "ms " + f);
              4 < c
                ? (r._a === q && (r._a = 0),
                  r._a++,
                  (f = function () {
                    0 < r._a && r._a--;
                    r._a || h(b, "transition", "");
                    b.removeData("aAnimateTimeoutId").removeData(
                      "aAnimateOnComplete"
                    );
                    e && e();
                  }),
                  b
                    .data("aAnimateOnComplete", f)
                    .data("aAnimateTimeoutId", a.delay(f, c)))
                : e && a.delay(e, 0);
              l.capabilities.transform &&
                (c = d(g)) &&
                h(
                  b,
                  "transform",
                  k({top: c.top, left: c.left, scale: c.scale})
                );
              a.objectIsEmpty(g) || b.css(g);
            }
          },
          fadeIn: function (b, d, c, f) {
            this.stopAnimation(b, !0, !0);
            if (b.data("aTargetOpacity") === q) {
              var g = b.css("opacity") || 1;
              b.data("aTargetOpacity", g);
            } else g = b.data("aTargetOpacity");
            b.css("opacity", "0").removeClass("a-hidden aok-hidden").show();
            a.reflowCssChanges(b);
            this.animate(b, {opacity: g}, d, c, function () {
              b.show();
              f && f();
            });
          },
          fadeOut: function (b, a, c, f) {
            this.stopAnimation(b, !0, !0);
            var d = b.css("opacity");
            b.data("aTargetOpacity") === q && b.data("aTargetOpacity", d);
            this.animate(b, {opacity: 0}, a, c, function () {
              b.hide().css("opacity", d);
              f && f();
            });
          },
          fadeToggle: function (b, a, c, f) {
            ("none" === b.css("display") || 0.05 > +b.css("opacity")
              ? this.fadeIn
              : this.fadeOut
            ).call(this, b, a, c, f);
          },
          slideUp: function (b, d, c, f) {
            var g = this.animate;
            b.css({height: b.innerHeight(), overflow: "hidden"});
            a.delay(function () {
              g(b, {height: 0}, d, c, function () {
                b.hide();
                b.css({height: "", overflow: ""});
                f && f();
              });
            }, 0);
          },
          slideDown: function (b, d, c, f) {
            var g = b.innerHeight(),
              e = this.animate;
            b.css({height: 0, overflow: "hidden"});
            b.show();
            a.delay(function () {
              e(b, {height: g}, d, c, function () {
                f && f();
                b.css({height: "", overflow: ""});
              });
            }, 0);
          },
          slideToggle: function (b, a, c, f) {
            (b.is(":visible") ? this.slideUp : this.slideDown).call(
              this,
              b,
              a,
              c,
              f
            );
          },
          isAnimated: function (b) {
            b = b.jquery ? b[0] : b;
            return b._a && 0 < b._a;
          },
          stopAnimation: function (b, d, c) {
            if (b && b.length) {
              var f = b[0];
              h(b, "transition", "all " + (c ? "1" : "0") + "ms");
              d && (f._a = 0);
              a.reflowCssChanges(b);
              clearTimeout(b.data("aAnimateTimeoutId"));
              b.data("aAnimateOnComplete") && b.data("aAnimateOnComplete")();
            }
          },
        };
      return l.capabilities.transition ? m : n;
    }
  );
  ("use strict");
  n.when("A", "jQuery").register("a-image-lazy-loader", function (a, l) {
    function e() {
      l(".a-lazy-loaded").each(function () {
        d.set(l(this));
      });
    }
    function h() {
      var h = [];
      l(".a-lazy-loaded").each(function () {
        var p = l(this);
        p.data("src") &&
          k(p) &&
          (p.load(function () {
            a.trigger("a:image:lazyLoaded", p);
            e();
          }),
          h.push(p),
          p.removeClass("a-lazy-loaded"),
          d.remove(p));
      });
      a.each(h, function (a) {
        a.attr("src", a.data("src"));
      });
    }
    function k(a) {
      d.get(a) || d.set(a);
      var e = l(m),
        k = e.scrollTop();
      e = m.innerHeight ? m.innerHeight : e.height();
      var h = k + e + 500;
      k -= 500;
      var b = d.get(a);
      a = b.top;
      b = b.height;
      var g = a + b;
      return (
        (a >= k && a < h) || (g > k && g <= h) || (b > e && a <= k && g >= h)
      );
    }
    var d = (function () {
      var a = {},
        d = 0;
      return {
        get: function (d) {
          return a[d.data("cacheKey")];
        },
        set: function (e) {
          e.data("cacheKey") || (e.data("cacheKey", d), d++);
          a[e.data("cacheKey")] = {top: e.offset().top, height: e.height()};
        },
        remove: function (d) {
          d.data("cacheKey") && delete a[d.data("cacheKey")];
        },
      };
    })();
    e();
    h();
    a.on("scroll", function () {
      h();
    });
    a.on(
      "scroll",
      a.debounce(function () {
        e();
        h();
      }, 250)
    );
    a.on("resize", h);
    a.on("a:image:lazyLoad", h);
    a.on.ready(h);
  });
  ("use strict");
  n.register("a-image-url-key-handler", function () {
    return {
      generate: function (a, l) {
        return a;
      },
      parse: function (a) {
        return {url: a};
      },
    };
  });
  ("use strict");
  n.when(
    "jQuery",
    "a-util",
    "a-events",
    "a-defer",
    "p-detect",
    "a-image-url-key-handler"
  ).register("a-image", function (a, l, e, h, k, d) {
    function p(b) {
      b = a(b);
      var c = b.data("a-dynamic-image");
      if (c && "object" === typeof c) {
        var d = b.data("a-dynamic-image-container");
        "undefined" === typeof d &&
          ((d = b.closest(".a-dynamic-image-container")),
          0 === d.length && (d = b.parent()),
          b.data("a-dynamic-image-container", d));
        var f =
            k.capabilities.hires && m.devicePixelRatio ? m.devicePixelRatio : 1,
          e = d.width() * f,
          h = d.height() * f,
          p = Number.MAX_VALUE,
          r = Number.MAX_VALUE,
          n = b.attr("src") || "",
          t,
          q = e / h;
        l.each(c, function (b, a) {
          var c = parseInt(b[0], 10);
          b = parseInt(b[1], 10);
          c -= h;
          b -= e;
          c = 1 <= q ? b : c;
          Math.abs(c) < r && 0 <= c && ((r = Math.abs(c)), (t = a));
          Math.abs(c) < p && ((p = Math.abs(c)), (n = a));
        });
        t && (n = t);
        g.schedule(n, b);
        g.fill();
        return n;
      }
    }
    function r() {
      a("img.a-dynamic-image").each(function () {
        a(this).data("a-manual-replacement") || p(this);
      });
    }
    var n = document.getElementsByTagName("img"),
      t = {},
      b = 0,
      g = (function () {
        var a = [],
          e = {};
        return {
          schedule: function (b, c) {
            b = d.generate(b, c.attr("crossorigin"));
            e[b] || (a.push(b), (e[b] = !0));
            t[b] = t[b] || [];
            for (var f = 0; f < t[b].length; f++) if (c.is(t[b][f])) return;
            t[b].push(c);
          },
          fill: function () {
            for (var d = 0; d < 2 - b; d++)
              if (0 < a.length) {
                var f = a.shift();
                e[f] = !1;
                c.load(f);
              }
          },
        };
      })(),
      c = (function () {
        function c(b) {
          var a = t[b],
            c = d.parse(b).url;
          a &&
            (l.each(a, function (b) {
              b.data("a-image-replaced") !== c &&
                (b.data("a-image-replaced", c),
                h.defer(function () {
                  b.attr("src", c);
                  e.trigger("a:image:load", {$imageElement: b, url: c});
                  var a = b.data("a-image-name");
                  a &&
                    e.trigger("a:image:load:" + a, {$imageElement: b, url: c});
                }));
            }),
            (t[b] = []));
        }
        var k = {};
        return {
          load: function (a) {
            if (k[a]) c(a);
            else if (!1 !== k[a]) {
              var f = new Image(),
                e = (f.onload = l.once(function () {
                  b--;
                  c(a);
                  k[a] = !0;
                  g.fill();
                }));
              f.onerror = function () {
                b--;
                k[a] = !1;
                g.fill();
              };
              b++;
              h.defer(function () {
                var b = d.parse(a),
                  c = b.crossOrigin;
                c && (f.crossOrigin = c);
                f.src = b.url;
                f.complete && h.defer(e);
              });
            }
          },
          poll: function () {
            l.isPageHidden() ||
              l.each(n, function (b) {
                b = a(b);
                !b.data("a-hires") ||
                  b.data("a-hires-loaded") ||
                  b.data("a-manual-replacement") ||
                  b.is(":hidden") ||
                  !l.onScreen(b) ||
                  (g.schedule(b.data("a-hires"), b),
                  b.data("a-hires-loaded", !0));
              });
          },
        };
      })();
    k.capabilities.hires &&
      e.on.ready(function () {
        l.interval(function () {
          c.poll();
          g.fill();
        }, 2e3);
      });
    e.on.ready(r);
    a(m).resize(r);
    return {
      loadHiResImage: function (b) {
        var c = [];
        a(b).each(function () {
          var b = a(this),
            d = b.data("a-hires");
          d && (g.schedule(d, b), g.fill(), c.push(d));
          b.data("a-hires-loaded", !0);
        });
        return c;
      },
      loadDynamicImage: function (b) {
        var c = [];
        a(b).each(function () {
          c.push(p(this));
        });
        return c;
      },
      loadImageManually: function (b, c) {
        var d = [];
        a(b, c).each(function () {
          var b = a(this);
          if (!b.data("a-image-already-loaded")) {
            b.data("a-image-already-loaded", !0);
            var c = p(b),
              f = a("\x3cimg\x3e").attr("src", c || b.data("a-image-source"));
            d.push(c);
            c = "" + this.className;
            var e = b.data("a-extra-classes");
            e && (c += " " + e);
            f.attr("class", c);
            f.attr("id", this.id);
            f.attr("style", b.attr("style"));
            f.attr("alt", b.attr("alt"));
            f.attr("usemap", b.attr("usemap"));
            f.attr("title", b.attr("title"));
            f.attr("role", b.attr("role"));
            (c = b.data("a-image-crossorigin")) && f.attr("crossorigin", c);
            l.each(this.attributes, function (b) {
              b &&
                b.name &&
                (0 === b.name.indexOf("data-") ||
                  0 === b.name.indexOf("aria-")) &&
                f.attr(b.name, b.value);
            });
            f.data(b.data());
            b.replaceWith(f);
          }
          return d;
        });
      },
      loadDescendantImagesManually: function (b, c) {
        b = a(b, c)
          .find("div.a-manually-loaded")
          .filter(function () {
            return !a(this).data("a-image-already-loaded");
          });
        return this.loadImageManually(b);
      },
    };
  });
  n.register("a-class", function () {
    function a() {}
    var l = /xyz/.test(function () {
      xyz;
    })
      ? /\b_super\b/
      : /.*/;
    a.extend = function (e) {
      var h = this.prototype,
        k = Object.create
          ? Object.create(h)
          : (function (a) {
              function d() {}
              d.prototype = a;
              return new d();
            })(h),
        d;
      for (d in e)
        k[d] =
          "function" === typeof e[d] &&
          "function" === typeof h[d] &&
          l.test(e[d])
            ? (function (a, d) {
                return function () {
                  var e = this._super;
                  this._super = h[a];
                  var k = d.apply(this, arguments);
                  this._super = e;
                  return k;
                };
              })(d, e[d])
            : e[d];
      e =
        "function" === typeof k.init
          ? k.hasOwnProperty("init")
            ? k.init
            : function () {
                h.init.apply(this, arguments);
              }
          : function () {};
      e.prototype = k;
      k.constructor = e;
      e.extend = a.extend;
      return e;
    };
    return {
      createClass: function (e) {
        return a.extend(e);
      },
    };
  });
  ("use strict");
  n.register("a-constants", function () {
    return {
      constants: {
        keycodes: {
          BACKSPACE: 8,
          TAB: 9,
          ENTER: 13,
          ESCAPE: 27,
          SPACE: 32,
          LEFT_ARROW: 37,
          UP_ARROW: 38,
          RIGHT_ARROW: 39,
          DOWN_ARROW: 40,
          DELETE: 46,
          HOME: 36,
          END: 35,
        },
        declarativeEvents:
          "blur click dblclick focus focusin focusout mousedown mouseup mouseenter mouseleave mousemove change submit touchstart touchend touchmove touchcancel keydown keyup keypress MSPointerDown pointerdown MSPointerUp pointerup MSPointerMove pointermove MSPointerCancel pointercancel MSPointerOver pointerenter MSPointerOut pointerleave",
        HIDE_CLASS: "aok-hidden",
        BROWSER_EVENTS: {
          SCROLL: "scroll",
          RESIZE: "resize",
          ORIENTATION_CHANGE: "orientationChange",
        },
        PAGESTATE_LOADED_MODULE_PREFIX: "page-state-loaded:",
        NOOP: function () {},
      },
    };
  });
  ("use strict");
  n.when("jQuery", "a-detect", "a-events", "a-util", "a-defer").register(
    "a-browser-events",
    function (a, l, e, h, k) {
      function d() {
        return m.innerHeight
          ? m.innerHeight
          : document.documentElement.clientHeight;
      }
      function p() {
        return m.innerWidth
          ? m.innerWidth
          : document.documentElement.clientWidth;
      }
      function n() {
        return m.innerWidth
          ? Math.round(
              (document.documentElement.clientWidth / m.innerWidth) * 10
            ) / 10
          : 1;
      }
      function y(b) {
        switch (b) {
          case c.ALL:
            b = "orientation height width zoom scrollLeft scrollTop".split(" ");
            break;
          case c.SCROLL:
            b = ["scrollLeft", "scrollTop"];
            break;
          case c.ZOOM:
            b = ["height", "width", "zoom", "scrollLeft", "scrollTop"];
            break;
          default:
            b = ["orientation", "height", "width", "scrollLeft", "scrollTop"];
        }
        for (var a = {}, e, k; (k = b.pop()) !== q; )
          (e = f[k]),
            "orientation" === k
              ? (f[k] =
                  m.orientation === q ? (p() > d() ? 90 : 0) : m.orientation)
              : "height" === k
              ? (f[k] = d())
              : "width" === k
              ? (f[k] = p())
              : "scrollTop" === k
              ? (f[k] = m.scrollY ? m.scrollY : g.scrollTop())
              : "scrollLeft" === k
              ? (f[k] = m.scrollX ? m.scrollX : g.scrollLeft())
              : "zoom" === k && (f[k] = n()),
            f[k] !== e && (a[k] = e);
        return a;
      }
      function t(b) {
        if ((b = w[b]))
          (b.pollCounter = b.maxPollCount),
            b.intervalId ||
              (b.intervalId = setInterval(b.handler, b.pollInterval));
      }
      function b(b) {
        (b = w[b]) &&
          b.intervalId &&
          (clearInterval(b.intervalId), (b.intervalId = 0));
      }
      var g = a(m),
        c = {
          ORIENTATION_CHANGE: "orientationchange",
          SCROLL: "scroll",
          RESIZE: "resize",
          ZOOM: "zoom",
          ALL: "all",
        },
        f = {
          scrollLeft: 0,
          scrollTop: 0,
          height: d(),
          width: p(),
          orientation:
            m.orientation === q ? (p() > d() ? 90 : 0) : m.orientation,
          zoom: n(),
        };
      e.on("beforeReady", function () {
        y(c.ALL);
      });
      var x = {speed: 0, degree: 0, direction: "", positionX: 0, positionY: 0},
        v = [],
        B;
      g.bind(
        "mousemove",
        h.throttle(function (b) {
          b = {x: b.clientX, y: b.clientY};
          if (B) {
            var a = B,
              c = 0,
              d = 0;
            v.push({
              speed:
                (Math.sqrt(Math.pow(b.x - a.x, 2) + Math.pow(b.y - a.y, 2)) /
                  50) *
                10,
              degree: Math.atan2(b.y - a.y, b.x - a.x) / (Math.PI / 180),
            });
            4 < v.length && (v = v.slice(-4));
            a = v.length;
            for (var f = 0; f < a; f++) (c += v[f].speed), (d += v[f].degree);
            c = Number((c / a).toFixed(2));
            d = Math.round(d / a);
            x = {
              speed: c,
              degree: d,
              direction:
                0 <= d
                  ? 157.5 < d
                    ? "W"
                    : 112.5 < d
                    ? "SW"
                    : 67.5 < d
                    ? "S"
                    : 22.5 < d
                    ? "SE"
                    : "E"
                  : -157.5 > d
                  ? "W"
                  : -112.5 > d
                  ? "NW"
                  : -67.5 > d
                  ? "N"
                  : -22.5 > d
                  ? "NE"
                  : "E",
              positionX: b.x,
              positionY: b.y,
            };
            B = b;
          } else b && (B = b);
        }, 50)
      );
      g.bind(
        c.SCROLL,
        h.throttle(function () {
          var b = y(c.SCROLL);
          e.trigger(c.SCROLL, f, b);
        }, 100)
      );
      var w = {};
      h.each([c.RESIZE, c.ZOOM], function (b) {
        w[b] = {
          handler: function () {},
          lastViewport: h.copy(f),
          maxPollCount: 5,
          pollCounter: 5,
          pollInterval: 100,
          intervalId: 0,
        };
      });
      w.resize.handler = function () {
        var a = [],
          d = w.resize;
        y("resize");
        var g = h.diff(f, d.lastViewport);
        g.orientation && a.push(c.ORIENTATION_CHANGE);
        g.width || g.height
          ? a.push(c.RESIZE)
          : l.capabilities.isIETouchCapable && g.scrollTop && a.push(c.RESIZE);
        a.length &&
          ((d.lastViewport = h.copy(f)),
          h.each(a, function (b) {
            e.trigger(b, f, g);
          }));
        0 === --d.pollCounter && b(c.RESIZE);
      };
      w.resize.pollInterval = 100;
      w.resize.maxPollCount = 10;
      g.bind(c.RESIZE, function (b) {
        t(c.RESIZE);
      });
      w.zoom.handler = function () {
        y(c.ZOOM);
        var a = w.zoom,
          d = h.diff(f, a.lastViewport);
        d.zoom && ((a.lastViewport = h.copy(f)), e.trigger(c.ZOOM, f, d));
        0 === --a.pollCounter && b(c.ZOOM);
      };
      w.zoom.pollInterval = 200;
      l.capabilities.android &&
        g.bind("touchcancel", function (b) {
          2 === b.originalEvent.changedTouches.length &&
            ((w.zoom.maxPollCount = 15), t(c.ZOOM));
        });
      l.capabilities.ios &&
        g.bind("touchend", function (b) {
          1 === b.originalEvent.touches.length &&
            ((w.zoom.maxPollCount = 1), t(c.ZOOM));
        });
      l.capabilities.ios ||
        l.capabilities.android ||
        g.bind("resize", function (b) {
          w.zoom.maxPollCount = 5;
          t(c.ZOOM);
        });
      return {
        viewport: function (b) {
          b && y(c.ALL);
          return h.copy(f);
        },
        cursor: function () {
          return h.copy(x);
        },
        scrollBarWidth: function (b) {
          if (
            b ||
            (document && document.body && document.body.scrollHeight
              ? document.body.scrollHeight
              : 0) > d()
          ) {
            b = document.createElement("div");
            b.style.visibility = "hidden";
            b.style.width = "100%";
            b.style.overflowX = "scroll";
            document.body.appendChild(b);
            var a = b.offsetHeight;
            document.body.removeChild(b);
            return a;
          }
          return 0;
        },
      };
    }
  );
  ("use strict");
  n.register("a-analytics", function () {
    function a(a, h) {
      var e = m && m.ue && m.ue.count;
      if (e && a) {
        var d = "aui:" + a;
        1 < arguments.length && e(d, h);
        return e(d);
      }
    }
    var l = m && m.ue && m.ue.tag;
    return {
      increment: function (e, h) {
        if (e) {
          var k = a(e) || 0;
          a(e, k + (h || 1));
        }
      },
      count: a,
      logError: function (a, h, k) {
        m.ueLogError &&
          m.ueLogError({message: a}, {logLevel: h, attribution: k});
      },
      tag: function (a) {
        l && a && l("aui:" + a);
      },
    };
  });
  ("use strict");
  n.when("a-util").register("a-request-animation-frame", function (a) {
    for (
      var l = 0, e = ["ms", "moz", "webkit", "o"], h = 0;
      h < e.length && !m.requestAnimationFrame;
      ++h
    )
      (m.requestAnimationFrame = m[e[h] + "RequestAnimationFrame"]),
        (m.cancelAnimationFrame =
          m[e[h] + "CancelAnimationFrame"] ||
          m[e[h] + "CancelRequestAnimationFrame"]);
    m.requestAnimationFrame ||
      (m.requestAnimationFrame = function (e, d) {
        var k = a.now(),
          h = Math.max(0, 16 - (k - l));
        d = m.setTimeout(function () {
          e(k + h);
        }, h);
        l = k + h;
        return d;
      });
    m.cancelAnimationFrame ||
      (m.cancelAnimationFrame = function (a) {
        clearTimeout(a);
      });
    return {
      requestAnimationFrame: function (a, d) {
        return m.requestAnimationFrame(a, d);
      },
      cancelAnimationFrame: function (a) {
        m.cancelAnimationFrame(a);
      },
    };
  });
  ("use strict");
  n.when("jQuery").register("a-form-controls-api", function (a) {
    var l = 0,
      e = function (e) {
        return e && e.jquery ? e : e && 1 === e.nodeType ? a(e) : null;
      },
      h = function (a, d, h) {
        var k = e(a);
        if (!k || 1 !== k.length) return !1;
        a = k.find("input").first();
        d !== q &&
          ((d = !!d),
          k.hasClass("a-touch-multi-select") &&
            (k
              .find("i.a-icon")
              .first()
              .toggleClass("a-icon-touch-multi-select-active", d)
              .toggleClass("a-icon-touch-multi-select", !d),
            k.attr("aria-checked", d)),
          a.prop("checked") !== d && a.prop("checked", d).trigger("change"));
        h !== q &&
          ((h = !!h), a.prop("disabled") !== h && a.prop("disabled", h));
      };
    return {
      findFormElementContainer: function (h) {
        if ((h = e(h)) && 1 === h.length) {
          var d = h.closest("form");
          0 === d.length &&
            ((d = h.closest("fieldset")), 0 === d.length && (d = a(document)));
          return d;
        }
      },
      toggleCheckboxState: function (a) {
        a = e(a);
        if (a && 1 === a.length) {
          var d = a.find("input").first();
          h(a, !d[0].checked);
        }
      },
      setCheckboxState: h,
      setRadioState: h,
      normalizeElement: function (a) {
        if ((a = (a = e(a)) ? a : e(this)) && 1 === a.length) {
          var d = a.find("input").first();
          d.attr("type");
          var k = a.hasClass("a-touch-multi-select");
          a.attr("id") ||
            d.attr("id") ||
            (k && (!k || a.parent().attr("id"))) ||
            ((k = "a-form-controls-autoid-" + l),
            a
              .attr("aria-labelledby", k)
              .find(
                ".a-checkbox-label, .a-radio-label, .a-touch-multi-select-item-label"
              )
              .attr("id", k),
            l++);
          h(a, d[0].checked, d[0].disabled);
        }
      },
      normalizeFieldsets: function (e) {
        a(e)
          .closest("fieldset")
          .each(function (d, e) {
            d = a(e);
            e = d.find("legend").first();
            if (e.length) {
              var h = e.attr("id");
              h || ((h = "a-form-controls-autoid-" + l), e.attr("id", h), l++);
              d.attr("aria-describedby", h);
            }
          });
      },
    };
  });
  ("use strict");
  n.when("a-util", "a-constants").execute("prepare-a-weblab", function (a, l) {
    n.when(
      l.constants.PAGESTATE_LOADED_MODULE_PREFIX + "a-wlab-states"
    ).register("a-weblab", function (e) {
      function h(a) {
        m || (q[a] = p[a]);
        return (m && m[a]) || p[a];
      }
      function k(a) {
        return h(a) || "C";
      }
      function d(a) {
        return h(a) || "C";
      }
      var p = e || {},
        m,
        q = {};
      n.when(
        l.constants.PAGESTATE_LOADED_MODULE_PREFIX + "a-ltree-states"
      ).execute(function (d) {
        m = d || {};
        a.each(a.keys(q), function (b) {
          (m[b] || q[b]) &&
            m[b] !== q[b] &&
            n.log(
              "a-weblab returned wrong value for " +
                b +
                ". It returned " +
                q[b] +
                ". it is set as " +
                m[b] +
                " at a-ltree-states."
            );
        });
      });
      return {
        is: function (a, b, e) {
          return (e ? d : k)(a) === b;
        },
        isActive: function (a) {
          return !!h(a);
        },
        noTrigger: k,
        trigger: d,
      };
    });
  });
  ("use strict");
  n.declare("prv:a-post-atf-catchdomready", !0);
  n.when("a-util", "a-defer", "prv:a-post-atf-catchdomready").register(
    "prv:a-post-atf",
    function (a, l, e) {
      function h() {
        p ||
          ((p = !0),
          a.each(d, function (a) {
            l.defer(a);
          }),
          (d = []));
      }
      function k() {
        e && h();
      }
      var d = [],
        p = !1;
      n.when("af", "cf").execute("flush_queued_functions_after_ATF", h);
      n.when("a-domready").execute(
        "flush_queued_functions_after_domready",
        function () {
          a.delay(k, 500);
        }
      );
      return {
        execute: function (a) {
          p ? l.defer(a) : d.push(a);
        },
      };
    }
  );
  ("use strict");
  n.register("prv:a-tnr", function () {
    function a() {
      for (var a = Array(arguments.length), h = 0; h < a.length; ++h)
        a[h] = arguments[h];
      return a;
    }
    function l() {}
    return {
      findTnrAttribute: function () {
        return null;
      },
      ack: l,
      ackDelegated: l,
      ackDeclarative: l,
      wrapJqBindArgs: function () {
        return a.apply(null, arguments).slice(1);
      },
      wrapJqUnbindArgs: a,
      wrapDeclarativeActionHandler: function (a) {
        return a;
      },
    };
  });
  ("use strict");
  n.register("prv:a-collect-p-debug", function () {
    var a = !1;
    return function () {
      a ||
        ((a = !0),
        n.when("prv:p-debug", "afterLoad").execute(function (a) {
          a = JSON && JSON.stringify ? JSON.stringify(a) : "{}";
          n.log(a, "WARN", "[AUI] p-debug");
        }));
    };
  });
  ("use strict");
  n.when("A").register("a-component-mixins", function (a) {
    function l(e) {
      for (var d = 0; d < e.length; d++)
        if (0 > a.indexOfArray(h, e[d])) return !1;
      return !0;
    }
    var e = 0,
      h = a.constants.declarativeEvents.split(" ");
    return {
      show: function () {
        this._$element.removeClass("a-hidden aok-hidden").show();
        return this;
      },
      hide: function () {
        this._$element.addClass("aok-hidden");
        return this;
      },
      toggle: function () {
        return this._$element.hasClass("aok-hidden")
          ? this.show()
          : this.hide();
      },
      size: function () {
        return this._$element.size();
      },
      isEmpty: function () {
        return 0 === this._$element.size();
      },
      on: function (h, d) {
        var k = a.parseFunctionName(d);
        k || n.error.call({}, "Please name all asynchronous event callbacks");
        if ((h = h ? h.split(" ") : q)) {
          this.fnMap = this.fnMap || {};
          l(h) || n.error.call({}, "That event is not supported!");
          var m = this;
          a.each(
            h,
            function (h) {
              this.fnMap[h] = this.fnMap[h] || [];
              var l = (this.fnMap[h][d] = "a-component-event-" + e++);
              a.declarative(l, h, function () {
                try {
                  d.apply(m, m.callbackArgs || []);
                } catch (b) {
                  n.logError.call(
                    {},
                    b,
                    "Error occurred in an asynchronous event callback",
                    "FATAL",
                    (d.caller || "") + h + "handler:" + (k || "anonymous")
                  );
                }
              });
              a.declarative.create(m._$element, l);
            },
            m
          );
        }
      },
      off: function (e, d) {
        e = e ? e.split(" ") : q;
        this.fnMap ||
          n.error.call({}, "There are no callbacks assigned to this component");
        e && d
          ? a.each(
              e,
              function (e) {
                try {
                  a.declarative.remove(this._$element, this.fnMap[e][d]),
                    delete this.fnMap[e][d];
                } catch (r) {
                  n.error.call(
                    {},
                    "The component is not bound to a callback with name " +
                      a.parseFunctionName(d) || "anonymous for event " + e
                  );
                }
              },
              this
            )
          : d || e
          ? !d && e
            ? a.each(
                e,
                function (a) {
                  for (var d in this.fnMap[a])
                    this.fnMap[a].hasOwnProperty(d) && this.off(a, d);
                  delete this.fnMap[a];
                },
                this
              )
            : n.error.call(
                {},
                "Please provide an event associated with the callback"
              )
          : (a.declarative.remove(this._$element), delete this.fnMap);
      },
      trigger: function (e, d) {
        this.callbackArgs = d || [];
        a.$.fn.trigger.call(this._$element, e);
      },
    };
  });
  ("use strict");
  n.when(
    "A",
    "jQuery",
    "a-component-mixins",
    "a-analytics",
    "prv:a-sampler"
  ).register("a-component", function (a, l, e, h, k) {
    var d = a.createClass({
      init: function (d, e) {
        a.contains(d, ".a-") &&
          n.error(
            "{API} Cannot create components using 'a-' selectors. Apply your own CSS class or ID to select this element.",
            "API",
            "component"
          );
        this._$element = l(d, e);
        this._trackApi();
      },
      _trackApi: function () {
        this._componentName &&
          k("AUI API Analytics") &&
          h.increment("api:" + this._componentName);
      },
    });
    return {
      create: function (h) {
        var k = h.mixin;
        k && delete h.mixin;
        h = d.extend(h);
        k && a.mixin(h.prototype, e, k);
        return h;
      },
    };
  });
  ("use strict");
  n.when("A", "jQuery", "a-component").register("a-alert", function (a, l, e) {
    var h = ["error", "success", "warning", "info"],
      k = a
        .map(h, function (a) {
          return "a-alert-" + a;
        })
        .join(" "),
      d = a
        .map(h, function (a) {
          return "a-alert-inline-" + a;
        })
        .join(" "),
      m = document.createElement("h4");
    m.className = "a-alert-heading";
    var r = l(m),
      q = e.create({
        _componentName: "alert",
        init: function (a, b) {
          this._super(a, b);
          this._$element = this._$element.filter(".a-alert, .a-alert-inline");
          this._$heading = this._$element.find(".a-alert-heading");
          this._$content = this._$element.find(".a-alert-content");
        },
        mixin: ["show", "hide", "size", "isEmpty"],
        heading: function (a) {
          if ("undefined" === typeof a) return this._$heading.text();
          this._$heading.length
            ? this._$heading.text(a)
            : (this._$heading = r.clone().text(a).insertBefore(this._$content));
          return this;
        },
        removeHeading: function () {
          this._$heading.remove();
          this._$heading = l();
          return this;
        },
        text: function (a) {
          if ("undefined" === typeof a) return this._$content.text();
          this._$content.text(a);
          return this;
        },
        html: function (a) {
          if ("undefined" === typeof a) return this._$content.html();
          this._$content.html(a);
          return this;
        },
        type: function (e) {
          -1 === a.indexOfArray(h, e) &&
            n.error(
              "{API} Alert type must be one of [error, success, warning, info].",
              "API",
              "alert"
            );
          this._$element.each(function (b, a) {
            b = l(a);
            a = "a-alert-";
            b.hasClass("a-alert-inline")
              ? ((a += "inline-"), b.removeClass(d))
              : b.removeClass(k);
            b.addClass(a + e);
          });
          return this;
        },
      });
    return function (a, b) {
      return new q(a, b);
    };
  });
  ("use strict");
  n.when("jQuery", "a-component", "a-form-controls-api").register(
    "a-checkbox",
    function (a, l, e) {
      var h = e.setCheckboxState,
        k = l.create({
          _componentName: "checkbox",
          init: function (a, e) {
            this._super(a, e);
            this._$element = this._$element.closest(".a-checkbox");
            this._$input = this._$element.find("[type\x3dcheckbox]");
          },
          mixin: ["show", "hide", "size", "isEmpty"],
          check: function (a) {
            a = void 0 === a ? !0 : a;
            this._$element.each(function () {
              h(this, a);
            });
            return this;
          },
          uncheck: function () {
            return this.check(!1);
          },
          toggleChecked: function () {
            this._$element.each(function () {
              e.toggleCheckboxState(this);
            });
            return this;
          },
          isChecked: function () {
            for (var a = 0, e = this._$input.length; a < e; a++)
              if (!this._$input[a].checked) return !1;
            return !0;
          },
          isUnchecked: function () {
            for (var a = 0, e = this._$input.length; a < e; a++)
              if (this._$input[a].checked) return !1;
            return !0;
          },
          enable: function (a) {
            a = void 0 === a ? !0 : a;
            this._$element.each(function () {
              h(this, void 0, !a);
            });
            return this;
          },
          disable: function () {
            return this.enable(!1);
          },
          toggleEnabled: function () {
            for (var a = 0, e = this._$input.length; a < e; a++)
              h(this._$element[a], void 0, !this._$input[a].disabled);
            return this;
          },
          isEnabled: function () {
            for (var a = 0, e = this._$input.length; a < e; a++)
              if (this._$input[a].disabled) return !1;
            return !0;
          },
          isDisabled: function () {
            for (var a = 0, e = this._$input.length; a < e; a++)
              if (!this._$input[a].disabled) return !1;
            return !0;
          },
          toggle: function (d) {
            "undefined" !== typeof d && (d = !!d);
            this._$element.each(function () {
              a(this).toggle(d);
            });
            return this;
          },
        });
      return function (a, e) {
        return new k(a, e);
      };
    }
  );
  ("use strict");
  n.when("A", "a-component").register("a-meter", function (a, l) {
    var e = l.create({
      _componentName: "meter",
      init: function (a, e) {
        this._super(a, e);
        this._$element = this._$element.filter(".a-meter, .a-meter-with-txt");
        this._$bar = this._$element.find(".a-meter-bar");
        this._$progressTxt = this._$element.find(".a-meter-progress-txt");
      },
      mixin: ["show", "hide", "size", "isEmpty"],
      get: function () {
        return {percent: this.percent(), txt: this.text()};
      },
      enable: function () {
        this._$element.removeClass("a-inactive");
        return this;
      },
      disable: function () {
        this._$element.addClass("a-inactive");
        return this;
      },
      isEnabled: function () {
        return !this._$element.hasClass("a-inactive");
      },
      percent: function (e) {
        if ("undefined" === typeof e)
          return (e = this._$bar.get(0).style.width), parseInt(e, 10);
        a.isFiniteNumber(e) ||
          n.error(
            "{API}  Meter percent should be a number between 0 and 100",
            "a-meter",
            "setProgress"
          );
        e = Math.min(100, Math.max(0, e));
        e += "%";
        this._$bar.css({width: e});
        this._$element.attr({"aria-label": e, "aria-valuenow": e});
        return this;
      },
      text: function (a) {
        if ("undefined" === typeof a) return this._$progressTxt.text();
        this._$progressTxt.text(a);
        return this;
      },
      set: function (a, e) {
        this.percent(a);
        e && this.text(e);
        return this;
      },
    });
    return function (a, k) {
      return new e(a, k);
    };
  });
  n.when("a-component").register("a-spinner", function (a) {
    var l = a.create({
      _componentName: "spinner",
      init: function (a, h) {
        this._super(a, h);
        this._$element = this._$element.filter(
          ".a-spinner-wrapper, .a-spinner"
        );
      },
      mixin: ["show", "hide", "isEmpty", "size"],
      remove: function () {
        this._$element.remove();
      },
    });
    return function (a, h) {
      return new l(a, h);
    };
  });
  ("use strict");
  n.register("a-ua", function () {
    return {
      compareVersions: function (a, l, e) {
        var h = function (a) {
          n.error(
            "Versions are not comparable. " + a,
            "A - extras",
            "compareVersions"
          );
        };
        e = e || ".";
        ("string" === typeof a &&
          "string" === typeof l &&
          "string" === typeof e &&
          "" !== a &&
          "" !== l) ||
          h("Input values are not valid.");
        a = a.split(e);
        l = l.split(e);
        e = Math.max(a.length, l.length);
        for (var k = 0; k < e; k++) {
          var d = k < a.length ? Number(a[k]) : 0,
            m = k < l.length ? Number(l[k]) : 0;
          (!isNaN(d) && isFinite(d) && !isNaN(m) && isFinite(m)) ||
            h("Piece of one version number evaluates to NaN or +/- Infinity.");
          if (d < m) return -1;
          if (d > m) return 1;
        }
        return 0;
      },
    };
  });
  ("use strict");
  n.when("a-analytics", "prv:p-debug", "ready").execute(function (a, l) {
    n.declare("prv:a-logTrigger", function (e) {
      var h = (l[e] && l[e].registered) || 0,
        k = 0,
        d = 0,
        m;
      for (m in l)
        if (l.hasOwnProperty(m)) {
          var n = l[m];
          n.end && n.end <= h && (k++, (d += n.end - n.start));
        }
      a.count("blocking-count:" + e, k);
      a.count("blocking-time:" + e, Math.round(d));
    });
  });
  ("use strict");
  n.when("a-analytics", "afterLoad").execute("a-doctype-test", function (a) {
    (document.doctype &&
      document.doctype.name &&
      "html" === document.doctype.name.toLowerCase()) ||
      (n.log(
        "Missing or Invalid HTML doctype. Please refer to http://w?AUI/LogMessages#HDOCTYPE for more details.",
        "WARN"
      ),
      a.increment("a-doctype-issue"));
  });
  ("use strict");
  n.register("prv:a-sampler-inclusion", function () {
    return {"AUI API Analytics": 0.01 > Math.random()};
  });
  n.when("prv:a-sampler-inclusion").register("prv:a-sampler", function (a) {
    return function (l) {
      return a.hasOwnProperty(l) && a[l];
    };
  });
  ("use strict");
  n.when("A", "3p-promise", "load").register("a-pcv", function (a, l) {
    var e;
    return {
      getData: function () {
        e ||
          (e = new l(function (a, e) {
            var d = m.pcv.AmazonUI;
            d
              ? (document.documentElement.setAttribute("data-aui-version", d),
                a(d))
              : e(
                  Error(
                    "Package closure version of AmazonUI is not found on the page"
                  )
                );
          }));
        return e;
      },
    };
  });
});
/* ******** */
(function (g) {
  var c = window.AmazonUIPageJS || window.P,
    n = c._namespace || c.attributeErrors,
    e = n ? n("AmazonUIBaseJS@declarative", "AmazonUI") : c;
  e.guardFatal
    ? e.guardFatal(g)(e, window)
    : e.execute(function () {
        g(e, window);
      });
})(function (g, c, n) {
  "use strict";
  g.when(
    "jQuery",
    "a-util",
    "a-events",
    "a-constants",
    "prv:a-guard",
    "prv:csa-logger"
  ).register("a-declarative", function (e, k, p, c, g, n) {
    function q(a) {
      var d = e(a.currentTarget),
        b = e(a.target);
      if ("submit" === a.type) {
        var l = b.closest("form");
        l.length && (b = l);
      }
      if ((l = d.data("action")))
        (a = {
          $target: b,
          $currentTarget: d,
          targetTag: b.prop("tagName").toLowerCase(),
          type: a.type,
          $event: a,
          $declarativeParent: d,
        }),
          t(l, a);
    }
    function t(a, d) {
      var b = d.$event,
        l = d.$target,
        e = d.$currentTarget,
        c = d.type;
      a = a.split(" ");
      k.each(a, function (a) {
        var h = r[a] || {},
          f = e.data(a),
          m = k.extend({}, d, {action: a, data: f});
        a = "a:declarative:" + a;
        var g = a + ":" + c;
        p.trigger(a, m);
        p.trigger(g, m);
        m = !1;
        f ? (m = !!f.allowLinkDefault) : h && (m = !!h.allowLinkDefault);
        "click" !== b.type || m
          ? (h = !1)
          : ((h = l.closest("a")),
            (h =
              h.length &&
              ("#" === h[0].href ||
                b.currentTarget === h[0] ||
                h.parent(".a-declarative").length)));
        h && b.preventDefault();
      });
    }
    var r = {};
    e(document).delegate(".a-declarative", c.constants.declarativeEvents, q);
    e(document).delegate(
      ".a-gesture",
      "tap swipe swipe-horizontal swipe-vertical pan-horizontal pan-vertical doubleTap",
      q
    );
    c = function () {
      switch (arguments.length) {
        case 2:
          var a = arguments[0];
          var d = arguments[1];
          break;
        case 3:
          a = arguments[0];
          var b = arguments[1];
          d = arguments[2];
          break;
        case 4:
          a = arguments[0];
          b = arguments[1];
          var e = arguments[2];
          d = arguments[3];
      }
      if (a) {
        "string" === typeof a && (a = k.trim(a).split(" "));
        var f = this;
        k.each(a, function (a) {
          var c = "a:declarative:" + a;
          r[a] = e || {};
          b
            ? ((b = "string" === typeof b ? k.trim(b).split(" ") : b),
              k.each(b, function (b) {
                p.on.call(f, c + ":" + b, function () {
                  return g.guardTimeFn(f, d).apply(this, arguments);
                });
                ("click" != b && "swipe" != b) || n.declarative(a, b);
              }))
            : p.on.call(f, c, d);
        });
      }
    };
    c.create = function (a, d, b) {
      var c = a.jquery && a.length ? a : e(a);
      if (c.length && d) {
        var f = c.data("action");
        c.data("action", f ? f + " " + d : d).data(d, b ? b : {});
        c.addClass("a-declarative");
      }
      return a;
    };
    c.remove = function (a, d) {
      var b = a.jquery && a.length ? a : e(a);
      if (!b.length) return a;
      var c = b.data("action");
      if (!c) return a;
      var f = c.split(" ");
      d
        ? ((d = d.split(" ")),
          k.each(d, function (a) {
            var c = k.indexOfArray(f, a);
            0 <= c && (f.splice(c, 1), b.data(a, null));
          }))
        : (k.each(f, function (a) {
            b.data(a, null);
          }),
          (f = []));
      f.length
        ? b.data("action", f.join(" "))
        : b.data("action", null).removeClass("a-declarative");
      return a;
    };
    return {declarative: c};
  });
  g.register("prv:csa-logger", function () {
    if (c.csa)
      var e = csa("PageTiming", {
        producerId: "csa",
        schemaId: "csa.InteractionFailuresDependencies.1",
      });
    return {
      declarative: function (c, g) {
        e && e("mark", "functional:aui-da-" + c + ":" + g);
      },
      element: function (e, g) {
        c.csa &&
          e &&
          e instanceof HTMLElement &&
          csa("Content", {element: e})("mark", "functional:" + g);
      },
    };
  });
});
/* ******** */
(function (d) {
  var e = window.AmazonUIPageJS || window.P,
    m = e._namespace || e.attributeErrors,
    a = m ? m("AmazonUIBaseJS@preload", "AmazonUI") : e;
  a.guardFatal
    ? a.guardFatal(d)(a, window)
    : a.execute(function () {
        d(a, window);
      });
})(function (d, e, m) {
  "use strict";
  d.when(
    "3p-promise",
    "a-analytics",
    "a-util",
    "prv:a-preload-queue",
    "prv:a-preload-strategies"
  ).register("a-preload", function (a, e, g, k, d) {
    function n() {
      return new a(function (a) {
        setTimeout(a, 2500);
      });
    }
    function q(h, b) {
      var q = Date.now();
      b = d.getStrategy(h, b)(h, b);
      var g = a.race([b.promise, n()]).then(
        function () {
          e.increment("preload_fulfilled");
          return {url: h, success: !0, duration: Date.now() - q};
        },
        function (r) {
          e.increment("preload_failed");
          return {url: h, success: !1, reason: r};
        }
      );
      b.teardown && g.then(b.teardown);
      return g;
    }
    function l(h, b) {
      if ("string" === typeof h) {
        if (!h.trim()) return a.resolve();
        e.increment("preload_asks");
        return k(b).then(function (a) {
          return q(h, b).then(a);
        });
      }
      return g.isArray(h)
        ? a.all(
            h.map(function (a) {
              return l(a, b);
            })
          )
        : a.reject("not an URL or URL list");
    }
    return {preload: l};
  });
  d.when("3p-promise").register("prv:a-preload-queue", function (a) {
    function e() {
      if (g) {
        var a = (k.length ? k : n ? p : []).pop();
        a && (g--, a());
      }
    }
    var g = 5,
      k = [],
      p = [],
      n = !1;
    d.when("afterLoad").execute(function () {
      n = !0;
      for (var a = g; 0 < a; a--) e();
    });
    return function (d) {
      function l() {
        l = function () {};
        g++;
        e();
      }
      return new a(function (a) {
        var b = d ? k : p;
        b.splice(Math.round(Math.random() * b.length), 0, a);
        e();
      }).then(function () {
        return function (a) {
          l();
          return a;
        };
      });
    };
  });
  d.when("3p-promise", "a-util").register(
    "prv:a-preload-strategies",
    function (a, d) {
      function g(a) {
        a = ((a = /^(?:[^?#]+)[.]([a-z2]+)(?:[?#].*)?$/.exec(a)) && a[1]) || "";
        return "js" === a
          ? "script"
          : "css" === a
          ? "style"
          : /^gif|jpe?g|png$/.test(a)
          ? "image"
          : /^woff2?$/.test(a)
          ? "font"
          : "fetch";
      }
      function k(a, c) {
        var f = /^(https?:|[/][/])/;
        return (
          !new RegExp("^(" + c.protocol + ")?//" + c.hostname + "/").test(a) &&
          f.test(a)
        );
      }
      function p(r) {
        return function (c) {
          var f = document.createElement("link");
          return {
            promise: new a(function (a, b) {
              try {
                var d = g(c);
                f.rel = r;
                f.as = d;
                if ("font" == d || ("script" == d && k(c, e.location)))
                  f.crossOrigin = "anonymous";
                f.href = c;
                f.onerror = f.onload = a;
                document.head.appendChild(f);
              } catch (w) {
                b("failed to preload link loader");
              }
            }),
            teardown: function () {
              f && f.parentElement && f.parentElement.removeChild(f);
            },
          };
        };
      }
      function n(b) {
        var c = new Image();
        return {
          promise: new a(function (a, d) {
            try {
              (c.style.display = "none"),
                (c.onerror = c.onload = a),
                (c.src = b),
                document.documentElement.appendChild(c);
            } catch (u) {
              d("failed to preload image loader");
            }
          }),
          teardown: function () {
            c && c.parentElement && c.parentElement.removeChild(c);
          },
        };
      }
      function q(b) {
        return {
          promise: new a(function (a, d) {
            try {
              var c = new XMLHttpRequest();
              c.open("GET", b, !0);
              c.onreadystatechange = function () {
                4 == this.readyState && a();
              };
              c.send();
            } catch (u) {
              d("failed to preload ajax loader");
            }
          }),
        };
      }
      function l(b) {
        return {
          promise: new a(function (a, d) {
            try {
              var c = g(b),
                f = {
                  mode:
                    "font" == c || ("script" == c && k(b, e.location))
                      ? "cors"
                      : "no-cors",
                };
              e.fetch(b, f).finally(a);
            } catch (v) {
              d("failed to preload fetch loader");
            }
          }),
        };
      }
      var h = !!e.fetch,
        b = !1,
        m = !1;
      (function () {
        try {
          var a = document.createElement("link");
          b = a.relList.supports("preload");
          m = a.relList.supports("prefetch");
        } catch (c) {}
      })();
      m && p("prefetch");
      var t = b ? p("preload") : function () {};
      return {
        getStrategy: function (a, c) {
          a = g(a);
          return b && c ? t : "image" === a ? n : h ? l : q;
        },
      };
    }
  );
});
/* ******** */
(function (n) {
  var q = window.AmazonUIPageJS || window.P,
    u = q._namespace || q.attributeErrors,
    f = u ? u("AmazonUIBaseJS@touch", "AmazonUI") : q;
  f.guardFatal
    ? f.guardFatal(n)(f, window)
    : f.execute(function () {
        n(f, window);
      });
})(function (n, q, u) {
  "use strict";
  n.when("A", "jQuery").register("a-touch-highlight", function (f, l) {
    var g = {
      touchstart: function (a, b) {
        var c = l(a.currentTarget);
        a = {
          startX: b.clientX,
          startY: b.clientY,
          dX: 0,
          dY: 0,
          highlightTimer: f.delay(function () {
            c.addClass("a-touch-press");
          }, 110),
        };
        c.data("a-touch-track", a);
        l(".a-touch-press").removeClass("a-touch-press");
      },
      touchmove: function (a, b) {
        if ((a = l(a.currentTarget).data("a-touch-track")))
          (a.dX = b.clientX - a.startX),
            (a.dY = b.clientY - a.startY),
            7 < Math.abs(a.dX) &&
              7 < Math.abs(a.dY) &&
              clearTimeout(a.highlightTimer);
      },
      touchend: function (a, b) {
        a = l(a.currentTarget);
        if ((b = a.data("a-touch-track")))
          clearTimeout(b.highlightTimer), a.removeClass("a-touch-press");
      },
    };
    g.touchcancel = g.touchend;
    n.when("ready").execute("a-touchpress-listeners", function () {
      l(document).delegate(
        "a:not(.a-button-text), .a-button:not(.a-button-disabled), .a-accordion-row, .a-histogram-row, label, .a-touch-radio, .a-touch-checkbox",
        "touchstart touchmove touchend touchcancel",
        function (a) {
          g[a.type](a, a.originalEvent.changedTouches[0]);
        }
      );
    });
  });
  ("use strict");
  n.when("A").register("a-touch-recognize", function (f) {
    var l = {
        tap: function (a, b) {
          if (
            a.ended &&
            20 > Math.abs(a.deltaX) &&
            20 > Math.abs(a.deltaY) &&
            75 < a.duration
          )
            return {name: "tap", touchFinished: !1};
        },
        doubleTap: function (a, b) {
          if (a.ended && b.ended && !b.wasDoubleTap) {
            var c =
                20 > a.deltaX &&
                20 > a.deltaY &&
                20 > b.deltaX &&
                20 > b.deltaY,
              r = 300 > f.now() - b.startTime;
            b =
              30 > Math.abs(a.startX - b.startX) &&
              30 > Math.abs(a.startY - b.startY);
            if (c && r && b)
              return (
                (a.wasDoubleTap = !0), {name: "doubleTap", touchFinished: !0}
              );
          }
        },
        pan: function (a, b) {
          if (1 < a.samples.length) {
            b = Math.abs(a.deltaX);
            var c = Math.abs(a.deltaY);
            if (
              (!a.ended ||
                (250 >= Math.abs(a.velocityX) &&
                  250 >= Math.abs(a.velocityY))) &&
              (5 < b || 5 < c)
            )
              return {
                name: "pan",
                direction: a.direction || (b > c ? "horizontal" : "vertical"),
              };
          }
        },
        swipe: function (a, b) {
          if (a.ended && 20 < a.duration && a.samples && 2 < a.samples.length) {
            var c = a.samples[a.samples.length - 1],
              f = a.samples[0];
            b = Math.abs(c.x - f.x);
            c = Math.abs(c.y - f.y);
            if (
              (250 < Math.abs(a.velocityX) || 250 < Math.abs(a.velocityY)) &&
              (5 < b || 5 < c)
            )
              return {
                name: "swipe",
                direction: a.direction || (b > c ? "horizontal" : "vertical"),
                touchFinished: !0,
              };
          }
        },
      },
      g = ["pan", "swipe", "doubleTap", "tap"];
    return function (a, b) {
      for (var c, f = 0, h = g.length; f < h; f++)
        if ((c = l[g[f]](a, b))) return c;
      return {name: "touch", touchFinished: !1};
    };
  });
  ("use strict");
  n.when("A", "jQuery", "a-touch-base", "a-touch-recognize", "a-util").register(
    "a-touch",
    function (f, l, g, a, b) {
      function c() {
        if (v && !d.multi) {
          var b = a(d, k);
          d.finished ||
            (g.trigger(b, d, e.target, e.currentTarget),
            (d.finished = b.touchFinished));
        }
        v = !1;
        m && (x = f.requestAnimationFrame(c));
      }
      function r(a) {
        a.preventDefault();
      }
      function h(a, d) {
        if ("touchstart" === a.type)
          w[a.type](a, a.originalEvent.targetTouches[0], l(d), l(a.target));
        else w[a.type](a, a.originalEvent.targetTouches[0], d);
      }
      var d = g.touch,
        k = g.lastTouch,
        e = {},
        v = !1,
        m = !1,
        x = 0,
        w = {
          touchstart: function (a, k, b, e) {
            var t = null;
            b.hasClass("a-gesture-horizontal")
              ? (t = "horizontal")
              : b.hasClass("a-gesture-vertical") && (t = "vertical");
            var p = f.now();
            d = {
              id: a.timeStamp,
              startTime: p,
              startX: k.pageX,
              startY: k.pageY,
              deltaX: 0,
              deltaY: 0,
              velocityX: 0,
              velocityY: 0,
              duration: 0,
              ended: !1,
              $target: b,
              $triggerTarget: e,
              targetOffset: b.offset(),
              multi: 1 < a.originalEvent.targetTouches.length,
              direction: t,
              capture: u,
              samples: [
                {
                  x: k.pageX,
                  y: k.pageY,
                  deltaX: 0,
                  deltaY: 0,
                  elapsed: 0,
                  time: p,
                },
              ],
            };
            m = !0;
            x = f.requestAnimationFrame(c);
          },
          touchmove: function (a, k, b) {
            if (d.samples && d.samples.length) {
              v = !0;
              var c = f.now(),
                m = d.samples[d.samples.length - 1];
              c = {
                x: k.pageX,
                y: k.pageY,
                deltaX: k.pageX - m.x,
                deltaY: k.pageY - m.y,
                direction: g.touchDirection(k, m),
                elapsed: c - d.startTime,
                time: c,
              };
              if (d.capture === u) {
                m = Math.abs(c.deltaX);
                var t = Math.abs(c.deltaY);
                d.capture =
                  !d.direction ||
                  ("horizontal" === d.direction && m >= t / 1.15) ||
                  ("vertical" === d.direction && t >= m / 1.15);
              }
              d.capture &&
                (r(a),
                d.samples.push(c),
                (d.deltaX = k.pageX - d.startX),
                (d.deltaY = k.pageY - d.startY),
                (d.duration = c.elapsed),
                (d.multi = d.multi || 1 < a.originalEvent.targetTouches.length),
                (k = g.computeVelocity(d.samples)),
                (d.velocityX = k.x),
                (d.velocityY = k.y),
                (e = {target: a.target, currentTarget: b}));
            }
          },
          touchend: function (a, b, h) {
            if (d.samples && d.samples.length) {
              v = !0;
              h = f.now();
              var p = d.samples[d.samples.length - 1];
              b = {
                x: p.x,
                y: p.y,
                deltaX: b && b.pageX ? b.pageX - p.deltaX : p.deltaX,
                deltaY: b && b.pageY ? b.pageY - p.deltaY : p.deltaY,
                direction:
                  1 < d.samples.length
                    ? g.touchDirection(p, d.samples[d.samples.length - 2])
                    : p.direction,
                elapsed: h - d.startTime,
                time: h,
              };
              d.samples.push(b);
              d.capture && r(a);
              d.multi = d.multi || 1 < a.originalEvent.targetTouches.length;
              d.duration = h - d.startTime;
              d.ended = !0;
              b = g.computeVelocity(d.samples);
              d.velocityX = b.x;
              d.velocityY = b.y;
              e = {target: a.target, currentTarget: a.currentTarget};
              m = !1;
              f.cancelAnimationFrame(x);
              c();
              k = d;
            }
          },
        };
      w.touchcancel = w.touchend;
      l(document)
        .delegate(".a-gesture", "mouseenter mouseleave", r)
        .delegate(
          ".a-gesture",
          "touchstart touchend touchmove touchcancel",
          function (a) {
            var d = l(this);
            d.data("a-touch-bound") ||
              (d
                .data("a-touch-bound", !0)
                .bind(
                  "touchstart touchend touchmove touchcancel",
                  function (a) {
                    h(a, this);
                  }
                ),
              h(a, this));
          }
        );
      return {
        pauseTouchEvents: function (a) {
          l(q).bind("touchstart.a-pause touchmove.a-pause touchend.a-pause", r);
          f.delay(function () {
            l(q).unbind(
              "touchstart.a-pause touchmove.a-pause touchend.a-pause"
            );
          }, a);
        },
      };
    }
  );
  ("use strict");
  n.when("A", "jQuery").register("a-touch-base", function (f, l) {
    var g = {};
    return {
      touch: g,
      lastTouch: {},
      trigger: function (a, b, c, g) {
        var h = b.samples[b.samples.length - 1];
        h = {
          x: h.x,
          y: h.y,
          direction: h.direction,
          targetX: h.x - b.targetOffset.left,
          targetY: h.y - b.targetOffset.top,
          deltaX: h.deltaX,
          deltaY: h.deltaY,
          velocityX: b.velocityX,
          velocityY: b.velocityY,
          touchDeltaX: b.deltaX,
          touchDeltaY: b.deltaY,
          touchDuration: b.duration,
          ended: b.ended,
        };
        b = b.direction || a.direction;
        if ((g = g ? g.id : null))
          b && f.trigger("a:" + a.name + "-" + b + ":" + g, h),
            f.trigger("a:" + a.name + ":" + g, h);
        c = l(c);
        b && c.trigger(a.name + "-" + b, h);
        c.trigger(a.name, h);
      },
      computeVelocity: function (a) {
        for (var b = f.now(), c = 0, g = a.length; c < g; c++)
          if (150 > b - a[c].time) {
            a.splice(0, c);
            break;
          }
        b = a[0];
        a = a[a.length - 1];
        c = (a.time - b.time) / 1e3;
        return {x: (a.x - b.x) / c, y: (a.y - b.y) / c};
      },
      touchDirection: function (a, b) {
        var c = (a.pageX || a.x) - b.x;
        a = (a.pageY || a.y) - b.y;
        return "horizontal" ===
          (g.direction
            ? g.direction
            : Math.abs(c) > Math.abs(a)
            ? "horizontal"
            : "vertical")
          ? 0 < c
            ? "right"
            : "left"
          : 0 < a
          ? "down"
          : "up";
      },
    };
  });
  ("use strict");
  n.when("A").register("a-immersive-image", function (f) {
    function l(a, b) {
      b = b
        ? ("transform" !== h("transform") ? "-webkit-" : "") +
          "transform 0.5s ease-out"
        : "none";
      a.css(h("transition"), b);
      a.parent().css(h("transition"), b);
    }
    function g(a, b, e, c) {
      b = "translate(" + b + "px, " + e + "px)";
      c = "scale(" + c + ")";
      a.css(h("transform"), c);
      a.parent().css(h("transform"), b);
    }
    function a(a, k, e, c, m) {
      var d = a.innerWidth() / 2,
        f = a.innerHeight() / 2;
      e = b(a, (d - e) * m, (f - c) * m, m);
      k.offsetX = e.x;
      k.offsetY = e.y;
      k.scale = m;
      g(a, k.offsetX, k.offsetY, m);
    }
    function b(a, b, e, c) {
      var d = (a.innerWidth() / 4) * c;
      a = (a.innerHeight() / 4) * c;
      c = b && b / Math.abs(b);
      var k = e && e / Math.abs(e);
      return {
        x: Math.abs(b) > d ? d * c : b,
        y: Math.abs(e) > a ? a * k : e,
        boundX: Math.abs(b) > d,
        boundY: Math.abs(e) > a,
        signX: c,
        signY: k,
      };
    }
    function c(a, b, c, h) {
      b.zoomed &&
        (f.trigger("a:immersiveImage:zoomOut", {$image: a, immersiveImage: b}),
        g(a, 0, 0, 1),
        l(a, c),
        (b.atBounds = !1),
        (b.zooming = !0),
        (b.scale = 1),
        f.delay(function () {
          b.isPanEnabled = !1;
          a.css("-webkit-backface-visibility", "hidden");
          h && ((b.zooming = !1), (b.zoomed = !1));
        }, 600));
    }
    function n(b, c, e, g, m) {
      c.zoomed ||
        (f.trigger("a:immersiveImage:zoomIn", {$image: b, immersiveImage: c}),
        b.css("-webkit-backface-visibility", "visible"),
        l(b, !0),
        a(b, c, e, g, 2),
        (c.atBounds = !1),
        (c.zooming = !0),
        f.delay(function () {
          c.isPanEnabled = !0;
          m && ((c.zooming = !1), (c.zoomed = !0));
        }, 600));
    }
    var h = f.prefixes.getStyle;
    f.declarative("a-immersive-image", ["touchstart"], function (a) {
      var d = a.$target;
      if ("IMG" === d.prop("tagName") && !d.data("a-immersive-init")) {
        var e = {
          zoomed: !1,
          atBounds: !1,
          offsetX: 0,
          offsetY: 0,
          scale: 1,
          isPanEnabled: !1,
        };
        d.data("a-immersive-image", e);
        d.bind("doubleTap", function (a, b) {
          e.zooming ||
            (e.zoomed ? c(d, e, !0, !0) : n(d, e, b.targetX, b.targetY, !0));
        });
        d.bind("pan swipe", function (a, c) {
          if (e.zoomed && !e.zooming && e.isPanEnabled) {
            var f = c.ended ? c.deltaX + c.velocityX / e.scale : c.deltaX,
              h = c.ended ? c.deltaY + c.velocityY / e.scale : c.deltaY;
            if ((a = c.ended)) e.atBounds = !1;
            c = c.ended;
            f = b(d, e.offsetX + f, e.offsetY + h, e.scale);
            e.offsetX = f.x;
            e.offsetY = f.y;
            e.endedAtBounds &&
              f.boundX &&
              f.signX === e.signX &&
              (e.atBounds = !0);
            e.endedAtBounds = f.boundX && c;
            e.signX = f.signX;
            l(d, a);
            g(d, e.offsetX, e.offsetY, e.scale);
          }
        });
        (function () {
          function a(a, b) {
            var c = a[0].pageX - b.left,
              d = a[0].pageY - b.top,
              e = a[1].pageX - b.left;
            a = a[1].pageY - b.top;
            return {
              midX: (c + e) / 2,
              midY: (d + a) / 2,
              distance: Math.sqrt(Math.pow(c - e, 2) + Math.pow(d - a, 2)),
            };
          }
          var b,
            f = 0,
            g = !1;
          d.bind("touchstart", function (c) {
            var e = c.originalEvent.targetTouches;
            2 === e.length &&
              ((b = a(e, d.offset())),
              c.stopImmediatePropagation(),
              c.preventDefault());
          });
          d.bind("touchmove", function (h) {
            var k = h.originalEvent.targetTouches;
            if (2 === k.length && ((k = a(k, d.offset())), b)) {
              g = !0;
              var l = k.distance - b.distance;
              f += Math.abs(l);
              4 < f &&
                !e.zooming &&
                (0 > l ? c(d, e, !0, !1) : n(d, e, k.midX, k.midY, !1));
              h.stopImmediatePropagation();
              h.preventDefault();
            }
          });
          d.bind("touchend touchleave touchcancel", function (a) {
            g &&
              0 === a.originalEvent.targetTouches.length &&
              ((f = 0),
              (g = !1),
              (e.zoomed = 1 < e.scale),
              (e.zooming = !1),
              a.preventDefault());
            e.atBounds = !1;
          });
        })();
        d.data("a-immersive-init", !0);
      }
    });
    return {
      zoomOut: function (a) {
        var b = a.data("a-immersive-image");
        b && c(a, b, !1, !0);
      },
    };
  });
});
/* ******** */
(function (a) {
  var c = window.AmazonUIPageJS || window.P,
    d = c._namespace || c.attributeErrors,
    b = d ? d("AmazonUIBaseJS@A", "AmazonUI") : c;
  b.guardFatal
    ? b.guardFatal(a)(b, window)
    : b.execute(function () {
        a(b, window);
      });
})(function (a, c, d) {
  "use strict";
  a.when("a-bodyBegin").execute("build-A", function () {
    var b = a.execute().decorate,
      c = a
        .when(
          "a-util",
          "a-defer",
          "a-base",
          "a-events",
          "a-declarative",
          "a-state",
          "a-ajax",
          "a-animate",
          "a-image",
          "a-constants",
          "a-detect",
          "a-browser-events",
          "a-preload",
          "a-prefix",
          "a-request-animation-frame",
          "a-class",
          "a-draggable"
        )
        .register("A", function (a) {
          function e(b, e, d, f) {
            this._guard = b;
            this._logError = e;
            this._guardTime = d;
            a.each(
              c,
              function (c) {
                a.extend(this, new c.constructor(b, e));
              },
              this
            );
          }
          var c = [];
          e.prototype = {};
          a.each(arguments, function (d) {
            b && d.constructor !== Object
              ? c.push(d)
              : (delete d.constructor, a.extend(e.prototype, d));
          });
          return b ? e : e.prototype;
        });
    b &&
      c.decorate(function (b, a) {
        return new b(a.guard, a.logError, a.guardTime);
      });
  });
});
/* ******** */
(function (c) {
  var f = window.AmazonUIPageJS || window.P,
    g = f._namespace || f.attributeErrors,
    d = g ? g("AmazonUIButton@buttonJS", "AmazonUI") : f;
  d.guardFatal
    ? d.guardFatal(c)(d, window)
    : d.execute(function () {
        c(d, window);
      });
})(function (c, f, g) {
  c.when("A", "a-component").register("a-button", function (d, l) {
    function e(a) {
      a.preventDefault();
    }
    var h = l.create({
      _componentName: "button",
      init: function (a, b) {
        this._super(a, b);
        this._$element = this._$element.filter(".a-button");
        this._$coreFormElement = this._$element
          .children(".a-button-inner")
          .children("button,input");
        this._$coreLinkElement = this._$element
          .children(".a-button-inner")
          .children("a");
        this._$contentElement = this._$element.find(".a-button-text");
      },
      mixin: "show hide toggle isEmpty size on off trigger".split(" "),
      enable: function () {
        this._$element.removeClass("a-button-disabled");
        this._$coreFormElement.prop("disabled", !1);
        this._$coreLinkElement.unbind("click", e);
        this._$coreLinkElement.removeAttr("aria-disabled");
        return this;
      },
      disable: function () {
        this._$element
          .addClass("a-button-disabled")
          .removeClass("a-button-focus");
        this._$coreFormElement.prop("disabled", !0);
        this._$coreLinkElement.click(e);
        this._$coreLinkElement.attr("aria-disabled", "true");
        return this;
      },
      isEnabled: function () {
        return !this._$element.hasClass("a-button-disabled");
      },
      setStatus: function (a) {
        var b = this._$element,
          e = [null, "normal", "selected", "disabled", "error", "inactive"],
          k = 0 > d.indexOfArray(e, a),
          m = "radio" === b.attr("role");
        if (k) return c.error(a + " is not a valid status"), !1;
        d.each(e, function (a) {
          b.removeClass("a-button-" + a);
        });
        this._$coreFormElement.prop("disabled", "disabled" === a);
        b.attr("aria-checked", function (b, k) {
          return m ? "selected" === a : k;
        });
        null !== a && b.addClass("a-button-" + a);
        return this;
      },
      text: function (a) {
        if (!(1 > this._$contentElement.length)) {
          if ("undefined" === typeof a) return this._$contentElement.text();
          this._$contentElement.text(a);
          return this;
        }
      },
    });
    return function (a, b) {
      return new h(a, b);
    };
  });
  ("use strict");
  c.when("A", "a-component").register("a-toggle-button", function (d, c) {
    function e(a) {
      a.preventDefault();
    }
    function h(a) {
      d.each(
        b,
        function (b) {
          a._$element.removeClass(b);
        },
        a
      );
    }
    function a(a) {
      return 0 === a._$element.length || 0 === a._$coreFormElement.length;
    }
    var b = ["a-button-selected", "a-button-focus"],
      f = c.create({
        _componentName: "toggleButton",
        init: function (a, b) {
          this._super(a, b);
          this._$element = this._$element.filter(".a-button");
          this._$coreFormElement = this._$element
            .find(".a-button-inner")
            .find("button,input");
          this._$coreLinkElement = this._$element.find(".a-button-inner a");
        },
        name: function () {
          return this._$coreFormElement.attr("name");
        },
        enable: function () {
          this._$element.removeClass("a-button-disabled");
          this._$coreFormElement.prop("disabled", !1);
          this._$coreLinkElement.unbind("click", e);
          return this;
        },
        disable: function () {
          h(this);
          this._$element.addClass("a-button-disabled");
          this._$coreFormElement.prop("disabled", !0);
          this._$coreLinkElement.click(e);
          return this;
        },
        setAvailable: function () {
          this._$element.removeClass("a-button-unavailable");
          return this;
        },
        setUnavailable: function () {
          this._$element.addClass("a-button-unavailable");
          return this;
        },
        isEnabled: function () {
          return !a(this) && !this._$element.hasClass("a-button-disabled");
        },
        setSelected: function () {
          !a(this) &&
            this.isEnabled() &&
            this._$element
              .addClass("a-button-selected a-button-focus")
              .attr("aria-checked", "true");
          return this;
        },
        setUnselected: function () {
          h(this);
          this._$element.attr("aria-checked", "false");
          return this;
        },
        isSelected: function () {
          return !a(this) && this._$element.hasClass("a-button-selected");
        },
        isAvailable: function () {
          return !a(this) && !this._$element.hasClass("a-button-unavailable");
        },
      });
    return function (a, b) {
      return new f(a, b);
    };
  });
  ("use strict");
  c.when("A", "a-component", "a-toggle-button").register(
    "a-toggle-button-group",
    function (d, c, e) {
      var f = c.create({
        _componentName: "toggleButtonGroup",
        init: function (a, b) {
          this._super(a, b);
          this._$toggleGroupElement = this._$element
            .filter(".a-button-group, .a-button-toggle-group")
            .eq(0);
          this._$toggleGroupName = (a =
            this._$toggleGroupElement.data("a-button-group"))
            ? a.name
            : g;
        },
        name: function () {
          return this._$toggleGroupName;
        },
        getToggleButtonByName: function (a) {
          return this.getToggleButtonBySelector(
            ".a-button:has([name\x3d" + a + "])"
          );
        },
        setSelected: function (a) {
          a = this.getToggleButtonBySelector(a);
          a.isEnabled() &&
            (this.getSelected().setUnselected(), a.setSelected());
          return this;
        },
        getSelected: function () {
          return this.getToggleButtonBySelector(".a-button.a-button-selected");
        },
        getToggleButtonBySelector: function (a) {
          return e(this._$toggleGroupElement.find(a));
        },
      });
      return function (a, b) {
        return new f(a, b);
      };
    }
  );
});
/* ******** */
(function (c) {
  var b = window.AmazonUIPageJS || window.P,
    d = b._namespace || b.attributeErrors,
    a = d ? d("AmazonUIMeter", "AmazonUI") : b;
  a.guardFatal
    ? a.guardFatal(c)(a, window)
    : a.execute(function () {
        c(a, window);
      });
})(function (c, b, d) {});
/* ******** */
(function (d) {
  var g = window.AmazonUIPageJS || window.P,
    f = g._namespace || g.attributeErrors,
    a = f ? f("AmazonUIFont", "AmazonUI") : g;
  a.guardFatal
    ? a.guardFatal(d)(a, window)
    : a.execute(function () {
        d(a, window);
      });
})(function (d, g, f) {
  d.when("jQuery", "A", "3p-promise").register("a-fonts", function (a, d, l) {
    function m(a, d) {
      var b = e && e[a] ? e : d;
      return function () {
        return b[a].apply(b, arguments);
      };
    }
    var h = [],
      b = a("body"),
      f = (function () {
        return new l(function (a, b) {
          var e = g.setInterval(function () {
            d.reduce(
              h,
              function (a, b) {
                return a && "loaded" === b.status;
              },
              !0
            ) && (a(), clearInterval(e));
          }, 50);
        });
      })(),
      k = {
        load: function (d) {
          return new l(function (e, f) {
            var c = {variant: d, status: "unloaded"};
            h.push(c);
            c.$loader = a("\x3cspan\x3e.\x3c/span\x3e", {class: "aok-hidden"})
              .css("font", c.variant)
              .appendTo(b);
            c.status = "loading";
            c.$checker = a("\x3cspan\x3e.\x3c/span\x3e", {
              class: "aok-hidden",
            }).appendTo(b);
            c.intervalId = g.setInterval(function () {
              c.$checker.css(
                "font",
                c.variant + ', Consolas, "Courier New", Courier, monospace'
              );
              var a = c.$checker.width(),
                b = c.$checker.height();
              c.$checker.css(
                "fontFamily",
                'Consolas, "Courier New", Courier, monospace'
              );
              if (c.$checker.width() !== a || c.$checker.height() !== b)
                e(c.variant),
                  (c.status = "loaded"),
                  c.$loader.remove(),
                  c.$checker.remove(),
                  clearInterval(c.intervalId);
            }, 50);
          });
        },
        check: function (a) {
          d.each(h, function (b) {
            if (b.variant === a) return "loaded" === b.status;
          });
          return !1;
        },
        ready: f,
      },
      e = document.fonts;
    e && e.ready && (f = e.ready.then ? e.ready : e.ready.apply(e));
    return {load: m("load", k), check: m("check", k), ready: f};
  });
  ("use strict");
  d.when("A", "a-fonts", "prv:a-capabilities", "load").register(
    "prv:a-custom-font-loader",
    function (a, d, f) {
      return function (g, h) {
        !f.isUCBrowser &&
          a.localStorage &&
          -1 ===
            a.indexOfArray(
              (a.localStorage.getItem("a-font-class") || "").split(" "),
              g
            ) &&
          (d.ready.then(function (b) {
            b = a.localStorage.getItem("a-font-class") || "";
            b += (b.length ? " " : "") + g;
            a.localStorage.setItem("a-font-class", b);
          }),
          a.each(h, function (a) {
            d.load(a);
          }));
      };
    }
  );
  ("use strict");
  d.when("prv:a-custom-font-loader").execute("a-ember-loader", function (a) {
    a(
      "a-ember",
      "1em Amazon Ember;bold 1em Amazon Ember;200 1em Amazon Ember;500 1em Amazon Ember;italic 1em Amazon Ember;italic bold 1em Amazon Ember;italic 200 1em Amazon Ember;italic 500 1em Amazon Ember".split(
        ";"
      )
    );
  });
});
/* ******** */
(function (n) {
  var E = window.AmazonUIPageJS || window.P,
    y = E._namespace || E.attributeErrors,
    e = y ? y("AmazonUICarousel", "AmazonUI") : E;
  e.guardFatal
    ? e.guardFatal(n)(e, window)
    : e.execute(function () {
        n(e, window);
      });
})(function (n, E, y) {
  n.declare("a-carousel-constants", {
    ANIMATING: "animating",
    ANIMATION_SPEED: "animation_speed",
    AUTO_ADJUST_HEIGHT: "auto_adjust_height",
    CIRCULAR: "circular",
    CURRENT_PIXEL: "px",
    CURRENTLY_WRAPPING: "currentlyWrapping",
    DELAY_TIME: "delay_time",
    ELEMENT_CSS_CLASS: "elementCssClass",
    FETCHED_ITEMS: "fetchedItems",
    FIRST_VISIBLE_ITEM: "firstVisibleItem",
    HEIGHT_ANIMATION_SPEED: "height_animation_speed",
    HIDE_OFF_SCREEN: "hide_off_screen",
    INIT_EVENTS: "a:pageUpdate beforeReady",
    LOADING: "loading",
    MIN_GUTTER: "minimum_gutter_width",
    NAME: "name",
    NO_TRANSITION: "no_transition",
    PAGE_NUMBER: "pageNumber",
    PAGE_SIZE: "pageSize",
    PEEK_GRADIENT: "peek_gradient",
    PEEK_PERCENTAGE: "peek_percentage",
    PEEK_WIDTH: "peek_width",
    SET_SIZE: "set_size",
    SHOW_PARTIAL_NEXT: "show_partial_next",
    SPRINGINESS: "springiness",
    STATIC_LOADER_CSS_CLASS: "staticLoaderCssClass",
    TOTAL_PAGES: "totalPages",
    TOUCH_EASING: "touch_easing",
    TRANSITION_STRATEGY: "transitionStrategy",
    DISPLAY_STRATEGY: "displayStrategy",
    WRAP_EASING: "wrap_easing",
    TRANSITION_SLIDE_CIRCULAR_FIRST_CARD_IDX:
      "transitionSlideCircularFirstCardIndex",
    NEXT_REQUEST_SIZE: "next_request_size",
    LOADING_THRESHOLD_PIXELS: "loading_threshold_pixels",
  });
  ("use strict");
  n.when("jQuery").register("a-carousel-utils", function (e) {
    function m(f) {
      return "string" === typeof f;
    }
    function g(f) {
      return f && f.nodeType !== y;
    }
    function d(f) {
      return "" === f
        ? "\x3cdiv\x3e\x3c/div\x3e"
        : f
        ? m(f) || g(f)
          ? f
          : d(f.content)
        : null;
    }
    function k(f) {
      f && (m(f) || g(f) ? (f = !0) : (f.content = k(f.content)));
      return f;
    }
    return {
      addElementToDom: function (f, d) {
        if (d) {
          if (m(d)) f.html(d);
          else if (g(d))
            if (e(d).hasClass("a-carousel-card-fragment")) {
              var c = e(d).clone();
              f.empty().append(c.contents());
            } else f.empty().append(d);
          !0 !== d && f.removeClass("a-carousel-card-empty");
        }
      },
      clearElementFromItem: k,
      getElementFromItem: d,
      isElement: g,
      isString: m,
    };
  });
  ("use strict");
  n.register("a-carousel-circular-utils", function () {
    function e(e) {
      var d = 0 < e;
      return function (e, f, h) {
        var c = f.length;
        h = (h || 1) % c;
        e = e.get(0);
        for (var b, a = 0; a < h; a++)
          d
            ? ((b = f.get(a)), e.appendChild(b))
            : ((b = f.get(c - 1 - a)), e.insertBefore(b, e.children[0]));
      };
    }
    function m(e) {
      var d = 0 < e;
      return function (e, f) {
        f = f ? f % e.length : 1;
        d
          ? (e = e.concat(e.splice(0, f)))
          : e.unshift.apply(e, e.splice(e.length - f, f));
        return e;
      };
    }
    return {
      rotateCW: e(1),
      rotateCCW: e(-1),
      rotateArrayCW: m(1),
      rotateArrayCCW: m(-1),
      firstCardIndexAfterRotate: function (e, d, k) {
        e = (d + e) % k;
        0 === e ? (e = k) : 0 > e && (e = k + e);
        return e;
      },
      relativeIndexFromIndex: function (e, d, k) {
        var f = 1;
        if (0 < e && e <= k)
          return e > d ? (f = e - d + 1) : e < d && (f = k - d + e + 1), f;
        n.error(
          "idx should be between 1 and " + k,
          "a-carousel-circular-utils",
          "relativeIndexFromIndex"
        );
      },
    };
  });
  ("use strict");
  n.when("A", "jQuery").register("a-carousel-measure", function (e, m) {
    return function (g) {
      function d(d, h, c) {
        var b, a, p;
        h.jquery || (h = m(h));
        for (
          e.each(c, function (b) {
            if ("top" === b || "left" === b) return (a = h.offset()), !1;
          });
          void 0 !== (b = c.pop());

        ) {
          var f = d[b];
          "left" === b || "top" === b
            ? (d[b] = a[b])
            : -1 < b.indexOf("outer")
            ? (d[b] = h[b](!0))
            : (d[b] = h["outer" + b.charAt(0).toUpperCase() + b.substr(1)]());
          d[b] !== f && (void 0 === p && (p = {}), (p[b] = f));
        }
        return p;
      }
      var k = {
        carousel: {height: 0, width: 0, outerHeight: 0, outerWidth: 0},
        viewport: {height: 0, width: 0, outerHeight: 0, outerWidth: 0},
        items: [],
        getFirstCardWidth: function () {
          return void 0 === this.items[0] ||
            !e.isFiniteNumber(this.items[0].width) ||
            0 >= this.items[0].width
            ? 160
            : this.items[0].width;
        },
      };
      g.measure = function (f) {
        var h = this.dom.$carousel,
          c = this.dom.$viewport,
          b = {};
        f && (f = f.split(" "));
        if (!f || -1 < e.indexOfArray(f, "carousel"))
          b.carousel = d(
            k.carousel,
            h,
            "top left height width outerHeight outerWidth".split(" ")
          );
        if (!f || -1 < e.indexOfArray(f, "viewport"))
          b.viewport = d(k.viewport, c, [
            "height",
            "width",
            "outerHeight",
            "outerWidth",
          ]);
        if (!f || -1 < e.indexOfArray(f, "items"))
          (k.items = []),
            (b.items = {}),
            h.children("li").each(function (a, c) {
              k.items[a] = {};
              c = d(
                k.items[a],
                c,
                "top left height width outerHeight outerWidth".split(" ")
              );
              void 0 !== c && (b.items[a] = c);
            });
        return b;
      };
      g.getItemOffset = function (e) {
        var d = k.items;
        e--;
        if (d && d.length) {
          if (e < d.length) {
            for (var c = 0, b = d[0].outerWidth, a = 0; a < e; a++)
              c += d[a] ? d[a].outerWidth : b;
            0 < e &&
              this.getAttr("first_item_flush_left") &&
              (c += g.getAttr("currentGutter"));
            return c;
          }
        } else return 0;
      };
      g.getDimensions = function () {
        return e.copy(k);
      };
      g.updateDimensionsCache = function (d) {
        e.extend(k, d);
      };
      g.getViewportWidth = function () {
        try {
          return k.viewport.width;
        } catch (f) {}
      };
    };
  });
  ("use strict");
  n.when("A", "jQuery").register("a-carousel-attributes", function (e, m) {
    return function (g, d) {
      var k = {},
        f = {},
        h = {};
      e.extend(k, d);
      g.onChange = function (c, b) {
        c = c.split(" ");
        for (var a = c.length, d; a--; )
          (d = c[a]),
            f[d] || (f[d] = []),
            m.isFunction(b) && -1 === e.indexOfArray(f[d], b) && f[d].push(b);
        return this;
      };
      g.unbind = function (c, b) {
        f[c] &&
          b &&
          ((b = e.indexOfArray(f[c], b)), -1 < b && f[c].splice(b, 1));
        return this;
      };
      g.once = function (c, b) {
        var a = function () {
          b.apply(null, arguments);
          g.unbind(c, a);
        };
        return g.onChange(c, a);
      };
      g.setAttr = function (c, b, a) {
        var d = k[c];
        k[c] = b;
        if (!(a || h[c] || e.equals(b, d))) {
          h[c] = !0;
          b = e.copy(b);
          d = e.copy(d);
          if (f[c]) {
            a = e.copy(f[c]);
            for (var t = 0, x = a.length; t < x; t++) a[t](b, d, g, c);
          }
          b = {newValue: b, oldValue: d, carousel: g};
          e.trigger("a:carousel:change:" + c, b);
          k.name && e.trigger("a:carousel:" + k.name + ":change:" + c, b);
          h[c] = !1;
        }
        return this;
      };
      g.getAttr = function (c) {
        return e.copy(k[c]);
      };
    };
  });
  ("use strict");
  n.when(
    "A",
    "jQuery",
    "a-carousel-measure",
    "a-carousel-attributes",
    "a-carousel-strategies",
    "a-carousel-constants",
    "a-analytics",
    "prv:a-capabilities"
  ).register("a-carousel-base", function (e, m, g, d, k, f, h, c) {
    function b(a) {
      var b = a.getAttr("set_size") <= a.getAttr("pageSize"),
        c = a.getAttr(f.NO_TRANSITION);
      1 === a.getAttr("totalPages") &&
        1 < a.getAttr("pageNumber") &&
        a.gotoPage(1, {startover: !0, animationDuration: 0});
      a.dom.$container
        .find(".a-carousel-left, .a-carousel-right")
        .css("visibility", b || c ? "hidden" : "visible");
    }
    function a(a, b) {
      return isNaN(a)
        ? (n.log(
            "`set_size` should be an integer: " + a,
            "WARN",
            "aui:carousel:base"
          ),
          b)
        : parseInt(a, 10);
    }
    function p(a) {
      a.onChange("pageSize", function (b, c) {
        var l = a.getAttr("firstVisibleItem"),
          e = Math.ceil(l / b);
        1 === e && 1 < l ? (e = 2) : 1 > e && (e = 1);
        a.setAttr("pageNumber", e);
        a.setAttr("totalPages", Math.ceil(a.getAttr("set_size") / b));
        l = a.getAttr("ajax");
        b > c &&
          (l && l.prefetch_next_page
            ? a.strategies.ajax.wantNextPage(a)
            : a.strategies.ajax.wantCurrentPage(a));
      });
      a.onChange("set_size", function (b, c) {
        var l = a.getAttr("pageSize"),
          e = a.getAttr("fetchedItems");
        a.setAttr("totalPages", Math.ceil(b / l));
        b < c
          ? (e.splice(b, Number.MAX_VALUE), a.setAttr("fetchedItems", e))
          : a.strategies.ajax.wantCurrentPage &&
            a.strategies.ajax.wantCurrentPage(a);
      });
      a.onChange("firstVisibleItem", function (b) {
        a.dom.$container.find("input.a-carousel-firstvisibleitem").val(b);
      });
      a.onChange("pageNumber", function (b) {
        0 < b &&
          b <= a.getAttr("totalPages") &&
          a.setAttr("currentlyWrapping", !1);
      });
    }
    function t(b, l, c) {
      if (0 !== arguments.length) {
        b.jquery || (b = m(b));
        this.dom = {
          $container: b,
          $viewport: b.hasClass("a-carousel-viewport")
            ? b
            : b.find(".a-carousel-viewport").eq(0),
          $carousel: b.find(".a-carousel").eq(0),
        };
        !b.length ||
          (this.dom.$viewport.length && this.dom.$carousel.length) ||
          h.logError(
            "[AUI] CarouselContainer does not have CarouselContent.",
            "ERROR",
            JSON.stringify({
              xpath: e.xpath(b.get(0)),
              cssSelector: e.cssSelector(b.get(0)),
              custody: e.attributionChain(b.get(0)),
            })
          );
        var p = {
          totalPages: 1e3,
          pageNumber: 1,
          pageSize: 0,
          firstVisibleItem: 1,
          initThreshold: 100,
          maintain_state: !0,
          px: 0,
          auto_adjust_height: !0,
          ajax: {},
        };
        e.extend(p, c);
        p.maintain_state = !!p.maintain_state;
        p.id_list
          ? p.set_size || (p.set_size = p.id_list.length)
          : (p.id_list = []);
        var x = this.dom.$carousel.children("li");
        if (p.set_size) p.set_size = a(p.set_size, x.length);
        else {
          var f = parseInt(x.first().attr("aria-setsize"), 10);
          e.isFiniteNumber(f) && 0 < f
            ? (p.set_size = f)
            : (p.set_size = x.length);
        }
        var v = [];
        this.dom.$carousel.children("li").each(function (a, b) {
          v.push(
            m(b).hasClass("a-carousel-card-empty") ? "" : e.trim(b.innerHTML)
          );
        });
        p.fetchedItems = v;
        g(this);
        d(this, p);
        this.strategies = l;
        return this;
      }
    }
    e.each(k, function (a, b) {
      t.prototype["set" + b.charAt(0).toUpperCase() + b.slice(1) + "Strategy"] =
        function (a) {
          this.strategies[name] = a;
          "function" === typeof a.init && a.init(this);
        };
    });
    k = t.prototype;
    k.gotoNextPage = function (a) {
      this.getAttr("transitionPaused") ||
        (this.strategies.transition.gotoNextPage(this, a),
        a &&
          a.accessibleSafe &&
          this.strategies.accessibility.nextPage(
            this,
            a.animationDuration,
            a.animationSpeed
          ));
    };
    k.gotoPrevPage = function (a) {
      this.getAttr("transitionPaused") ||
        (this.strategies.transition.gotoPrevPage(this, a),
        a &&
          a.accessibleSafe &&
          this.strategies.accessibility.prevPage(
            this,
            a.animationDuration,
            a.animationSpeed
          ));
    };
    k.gotoPage = function (a, b) {
      this.getAttr("transitionPaused") ||
        (this.strategies.transition.gotoPage(this, a, b),
        b &&
          b.accessibleSafe &&
          this.strategies.accessibility.gotoPage(
            this,
            b.animationDuration,
            b.animationSpeed
          ));
    };
    k.gotoIndex = function (a, b) {
      (!this.getAttr("transitionPaused") || (b && b.ignorePause)) &&
        this.strategies.transition.gotoIndex(this, a, b);
    };
    k.gotoPixel = function (a, b) {
      this.getAttr("transitionPaused") ||
        this.strategies.transition.gotoPixel(this, a, b);
    };
    k.resize = function () {
      if (this.dom.$container.is(":visible")) {
        var a = this.measure("carousel viewport");
        this.strategies.display.resize(this, a);
      }
    };
    k.pause = function () {
      this.setAttr("transitionPaused", !0);
    };
    k.resume = function () {
      this.setAttr("transitionPaused", !1);
    };
    k.triggerEvent = function (a, b) {
      b = b || {};
      b.carousel = this;
      e.trigger("a:carousel:" + a, b);
      var c = this.getAttr("name");
      c && e.trigger("a:carousel:" + c + ":" + a, b);
    };
    k.getStaticLoader = function () {
      return this.getAttr(f.STATIC_LOADER_CSS_CLASS)
        ? '\x3cdiv class\x3d"' +
            this.getAttr(f.STATIC_LOADER_CSS_CLASS) +
            '"\x3e\x3c/div\x3e'
        : "";
    };
    k.getEmptyCard = function (a, b) {
      var c = "a-carousel-card a-carousel-card-empty";
      this.getAttr(f.ELEMENT_CSS_CLASS) &&
        (c = c + " " + this.getAttr(f.ELEMENT_CSS_CLASS));
      return [
        '\x3cli class\x3d"',
        c,
        '" role\x3d"listitem" aria-setsize\x3d"',
        b,
        '" aria-posinset\x3d"',
        a,
        '"\x3e',
        this.getStaticLoader(),
        "\x3c/li\x3e",
      ].join("");
    };
    k.initTouchHandling = function () {
      var a = this,
        b = a.dom.$viewport;
      if (
        b.length &&
        ((e.capabilities.touch || e.capabilities.pointerPrefix) &&
          n.when("a-touch").execute(function (c) {
            b.addClass("a-gesture a-gesture-horizontal").bind(
              "pan-horizontal swipe-horizontal",
              function () {
                return !1;
              }
            );
            e.on("a:swipe-horizontal:" + b[0].id, function (b) {
              if (
                !a.getAttr("transitionPaused") &&
                a.strategies.transition.onSwipe
              )
                a.strategies.transition.onSwipe(a, b);
            });
            if (!a.getAttr("disable_panning"))
              e.on("a:pan-horizontal:" + b[0].id, function (b) {
                if (
                  !a.getAttr("transitionPaused") &&
                  a.strategies.transition.onPan
                )
                  a.strategies.transition.onPan(a, b);
              });
          }),
        c.isIE10 || c.isIE11Plus)
      ) {
        var d = function (a) {
          a.stopPropagation();
          a.preventDefault();
          document.body.removeEventListener("click", d, !0);
        };
        b.bind(e.action.start, function (a) {
          b.bind(
            "swipe-horizontal.a-ssiec pan-horizontal.a-ssiec",
            function (a) {
              b.unbind(".a-ssiec");
              b.bind(e.action.end + ".a-ssiec", function (a) {
                b.unbind(".a-ssiec");
                document.body && document.body.addEventListener("click", d, !0);
              });
            }
          );
        });
      }
    };
    k.init = function () {
      var a = this,
        c = a.strategies,
        d = a.dom.$viewport[0];
      d && !d.id && (d.id = "anonCarousel" + a.__id);
      a.dom.$carousel
        .contents()
        .not(function () {
          return this.tagName && "li" === this.tagName.toLowerCase();
        })
        .remove();
      e.each(a.strategies, function (b) {
        b.initAttrs &&
          e.each(b.initAttrs, function (b, c) {
            var d = b;
            "function" === typeof b && (d = b(a.getAttr(c)));
            a.setAttr(c, d);
          });
      });
      if (1 > a.getAttr("set_size")) return c.ajax.init(a), !1;
      a.measure();
      e.each(a.strategies, function (b) {
        b.init(a);
      });
      c = a.getAttr("pageSize");
      d = a.getAttr("set_size");
      a.setAttr("totalPages", Math.ceil(d / c));
      p(a);
      a.setAttr(
        "isInTab",
        0 < a.dom.$container.closest(".a-tab-content").length,
        !0
      );
      a.triggerEvent("init");
      e.each(a.strategies, function (b) {
        b.afterInit && b.afterInit(a);
      });
      a.triggerEvent("afterInit");
      c = a.getAttr("firstVisibleItem");
      1 === c &&
        a.getAttr("maintain_state") &&
        ((c = parseInt(
          a.dom.$container.find("input.a-carousel-firstvisibleitem").val(),
          10
        )),
        (e.isFiniteNumber(c) && 0 < c && c <= d) || (c = 1));
      if (1 < c) {
        d = 700;
        for (var f = Math.ceil(c / a.getAttr("pageSize")), t = 2; t < f; t++)
          d += 700 / t;
        a.gotoIndex(c, {animationDuration: d, easingFunction: "ease"});
      }
      b(this);
      a.onChange("pageSize set_size", function () {
        b(a);
      });
      c = a.dom.$container.find(".a-carousel-button");
      c.length && ((d = c.eq(0).position().top + "px"), c.css("top", d));
      var h = !1,
        g = function (b) {
          b.preventDefault();
          b = {startover: !0, accessibleSafe: "keydown" === b.type ? !0 : !1};
          5 < a.getAttr("pageNumber")
            ? (b.animationDuration = 1250)
            : (b.animationSpeed = 5 * a.getDimensions().viewport.width);
          a.gotoPage(1, b);
        };
      a.dom.$container
        .delegate(".a-carousel-goto-nextpage", "click dblclick", function (b) {
          h ||
            ((h = !0),
            b.preventDefault(),
            a.gotoNextPage(),
            e.delay(function () {
              h = !1;
            }, 5));
        })
        .delegate(".a-carousel-goto-prevpage", "click dblclick", function (b) {
          h ||
            ((h = !0),
            b.preventDefault(),
            a.gotoPrevPage(),
            e.delay(function () {
              h = !1;
            }, 5));
        })
        .delegate(".a-carousel-goto-nextpage", "keydown", function (b) {
          if (
            b.which === e.constants.keycodes.ENTER ||
            b.which === e.constants.keycodes.SPACE
          )
            b.preventDefault(), a.gotoNextPage({accessibleSafe: !0});
        })
        .delegate(".a-carousel-goto-prevpage", "keydown", function (b) {
          if (
            b.which === e.constants.keycodes.ENTER ||
            b.which === e.constants.keycodes.SPACE
          )
            b.preventDefault(), a.gotoPrevPage({accessibleSafe: !0});
        })
        .delegate(".a-carousel-restart", "keydown", function (a) {
          (a.which !== e.constants.keycodes.ENTER &&
            a.which !== e.constants.keycodes.SPACE) ||
            g(a);
        })
        .delegate(".a-carousel-restart", "click", function (a) {
          g(a);
        });
      a.dom.$container
        .find(".a-carousel-page-max")
        .html(this.getAttr("totalPages"));
      return !0;
    };
    return t;
  });
  ("use strict");
  n.when("A", "jQuery", "a-carousel-base", "a-carousel-constants").register(
    "a-carousel-mobile",
    function (e, m, g, d) {
      function k(c) {
        var b = c.getAttr("loaderHeight");
        b ||
          ((b = c.getAttr("maxHeight"))
            ? ((b = Math.min(0.9 * b, 90)), (b = Math.max(b, 120)))
            : (b = 90),
          c.setAttr("loaderHeight", b));
        return b;
      }
      function f(c, b, a) {
        g.call(this, c, b, a);
        if (0 !== arguments.length)
          return (
            this.getAttr("circular") === h && this.setAttr("circular", !1),
            this.getAttr("show_partial_next") === h &&
              this.setAttr("show_partial_next", !0),
            this.getAttr("hide_off_screen") === h &&
              this.setAttr("hide_off_screen", !1),
            this.getAttr("springiness") === h &&
              this.setAttr("springiness", 0.8),
            this.getAttr("touch_easing") === h &&
              this.setAttr(
                "touch_easing",
                "cubic-bezier(0.215, 0.610, 0.355, 1.000)"
              ),
            (this.init = function () {
              return g.prototype.init.call(this)
                ? (this.getAttr(d.STATIC_LOADER_CSS_CLASS) ||
                    this.dom.$carousel
                      .children("li")
                      .children(".a-loading-static")
                      .css("height", k(this) + "px"),
                  this.getAttr(d.NO_TRANSITION) || this.initTouchHandling(),
                  !0)
                : !1;
            }),
            this
          );
      }
      var h;
      f.prototype = new g();
      f.prototype.constructor = f;
      f.prototype.getStaticLoader = function () {
        return this.getAttr(d.STATIC_LOADER_CSS_CLASS)
          ? '\x3cdiv class\x3d"' +
              this.getAttr(d.STATIC_LOADER_CSS_CLASS) +
              '"\x3e\x3c/div\x3e'
          : '\x3cdiv class\x3d"a-loading-static" style\x3d"height:' +
              k(this) +
              'px"\x3e\x3cdiv class\x3d"a-loading-static-inner"\x3e\x3c/div\x3e\x3c/div\x3e';
      };
      return f;
    }
  );
  ("use strict");
  n.when("A", "jQuery", "a-carousel-base", "a-carousel-constants").register(
    "a-carousel-desktop",
    function (e, m, g, d) {
      function k(c) {
        var b = c.getAttr("set_size") <= c.getAttr("pageSize"),
          a = c.getAttr(d.NO_TRANSITION);
        c.dom.$container
          .find(".a-carousel-pagination")
          .css("visibility", b || a ? "hidden" : "visible");
      }
      function f(c, b, a) {
        g.call(this, c, b, a);
        if (0 !== arguments.length) {
          var e = this;
          e.getAttr("circular") === h && this.setAttr("circular", !0);
          e.getAttr("hide_off_screen") === h &&
            this.setAttr("hide_off_screen", !0);
          e.onChange("totalPages", function (a) {
            e.dom.$container.find(".a-carousel-page-max").html(a);
            a < e.getAttr("pageNumber") && e.gotoPage(a);
          });
          e.onChange("pageNumber", function (a, b) {
            b = e.dom.$container;
            var c = b.find(".a-carousel-restart-container");
            1 < a ? c.show() : c.hide();
            b.find(".a-carousel-page-current").html(a);
          });
          e.init = function () {
            var a = this;
            return g.prototype.init.call(a)
              ? (k(this),
                a.onChange("pageSize set_size", function () {
                  k(a);
                }),
                2 > a.getAttr("pageNumber") &&
                  a.dom.$container.find(".a-carousel-restart-container").hide(),
                a.getAttr(d.NO_TRANSITION) || a.initTouchHandling(),
                !0)
              : !1;
          };
          return e;
        }
      }
      var h;
      f.prototype = new g();
      return (f.prototype.constructor = f);
    }
  );
  ("use strict");
  n.when("A", "a-carousel-desktop", "a-carousel-mobile").register(
    "a-carousel-classes",
    function (e, m, g) {
      return {
        desktop: m,
        mobile: g,
        default:
          e.capabilities.mobile || e.capabilities.tablet ? "mobile" : "desktop",
      };
    }
  );
  ("use strict");
  n.when("A", "jQuery", "p-detect", "a-carousel-constants").register(
    "a-carousel-stretchygoodness",
    function (e, m, g, d) {
      function k(a, b, c, d) {
        a.getAttr("show_partial_next") && (b -= c / 10);
        var l = a.getAttr("minimum_gutter_width");
        a.getAttr("set_size");
        a = 0;
        for (var p = !0; 0 < b; )
          a++, (b = d && p ? b - c : b - (c + l)), (p = !1);
        0 > b && a--;
        return e.isFiniteNumber(a) && 0 < a ? a : 1;
      }
      function f(a, b, c, d, l, f, h) {
        "stretch" === a.getAttr("single_page_align") && d > f && (d = f);
        b -= c * d;
        a.getAttr("show_partial_next")
          ? ((a = b - l * (d + 1)),
            h && (a += l),
            (h = a / c),
            (b -= c * (0.5 < h ? 0.5 : h)))
          : h && (b += l);
        c = Math.ceil(b / (d + 1));
        if (!e.isFiniteNumber(c) || c < l) c = l;
        return c;
      }
      function h(a) {
        if (a.getAttr("auto_adjust_height"))
          if (a.getAttr("animating"))
            a.once("animating", function () {
              h(a);
            });
          else {
            var b = a.getAttr("maxHeight"),
              c = a.getDimensions();
            (b && e.isFiniteNumber(b)) || (b = 1);
            var d = b,
              l = a.getAttr("pageSize"),
              f = l * (a.getAttr("pageNumber") - 1);
            l = f + l - 1;
            c = c.items;
            var g = c.length,
              k;
            for (a.getAttr("show_partial_next") && l++; f <= l && f < g; f++)
              (k = c[f]) &&
                k.outerHeight > d &&
                (d = c[f].outerHeight || c[f].height);
            d > b &&
              (a.updateDimensionsCache({viewport: {height: d, outerHeight: d}}),
              a.setAttr("maxHeight", d),
              1 === b
                ? a.dom.$viewport.height(d)
                : e.animate(
                    a.dom.$viewport,
                    {height: d},
                    a.getAttr("height_animation_speed"),
                    "linear"
                  ));
          }
        else a.dom.$viewport.css("height", "");
      }
      function c(a) {
        a.onChange("pageNumber", function () {
          a.getAttr("hide_off_screen") &&
            a.dom.$carousel.children("li").css("visibility", "");
        });
        a.onChange("pageSize", function (b, c) {
          b > c && h(a);
        });
        a.onChange("loading", function (b) {
          b || h(a);
        });
        a.onChange("firstVisibleItem", function () {
          h(a);
        });
        a.onChange("animating", function (b) {
          if (!b && a.getAttr("hide_off_screen")) {
            var c = a.getAttr("firstVisibleItem") - 1,
              d = c + a.getAttr("pageSize") - 1;
            a.getAttr("show_partial_next") && d++;
            a.dom.$carousel.children("li").each(function (a, b) {
              a = a >= c && a <= d;
              m(b).css("visibility", a ? "" : "hidden");
            });
          }
        });
        a.onChange("single_page_align minimum_gutter_width", function () {
          b(a);
        });
        a.onChange("minimum_gutter_width", function () {
          b(a);
        });
      }
      function b(a) {
        var b = a.getDimensions(),
          c = b.viewport.width;
        b = b.getFirstCardWidth();
        var d = a.getAttr("minimum_gutter_width"),
          l = a.getAttr("set_size"),
          h = a.getAttr("first_item_flush_left"),
          g = k(a, c, b, h),
          m = f(a, c, b, g, d, l, h);
        a.setAttr("currentGutter", m);
        a.setAttr("pageSize", g);
        var z = a.dom.$carousel,
          n = z.children("li");
        d = n.length;
        var r = a.getAttr("totalPages"),
          A = a.getAttr("pageNumber"),
          C = a.getAttr("firstVisibleItem"),
          B = (A - 1) * g + 1;
        A > r
          ? ((C = (r - 1) * g + 1),
            a.setAttr("pageNumber", r),
            a.setAttr("firstVisibleItem", C))
          : C !== B &&
            ((r = Math.ceil(C / g)),
            (C = (r - 1) * g + 1),
            a.setAttr("pageNumber", r),
            a.setAttr("firstVisibleItem", C));
        var F = C - 1,
          G = F + g - 1;
        a.getAttr("show_partial_next") && G++;
        var H = a.getAttr("hide_off_screen"),
          I = m + "px",
          J = b + "px",
          y;
        n.each(function (a, b) {
          y = !H || (a >= F && a <= G);
          b.style[e.capabilities.rtl ? "marginRight" : "marginLeft"] =
            h && 0 === a ? 0 : I;
          b.style.visibility = y ? "" : "hidden";
          b.style.width = J;
        });
        var D;
        a.getAttr("first_item_flush_left")
          ? ((m = n.first().outerWidth(!0)),
            1 < n.length && (D = n.eq(1).outerWidth(!0)),
            (r = (d - 1) * D + m))
          : ((m = D = n.first().outerWidth(!0)), (r = d * D));
        g >= l
          ? ((r = c),
            (A = a.getAttr("single_page_align")),
            z.toggleClass("a-text-right", "right" === A),
            z.toggleClass("a-text-center", "center" === A),
            "center" === A && n.first().css("margin-left", 0))
          : z.removeClass("a-text-right a-text-center");
        r = g >= l ? c : r;
        z.css("width", r + "px");
        c = {carousel: {width: r, outerWidth: z.outerWidth()}, items: []};
        for (l = 0; l < d; l++)
          c.items.push({width: b, outerWidth: 0 === l ? m : D});
        a.updateDimensionsCache(c);
        a.gotoIndex(C, {animationDuration: 0, ignorePause: !0});
        a.triggerEvent("repaint");
      }
      return {
        repaint: b,
        init: function (a) {
          var f = a.getAttr("minimum_gutter_width");
          e.isFiniteNumber(f) ||
            ((f = 15), a.setAttr("minimum_gutter_width", f));
          a.setAttr("currentGutter", f);
          f = a.getAttr("height_animation_speed");
          e.isFiniteNumber(f) || a.setAttr("height_animation_speed", 200);
          a.setAttr(
            "first_item_flush_left",
            !!a.getAttr("first_item_flush_left")
          );
          a.setAttr("show_partial_next", !!a.getAttr("show_partial_next"));
          b(a);
          a.getAttr(d.NO_TRANSITION) || h(a);
          f = a.getDimensions();
          a.dom.$container
            .find(".a-carousel-left, .a-carousel-right, .a-carousel-viewport")
            .css(
              "height",
              Math.max(f.viewport.height, f.items[0] ? f.items[0].height : 0) +
                "px"
            );
          f = a.getAttr("firstVisibleItem");
          1 < f &&
            (a.setAttr("firstVisibleItem", f),
            (f = Math.ceil(f / a.getAttr("pageSize"))),
            a.gotoPage(f));
          c(a);
        },
        resize: function (a, c) {
          c.viewport && void 0 !== c.viewport.width && b(a);
        },
      };
    }
  );
  ("use strict");
  n.when("A", "jQuery", "p-detect", "a-carousel-utils").register(
    "a-carousel-display-swap",
    function (e, m, g, d) {
      function k(c) {
        if (c.getAttr("auto_adjust_height")) {
          var b = c.getAttr("maxHeight");
          (b && e.isFiniteNumber(b)) || (b = 1);
          var a = b;
          c.dom.$carousel
            .children("li")
            .not(".a-carousel-card-empty")
            .each(function (b, c) {
              b = m(c).outerHeight();
              a = Math.max(b, a);
            });
          a > b &&
            (c.setAttr("maxHeight", a),
            g.capabilities.transition
              ? 1 === b
                ? c.dom.$viewport.height(a)
                : e.animate(
                    c.dom.$viewport,
                    {height: a},
                    c.getAttr("height_animation_speed"),
                    "linear"
                  )
              : c.dom.$viewport.height(a),
            c.updateDimensionsCache({viewport: {height: a, outerHeight: a}}));
        } else c.dom.$viewport.css("height", "");
      }
      function f(c) {
        c.onChange("animating", function (b) {
          b || k(c);
        });
        c.onChange("loading", function (b) {
          b || k(c);
        });
        c.onChange("pageSize", function (b, a) {
          c.dom.$carousel.children("li").slice(b).remove();
          if (b > a) {
            a = c.getAttr("set_size");
            var e = c.getDimensions().getFirstCardWidth(),
              f = c.getAttr("currentGutter"),
              h = c.getAttr("fetchedItems"),
              l = c.getAttr("firstVisibleItem") - 1,
              g = c.dom.$carousel.children("li"),
              u = document.createDocumentFragment();
            if (m.isArray(h)) {
              for (var q = g.length; q < b; q++) {
                var n = q + l;
                g = m(
                  [
                    '\x3cli class\x3d"a-carousel-card a-carousel-card-empty" role\x3d"listitem" aria-setsize\x3d"',
                    a,
                    '" aria-posinset\x3d"',
                    n + 1,
                    '" style\x3d"width:',
                    e,
                    "px; margin-left:",
                    f,
                    'px;"\x3e',
                    c.getStaticLoader(),
                  ].join("")
                );
                h[n] && d.addElementToDom(g, d.getElementFromItem(h[n]));
                n >= a && g.removeClass("a-carousel-card-empty");
                u.appendChild(g[0]);
              }
              c.dom.$carousel.append(u);
            }
            k(c);
          }
        });
        c.onChange("set_size", function (b, a) {
          var d = c.getAttr("pageNumber"),
            f = c.getAttr("totalPages"),
            g = c.dom.$carousel.children("li");
          d === f &&
            b > a &&
            (g.length &&
              c.dom.$carousel.children("li").each(function (a, b) {
                e.trim(b.innerHTML) ||
                  ((b.className += " a-carousel-card-empty"),
                  (b.innerHTML = c.getStaticLoader()));
              }),
            0 === a && h(c));
        });
        c.onChange("single_page_align minimum_gutter_width", function () {
          h(c);
        });
        c.onChange("minimum_gutter_width", function () {
          h(c);
        });
      }
      function h(c) {
        var b = c.getDimensions(),
          a = b.viewport.width,
          d = b.getFirstCardWidth(),
          f = c.getAttr("minimum_gutter_width");
        b = c.getAttr("set_size");
        var h = c.getAttr("minimum_gutter_width");
        c.getAttr("set_size");
        h = Math.max(Math.floor(a / (d + h)), 1);
        h = e.isFiniteNumber(h) ? h : 1;
        var l = h;
        "stretch" === c.getAttr("single_page_align") && l > b && (l = b);
        l = Math.ceil((a - d * l) / (l + 1));
        e.isFiniteNumber(l) || (l = f);
        var g = l;
        c.setAttr("currentGutter", g);
        c.setAttr("pageSize", h);
        l = c.dom.$carousel;
        var k = l.children("li");
        f = k.length;
        d += g;
        var m = f * d,
          n = Math.min(h, b);
        c.dom.$carousel.children("li").slice(n).remove();
        k.css("margin-left", g + "px");
        h >= b
          ? ((m = a),
            (a = c.getAttr("single_page_align")),
            l.toggleClass("a-text-right", "right" === a),
            l.toggleClass("a-text-center", "center" === a),
            "center" === a && k.first().css("margin-left", 0))
          : l.removeClass("a-text-right a-text-center");
        for (
          a = {carousel: {width: m, outerWidth: l.outerWidth()}, items: []};
          f--;

        )
          a.items.push({outerWidth: d});
        c.updateDimensionsCache(a);
        c.triggerEvent("repaint");
      }
      return {
        repaint: h,
        init: function (c) {
          var b = c.getAttr("minimum_gutter_width");
          b || ((b = 15), c.setAttr("minimum_gutter_width", b));
          c.setAttr("currentGutter", b);
          b = c.getAttr("height_animation_speed");
          e.isFiniteNumber(b) || c.setAttr("height_animation_speed", 200);
          f(c);
          h(c);
          b = c.getDimensions();
          c.dom.$container
            .find(".a-carousel-left, .a-carousel-right, .a-carousel-viewport")
            .css(
              "height",
              Math.max(b.viewport.height, b.items[0] ? b.items[0].height : 0) +
                "px"
            );
          b = c.getAttr("firstVisibleItem");
          1 < b &&
            (c.setAttr("firstVisibleItem", b),
            (b = Math.ceil(b / c.getAttr("pageSize"))),
            c.gotoPage(b));
        },
        resize: function (c, b) {
          b.viewport && void 0 !== b.viewport.width && h(c);
        },
      };
    }
  );
  ("use strict");
  n.when("A", "jQuery").register("a-carousel-display-single", function (e, m) {
    function g(d) {
      if (d.getAttr("auto_adjust_height"))
        if (d.getAttr("animating"))
          d.once("animating", function () {
            g(d);
          });
        else
          d.dom.$viewport.css("height", "auto"),
            e.delay(function () {
              d.dom.$viewport.height(d.dom.$viewport.height());
            }, 0);
      else d.dom.$viewport.css("height", "");
    }
    function d(d, c) {
      var b = d.dom.$carousel.children("li"),
        a = d.getAttr("firstVisibleItem") - 1;
      d = d.getAttr("show_partial_next") ? 2 : 1;
      a = b.slice(a, a + d);
      b.not(a).css("visibility", "hidden");
      c && a.css("visibility", "");
    }
    function k(e) {
      e.getAttr("fixed_height") ||
        (e.dom.$viewport.delegate("img", "load", function () {
          g(e);
        }),
        e.onChange("loading", function (c) {
          c || g(e);
        }),
        e.onChange("pageNumber", function () {
          e.getAttr("hide_off_screen") &&
            e.dom.$carousel.children("li").css("visibility", "");
        }),
        e.onChange("animating", function (c) {
          !c && e.getAttr("hide_off_screen") && d(e);
        }),
        e.onChange("minimum_gutter_width", function () {
          f(e);
        }));
    }
    function f(e) {
      var c = e.getDimensions(),
        b = c.viewport.width,
        a = e.getAttr("show_partial_next"),
        f = e.getAttr("minimum_gutter_width"),
        g = e.getAttr("set_size"),
        h = e.dom.$carousel.children("li");
      b -= 2 * f;
      a && (b -= f + c.viewport.width / 3);
      h.css({width: b + "px", margin: "0 " + f + "px"});
      c = b + 2 * f;
      a = c * g;
      e.dom.$carousel.width(a);
      for (a = {carousel: {width: a}, items: []}; g--; )
        a.items[g] = {width: b, outerWidth: c};
      e.updateDimensionsCache(a);
      e.getAttr("hide_off_screen") && d(e, !0);
      e.gotoIndex(e.getAttr("firstVisibleItem"), {
        animationDuration: 0,
        ignorePause: !0,
      });
      e.triggerEvent("repaint");
    }
    return {
      repaint: f,
      init: function (d) {
        var c = d.getAttr("minimum_gutter_width");
        d.setAttr("minimum_gutter_width", e.isFiniteNumber(c) ? c : 14);
        d.setAttr("show_partial_next", !!d.getAttr("show_partial_next"));
        d.setAttr("pageSize", 1);
        d.setAttr("pageSize", 1);
        c = d.getAttr("fixed_height");
        e.isFiniteNumber(c)
          ? d.dom.$viewport.height(c)
          : d.setAttr("fixed_height", !1);
        d.dom.$carousel.children("li").css("visibility", "visible");
        k(d);
        this.repaint(d);
        g(d);
      },
      resize: function (d, c) {
        c.viewport &&
          void 0 !== c.viewport.width &&
          (this.repaint(d), d.getAttr("fixed_height") || g(d));
      },
    };
  });
  ("use strict");
  n.when("A", "jQuery", "a-carousel-constants").register(
    "a-carousel-display-peekcircular",
    function (e, m, g) {
      function d(d) {
        return function (f) {
          return e.isFiniteNumber(f) ? f : d;
        };
      }
      m = {};
      m[g.PAGE_SIZE] = 1;
      m[g.MIN_GUTTER] = d(14);
      m[g.PEEK_PERCENTAGE] = d(10);
      return {
        initAttrs: m,
        init: function (d) {
          var e = this;
          d.onChange(g.PEEK_PERCENTAGE, function (f, c) {
            e.repaint(d);
          });
          d.dom.$carousel.children("li").css("visibility", "visible");
          e.repaint(d);
        },
        repaint: function (d) {
          var f = d.getAttr(g.MIN_GUTTER),
            h = d.getAttr(g.SET_SIZE),
            c = d.getAttr(g.PEEK_PERCENTAGE),
            b = d.getDimensions().viewport.width,
            a = d.dom.$carousel,
            p = a.children("li");
          c = (c / 100) * b;
          var t = b - 2 * c - f,
            k = t + 2 * f;
          b = k * h;
          a.width(b);
          p.css({
            width: t + "px",
            "margin-left": f + "px",
            "margin-right": f + "px",
          });
          d.updateDimensionsCache({
            carousel: {width: b},
            items: e.map(e.range(h), function () {
              return {width: t, outerWidth: k};
            }),
          });
          d.setAttr(g.PEEK_WIDTH, c, !1);
          d.triggerEvent("repaint");
        },
        resize: function (d, e) {
          e.viewport && e.viewport.width !== y && this.repaint(d);
        },
      };
    }
  );
  ("use strict");
  n.when("A").register("a-carousel-display-variablewidth", function (e) {
    return {
      init: e.constants.NOOP,
      resize: e.constants.NOOP,
      repaint: e.constants.NOOP,
    };
  });
  ("use strict");
  n.when(
    "a-carousel-stretchygoodness",
    "a-carousel-display-swap",
    "a-carousel-display-single",
    "a-carousel-display-peekcircular",
    "a-carousel-display-variablewidth"
  ).register("a-carousel-strategies-display", function (e, m, g, d, k) {
    return {
      swap: m,
      single: g,
      peekCircular: d,
      stretchyGoodness: e,
      variableWidth: k,
      default: "stretchyGoodness",
    };
  });
  ("use strict");
  n.when("A", "jQuery", "a-carousel-utils").register(
    "a-carousel-transition-swap",
    function (e, m, g) {
      function d(d, b) {
        var a = d.getAttr("preloadedImages");
        a || (a = []);
        for (var c = [], f = b.length - 1; 0 <= f; f--)
          if (b[f] && !a[f]) {
            var h = g.getElementFromItem(b[f]);
            h &&
              m("img", h).each(function () {
                c.push(this.src);
              });
            a[f] = !0;
          }
        e.preload(c);
        d.setAttr("preloadedImages", a);
      }
      function k(d) {
        return "number" === typeof d
          ? d
            ? 0 > d
              ? -1
              : 1
            : isNaN(d)
            ? NaN
            : 0
          : NaN;
      }
      function f(d, b) {
        d.getAttr("pageNumber");
        d.getAttr("pageSize");
        var a = d.getAttr("firstVisibleItem"),
          c = d.getAttr("delay_time"),
          f = d.dom.$carousel.children("li"),
          h = f.filter(".a-carousel-card-empty");
        h.length && d.setAttr("loading", !0);
        h.each(function (l, p) {
          var k = m(p);
          p = f.index(p) + a - 1;
          var v = b[p];
          v &&
            e.delay(function () {
              g.addElementToDom(k, g.getElementFromItem(v));
              l === h.length - 1 && d.setAttr("loading", !1);
            }, 0 + c);
        });
      }
      function h(d, b, a) {
        a = a || {};
        var c = d.getAttr("pageNumber");
        if (b !== c) {
          var f = d.getAttr("set_size"),
            h = d.getAttr("totalPages"),
            l = d.getAttr("circular"),
            v = d.getAttr("pageSize"),
            m = a.delayTime || d.getAttr("delay_time"),
            q = k(a.direction) || NaN;
          !l && 1 > b
            ? (b = 1)
            : !l && b > h
            ? (b = h)
            : l && 1 > b
            ? (b = h)
            : l && b > h && (b = 1);
          q || (q = c < b ? 1 : -1);
          a.startover && (q = m = 1);
          var n = v * (b - 1),
            w = 1 === q ? 0 : v - 1;
          d.setAttr("pageNumber", b);
          d.setAttr("firstVisibleItem", n + 1);
          d.setAttr("animating", !0);
          var r = e.interval(function () {
            var a = n + w;
            if (r !== d.getAttr("responsiveTimerId")) clearInterval(r);
            else if ((-1 === q && 0 > w) || (1 === q && w >= v))
              d.setAttr("responsiveTimerId", y), d.setAttr("animating", !1);
            else {
              var b = d.dom.$carousel.children("li").eq(w),
                c = d.getAttr("fetchedItems")[a];
              c
                ? g.addElementToDom(b, g.getElementFromItem(c))
                : a < f
                ? b.html(d.getStaticLoader()).addClass("a-carousel-card-empty")
                : b.empty().removeClass("a-carousel-card-empty");
              w += q;
            }
          }, m);
          d.setAttr("responsiveTimerId", r);
        }
      }
      return {
        init: function (c) {
          var b = c.getAttr("delay_time");
          e.isFiniteNumber(b) || c.setAttr("delay_time", 30);
          c.onChange("responsiveTimerId", function (a, b) {
            b !== a && clearInterval(b);
          });
          c.onChange("fetchedItems", function (a, b) {
            f(c, a);
            d(c, a);
          });
          d(c, c.getAttr("fetchedItems"));
        },
        gotoIndex: function (d, b, a) {
          a = a || {};
          var c = d.getAttr("pageSize");
          h(d, Math.ceil(b / c), a);
        },
        gotoNextPage: function (d, b) {
          b = b || {};
          var a = d.getAttr("pageNumber");
          b.direction = -1;
          h(d, ++a, b);
        },
        gotoPrevPage: function (d, b) {
          b = b || {};
          var a = d.getAttr("pageNumber");
          b.direction = 1;
          h(d, --a, b);
        },
        gotoPage: h,
      };
    }
  );
  ("use strict");
  n.when("A", "jQuery", "a-carousel-utils", "a-carousel-constants").register(
    "a-carousel-transition-slide",
    function (e, m, g, d) {
      function k(b) {
        var a = b.dom.$carousel.children("li").length,
          e = a + 1,
          c = b.getAttr(d.SET_SIZE),
          f = c - a;
        if (0 < f) {
          f = e + f - 1;
          for (var l = []; e <= f; e++) l.push(b.getEmptyCard(e, c));
          b.dom.$carousel.append(l.join(""));
          b.setAttr(d.LOADING, !0);
          f = b.getAttr(d.FETCHED_ITEMS);
          l = b.dom.$carousel.children("li");
          var h;
          for (e = a; e < c; e++)
            if ((h = f[e])) {
              var k = g.getElementFromItem(h);
              a = l.eq(e);
              g.addElementToDom(a, k);
              f[e] = g.clearElementFromItem(h);
            }
          b.strategies.display.repaint && b.strategies.display.repaint(b);
          b.setAttr(d.FETCHED_ITEMS, f, !0);
          b.setAttr(d.LOADING, !1);
        }
      }
      function f(b, a, c) {
        if (b.getAttr(d.ANIMATING))
          b.once(d.ANIMATING, function () {
            f(b, a, c);
          });
        else {
          var h = b.getDimensions().items,
            p = [];
          if (!c || a.length >= c.length) {
            b.setAttr(d.LOADING, !0);
            for (
              var l = b.dom.$carousel.children("li"), k, m, q = a.length;
              q--;

            )
              if (
                ((m = a[q]),
                null === m && p.push(q),
                m && !e.equals(m, c[q]) && !0 !== m && !0 !== m.content)
              ) {
                var n = g.getElementFromItem(m);
                k = l.eq(q);
                k.length &&
                  (g.addElementToDom(k, n),
                  (h[q] = {
                    width: k.outerWidth(),
                    outerWidth: k.outerWidth(!0),
                    height: k.outerHeight(),
                    outerHeight: k.outerHeight(!0),
                  }),
                  (a[q] = g.clearElementFromItem(m)));
              }
            p.length &&
              (e.each(p, function (b) {
                l.eq(b).remove();
                a.splice(b, 1);
              }),
              b.setAttr(d.SET_SIZE, b.getAttr(d.SET_SIZE) - p.length),
              b.triggerEvent("repaint"));
          }
          b.setAttr(d.FETCHED_ITEMS, a);
          b.updateDimensionsCache({items: h});
          b.setAttr(d.LOADING, !1);
        }
      }
      var h = e.capabilities.touch ? 2e3 : 3e3,
        c = e.capabilities.rtl ? -1 : 1;
      return {
        wrapToFirst: function (b) {
          var a = b.getAttr(d.PAGE_SIZE),
            e = b.getDimensions().getFirstCardWidth(),
            c = this;
          b.gotoPixel(a * e * -1, {
            animationDuration: 0,
            callback: function () {
              b.setAttr(d.CURRENTLY_WRAPPING, !1);
              c.gotoPage(b, 1);
            },
          });
        },
        wrapToLast: function (b) {
          b.getAttr(d.PAGE_SIZE);
          var a = b.getAttr(d.TOTAL_PAGES),
            e = this,
            c = b.getDimensions().carousel.width;
          b.gotoPixel(c, {
            animationDuration: 0,
            callback: function () {
              b.setAttr(d.CURRENTLY_WRAPPING, !1);
              e.gotoPage(b, a);
            },
          });
        },
        gotoPage: function (b, a, e) {
          e = e || {};
          (void 0 === e.animationDuration || 0 < e.animationDuration) &&
            !e.silent &&
            b.setAttr(d.ANIMATING, !0);
          var c = b.getAttr(d.TOTAL_PAGES);
          0 < a && a <= c && b.setAttr(d.PAGE_NUMBER, a);
          var f = b.getAttr(d.CIRCULAR);
          !f && 1 > a
            ? ((a = 1),
              (e.animationDuration = Math.pow(
                b.getAttr(d.ANIMATION_SPEED) * b.getAttr(d.SPRINGINESS)
              )))
            : !f &&
              a > c &&
              ((a = c),
              (e.animationDuration = Math.pow(
                b.getAttr(d.ANIMATION_SPEED),
                b.getAttr(d.SPRINGINESS)
              )));
          this.gotoIndex(b, b.getAttr(d.PAGE_SIZE) * (a - 1) + 1, e);
        },
        gotoIndex: function (b, a, c) {
          c = c || {};
          (void 0 === c.animationDuration || 0 < c.animationDuration) &&
            !c.silent &&
            b.setAttr(d.ANIMATING, !0);
          var f = b.getAttr(d.CIRCULAR) && !b.getAttr(d.CURRENTLY_WRAPPING),
            g = c.callback,
            l = this,
            h = !1,
            k = b.getViewportWidth(),
            m = Math.ceil(a / b.getAttr(d.PAGE_SIZE));
          m !== b.getAttr(d.PAGE_NUMBER) &&
            0 < m &&
            m <= b.getAttr(d.TOTAL_PAGES) &&
            b.setAttr(d.PAGE_NUMBER, m);
          b.setAttr(d.FIRST_VISIBLE_ITEM, a);
          if (1 > a) {
            if (f) {
              h = -1 * k;
              var p = function () {
                g && g();
                l.wrapToLast(b);
              };
            }
          } else
            a > b.getAttr(d.SET_SIZE)
              ? f &&
                ((h = b.getAttr(d.CURRENT_PIXEL) + k),
                (p = function () {
                  g && g();
                  l.wrapToFirst(b);
                }))
              : (h = b.getItemOffset(a));
          p
            ? (b.setAttr(d.CURRENTLY_WRAPPING, !0),
              (c.callback = p),
              (c.easingFunction = c.easingFunction || b.getAttr(d.WRAP_EASING)),
              (c.animationSpeed =
                1.3 *
                (e.isFiniteNumber(c.animationSpeed)
                  ? c.animationSpeed
                  : b.getAttr(d.ANIMATION_SPEED))))
            : (c.callback = g);
          !1 !== h && this.gotoPixel(b, h, c);
        },
        gotoPixel: function (b, a, c) {
          var f = b.getAttr(d.CURRENT_PIXEL);
          if (a !== f) {
            c = c || {};
            var g = c.easingFunction || "ease-out",
              l = c.callback;
            b.getViewportWidth();
            if (void 0 !== c.animationDuration) var h = c.animationDuration;
            else
              (h = e.isFiniteNumber(c.animationSpeed)
                ? c.animationSpeed
                : b.getAttr(d.ANIMATION_SPEED)),
                (f = Math.abs(a - f)),
                (h = 0 === h ? 0 : Math.floor((f / h) * 1e3));
            0 < h && !c.silent && b.setAttr(d.ANIMATING, !0);
            if (e.isFiniteNumber(a)) {
              f =
                0 < h
                  ? function () {
                      l && l();
                      b.getAttr(d.CURRENTLY_WRAPPING) ||
                        b.setAttr(
                          d.ANIMATING,
                          e.isAnimated(b.dom.$carousel),
                          c.silent
                        );
                    }
                  : l;
              var k = e.capabilities.rtl ? 1 : -1;
              b.setAttr(d.CURRENT_PIXEL, a);
              e.animate(b.dom.$carousel, {left: a * k}, h, g, f);
            } else
              n.error(
                "Target pixel is not a finite number",
                "a-carousel-transition-slide",
                "gotoPixel"
              );
          }
        },
        gotoNextPage: function (b, a) {
          var c = b.getAttr(d.PAGE_NUMBER);
          this.gotoPage(b, ++c, a);
        },
        gotoPrevPage: function (b, a) {
          var c = b.getAttr(d.PAGE_NUMBER);
          this.gotoPage(b, --c, a);
        },
        onSwipe: function (b, a) {
          if (!b.getAttr(d.CURRENTLY_WRAPPING)) {
            var f = b.getAttr(d.FIRST_VISIBLE_ITEM),
              g = b.getAttr(d.PAGE_SIZE),
              h = b.getAttr(d.PAGE_NUMBER),
              l = 0 > c * a.velocityX,
              k = f;
            l && h < b.getAttr(d.TOTAL_PAGES)
              ? (k = f + g)
              : !l && 1 < h && (k = f - g);
            g = b.getAttr(d.CURRENT_PIXEL);
            h = b.getItemOffset(k);
            a = Math.abs((1e3 * (l ? g - h : g + h)) / a.velocityX);
            a = Math.max(a, 300);
            a = Math.min(a, 1.2 * e.viewport().width);
            a = {
              animationDuration: a,
              easingFunction: b.getAttr(d.TOUCH_EASING),
            };
            k !== f || b.getAttr("circular")
              ? l
                ? b.gotoNextPage(a)
                : b.gotoPrevPage(a)
              : ((a.animationSpeed = 0.95 * e.viewport().width),
                delete a.animationDuration,
                b.gotoIndex(k, a));
          }
        },
        onPan: function (b, a) {
          if (!b.getAttr(d.CURRENTLY_WRAPPING)) {
            b.setAttr(d.ANIMATING, !0);
            var f = b.getItemOffset(b.getAttr(d.FIRST_VISIBLE_ITEM)),
              g = f - c * a.touchDeltaX,
              h = b.getAttr(d.CIRCULAR),
              l = b.getAttr(d.PAGE_NUMBER),
              k = b.getAttr(d.TOTAL_PAGES);
            a.ended
              ? ((f = {
                  easingFunction: b.getAttr(d.TOUCH_EASING),
                  animationSpeed: 0.95 * e.viewport().width,
                  silent: !0,
                }),
                (a = c * a.touchDeltaX),
                (g = Math.abs(a) < 0.4 * b.getViewportWidth()),
                (!h && ((0 > a && k === l) || (0 < a && 1 === l))) || g
                  ? b.gotoPage(l, f)
                  : 0 > a
                  ? b.gotoNextPage(f)
                  : b.gotoPrevPage(f))
              : (!h &&
                  ((h = b.getAttr(d.SPRINGINESS)),
                  (0 > g && 0 < a.touchDeltaX) ||
                    (l === k && 0 > a.touchDeltaX)) &&
                  ((l = Math.pow(Math.abs(a.touchDeltaX), h)),
                  (g = 0 >= g ? -1 * l : f + l)),
                b.gotoPixel(g, {
                  easingFunction: b.getAttr(d.TOUCH_EASING),
                  animationDuration: 0,
                  silent: !0,
                }));
          }
        },
        init: function (b) {
          var a = b.getAttr(d.ANIMATION_SPEED);
          e.isFiniteNumber(a) || b.setAttr(d.ANIMATION_SPEED, h);
          void 0 === b.getAttr(d.WRAP_EASING) &&
            b.setAttr(d.WRAP_EASING, "linear");
          k(b);
          b.onChange(d.FETCHED_ITEMS, function (a, d) {
            f(b, a, d);
          });
          b.onChange(d.SET_SIZE, function (a, d) {
            a > d && k(b);
          });
        },
      };
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-carousel-utils",
    "a-carousel-circular-utils",
    "a-carousel-constants"
  ).register("a-carousel-transition-slidecircular", function (e, m, g, d) {
    function k(a) {
      var b = a.dom.$carousel.children("li").length,
        f = a.getAttr(d.SET_SIZE),
        l = f - b,
        g = c(a, b);
      0 < l &&
        ((b += 1),
        (l = e.map(e.range(b, b + l), function (b) {
          return a.getEmptyCard(b, f);
        })),
        g.after(l.join("")),
        a.measure("items"));
    }
    function f(c, e) {
      var f = c.getAttr(d.SET_SIZE);
      if (2 < c.getAttr(d.SET_SIZE)) {
        var g = a(c, c.getAttr(d.FIRST_VISIBLE_ITEM)),
          r = Math.round(c.getAttr(d.SET_SIZE) / 2);
        f = h(r, g, f);
        0 !== f.quantity &&
          (l(c, f.direction, f.quantity),
          (g = f.direction === u.CLOCKWISE ? g - f.quantity : g + f.quantity),
          e.gotoPixel(c, b(c, g), {animationDuration: 0}));
      }
    }
    function h(a, b, d) {
      var c = {};
      a === b
        ? (a = b = 0)
        : a > b
        ? ((b = a - b), (a = d - b))
        : ((a = b - a), (b = d - a));
      c.direction = a <= b ? u.CLOCKWISE : u.COUNTER_CLOCKWISE;
      c.quantity = Math.min(a, b);
      return c;
    }
    function c(b, d) {
      return b.dom.$carousel.children("li").eq(a(b, d) - 1);
    }
    function b(a, b) {
      var c = Math.floor(a.getAttr(d.PEEK_WIDTH) || 0);
      return a.getItemOffset(b) - c;
    }
    function a(a, b) {
      b = b || 1;
      var c = a.getAttr(d.TRANSITION_SLIDE_CIRCULAR_FIRST_CARD_IDX);
      a = a.getAttr(d.SET_SIZE);
      return g.relativeIndexFromIndex(b, c, a);
    }
    function p(b, f, l) {
      if (b.getAttr(d.ANIMATING))
        b.once(d.ANIMATING, function () {
          p(b, f, l);
        });
      else {
        var g = b.getDimensions().items,
          h = Math.min(f.length, b.getAttr(d.SET_SIZE));
        if (!l || f.length >= l.length)
          b.setAttr(d.LOADING, !0),
            e.each(e.range(h), function (d) {
              var h = d + 1,
                k = f[d],
                B = c(b, h),
                r = k && !(!0 === k || !0 === k.content);
              k &&
                !e.equals(k, l[d]) &&
                B.length &&
                r &&
                ((h = a(b, h)),
                (g[h] = {
                  width: B.outerWidth(),
                  outerWidth: B.outerWidth(!0),
                  height: B.outerHeight(),
                  outerHeight: B.outerHeight(!0),
                }),
                m.addElementToDom(B, m.getElementFromItem(k)),
                (f[d] = m.clearElementFromItem(k)));
            }),
            b.setAttr(d.LOADING, !1);
        b.setAttr(d.FETCHED_ITEMS, f);
        b.updateDimensionsCache({items: g});
      }
    }
    function t(a) {
      var b = {reached: !1, left: !1, right: !1};
      if (!(2 < a.getAttr(d.SET_SIZE))) {
        var c = a.getAttr(d.PAGE_NUMBER);
        a = a.getAttr(d.SET_SIZE);
        1 === c && ((b.reached = !0), (b.left = !0));
        c === a && ((b.reached = !0), (b.right = !0));
      }
      return b;
    }
    function x(a, b, c) {
      var e = t(a),
        f = a.getAttr(d.PAGE_NUMBER);
      e.reached && e[b]
        ? a.gotoPage(f)
        : ("right" === b ? a.gotoNextPage : a.gotoPrevPage).call(a, c);
    }
    function l(a, b, c) {
      var e = a.getAttr(d.TRANSITION_SLIDE_CIRCULAR_FIRST_CARD_IDX) || 1,
        f = a.getAttr(d.SET_SIZE),
        l = a.dom.$carousel.children("li"),
        h = a.dom.$carousel;
      b === u.CLOCKWISE
        ? (g.rotateCW(h, l, c), (e = g.firstCardIndexAfterRotate(c, e, f)))
        : (g.rotateCCW(a.dom.$carousel, a.dom.$carousel.children("li"), c),
          (e = g.firstCardIndexAfterRotate(-1 * c, e, f)));
      a.setAttr(d.TRANSITION_SLIDE_CIRCULAR_FIRST_CARD_IDX, e);
      c = c || 1;
      b = b || u.CLOCKWISE;
      e = a.getDimensions().items;
      e = b === u.CLOCKWISE ? g.rotateArrayCW(e, c) : g.rotateArrayCCW(e, c);
      a.updateDimensionsCache({items: e});
    }
    function v(c, g, h, k, m) {
      var B = m.callback,
        r = a(c, c.getAttr(d.FIRST_VISIBLE_ITEM)),
        v = c.getAttr(d.CURRENT_PIXEL) - b(c, r);
      e.sequence(
        function (a) {
          l(c, g, k);
          a();
        },
        function (a) {
          h.gotoPixel(c, b(c, g === u.CLOCKWISE ? r - k : r + k) + v, {
            animationDuration: 0,
            callback: a,
          });
        },
        function (a) {
          m.callback = a;
          h.gotoPixel(c, b(c, r), m);
        },
        function (a) {
          f(c, h);
          a();
        },
        function (a) {
          B && B();
          a();
        }
      )();
    }
    var u = {CLOCKWISE: 1, COUNTER_CLOCKWISE: -1},
      q = e.capabilities.rtl ? -1 : 1,
      z = e.capabilities.touch ? 2e3 : 3e3,
      w = {};
    w[d.HIDE_OFF_SCREEN] = !1;
    w[d.ANIMATION_SPEED] = (function (a) {
      return function (b) {
        return e.isFiniteNumber(b) ? b : a;
      };
    })(z);
    w[d.TRANSITION_SLIDE_CIRCULAR_FIRST_CARD_IDX] = 1;
    return {
      initAttrs: w,
      init: function (a) {
        k(a);
        a.onChange(d.FETCHED_ITEMS, function (b, d) {
          p(a, b, d);
          a.strategies.display.repaint(a);
        });
        a.onChange(d.SET_SIZE, function (b, d) {
          b > d && k(a);
        });
        a.onChange(d.PEEK_WIDTH, function (b, c) {
          b !== c && ((b = a.getAttr(d.FIRST_VISIBLE_ITEM)), a.gotoIndex(b));
        });
      },
      afterInit: function (a) {
        f(a, this);
        a.strategies.display.repaint(a);
        a.gotoPage(a.getAttr(d.PAGE_NUMBER));
      },
      gotoPage: function (a, b, c) {
        c = c || {};
        var e = a.getAttr(d.TOTAL_PAGES);
        0 < b &&
          b <= e &&
          (a.setAttr(d.PAGE_NUMBER, b),
          this.gotoIndex(a, a.getAttr(d.PAGE_SIZE) * (b - 1) + 1, c));
      },
      gotoIndex: function (c, e, f) {
        var l = c.getAttr(d.SET_SIZE),
          g = a(c, c.getAttr(d.FIRST_VISIBLE_ITEM)),
          k = a(c, e);
        g === k
          ? this.gotoPixel(c, b(c, g), f)
          : (2 < c.getAttr(d.SET_SIZE)
              ? ((l = h(g, k, l)),
                f.startover &&
                  (5 < l.quantity
                    ? (f.animationDuration = 1250)
                    : (delete f.animationDuration,
                      (f.animationSpeed =
                        5 * c.getDimensions().viewport.width))),
                v(c, l.direction, this, l.quantity, f))
              : this.gotoPixel(c, b(c, e), f),
            c.setAttr(d.FIRST_VISIBLE_ITEM, e));
      },
      gotoPixel: function (a, b, c) {
        var f = a.getAttr(d.CURRENT_PIXEL);
        if (b !== f) {
          e.isFiniteNumber(b) ||
            n.error(
              "Target pixel is not a finite number",
              "a-carousel-transition-slide-circular",
              "gotoPixel"
            );
          c = c || {};
          var l = c.easingFunction || "ease-out",
            g = c.callback;
          if (c.animationDuration !== y) var h = c.animationDuration;
          else
            (h = e.isFiniteNumber(c.animationSpeed)
              ? c.animationSpeed
              : a.getAttr(d.ANIMATION_SPEED)),
              (f = Math.abs(b - f)),
              (h = 0 === h ? 0 : Math.floor((f / h) * 1e3));
          0 < h &&
            (!c.silent && a.setAttr(d.ANIMATING, !0),
            (g = function () {
              c.callback && c.callback();
              a.setAttr(d.ANIMATING, e.isAnimated(a.dom.$carousel), c.silent);
            }));
          f = e.capabilities.rtl ? u.CLOCKWISE : u.COUNTER_CLOCKWISE;
          a.setAttr(d.CURRENT_PIXEL, b);
          e.animate(a.dom.$carousel, {left: b * f}, h, l, g);
        }
      },
      gotoNextPage: function (a, b) {
        var c = a.getAttr(d.PAGE_NUMBER);
        c = c === a.getAttr(d.TOTAL_PAGES) ? 1 : c + 1;
        this.gotoPage(a, c, b);
      },
      gotoPrevPage: function (a, b) {
        var c = a.getAttr(d.PAGE_NUMBER);
        c = 1 === c ? a.getAttr(d.TOTAL_PAGES) : c - 1;
        this.gotoPage(a, c, b);
      },
      onSwipe: function (c, f) {
        var l = c.getAttr(d.CURRENT_PIXEL),
          g = c.getAttr(d.PAGE_SIZE),
          h = a(c, c.getAttr(d.FIRST_VISIBLE_ITEM)),
          k = 0 > q * f.velocityX;
        g = b(c, k ? h + g : h - g);
        l = Math.abs((1e3 * (k ? l - g : l + g)) / f.velocityX);
        k = 1.2 * e.viewport().width;
        x(c, 0 > q * f.touchDeltaX ? "right" : "left", {
          animationDuration: Math.min(Math.max(l, 300), k),
          easingFunction: c.getAttr(d.TOUCH_EASING),
        });
      },
      onPan: function (c, f) {
        c.setAttr(d.ANIMATING, !0);
        var l = c.getAttr(d.PAGE_NUMBER),
          g = a(c, c.getAttr(d.FIRST_VISIBLE_ITEM));
        g = b(c, g);
        g = t(c).reached ? g - q * f.touchDeltaX * 0.4 : g - q * f.touchDeltaX;
        f.ended
          ? ((g = {
              easingFunction: c.getAttr(d.TOUCH_EASING),
              animationSpeed: 0.95 * e.viewport().width,
              silent: !0,
            }),
            Math.abs(f.touchDeltaX) >= 0.4 * c.getViewportWidth()
              ? x(c, 0 > q * f.touchDeltaX ? "right" : "left", g)
              : c.gotoPage(l, g))
          : c.gotoPixel(g, {
              easingFunction: c.getAttr(d.TOUCH_EASING),
              animationDuration: 0,
              silent: !0,
            });
      },
    };
  });
  ("use strict");
  n.when("A", "a-carousel-utils", "a-carousel-constants").register(
    "a-carousel-transition-freescroll",
    function (e, m, g) {
      function d(a) {
        p[a.__id] || (p[a.__id] = new t(a));
        return p[a.__id];
      }
      function k(b) {
        for (var c = b.countItems(), d = [], f = 0; f < c; f++) d.push(!0);
        b.setAttr(g.FETCHED_ITEMS, d);
        b.getAttr("auto_adjust_height_freescroll") &&
          (e.$(b.getViewport()).css("height", "auto"),
          a(b),
          e.$(b.getViewport()).css("overflow-y", "hidden"));
      }
      function f(a) {
        var b = a.countItems(),
          c = a.getAttr(g.SET_SIZE),
          d = [];
        if (c > b) {
          for (var e = 0; e < c - b; e++) {
            var f = b + e + 1;
            d.push(a.getEmptyCard(f, c));
          }
          a.appendItems(d);
          a.shouldRepaint() && a.repaint();
        }
      }
      function h(b, c, d) {
        if (!d || c.length >= d.length)
          for (var f = b.getItems(), h = c.length, l; h--; )
            (l = c[h]) &&
              !e.equals(l, d[h]) &&
              !0 !== l &&
              !0 !== l.content &&
              b.hasItem(f, h) &&
              (c[h] = b.insertFetchedItem(l, f, h));
        b.setAttr(g.FETCHED_ITEMS, c);
        a(b);
      }
      function c(a) {
        a.attachScrollListener(function () {
          var c = a.hasEmptyCard();
          var d = a.getAttr("auto_adjust_height_freescroll"),
            e = a.getAttr("lastIndexChecked"),
            f = a.countItems();
          c || (d && e < f - 1)
            ? (c = !0)
            : (a.detachScrollListener(), (c = !1));
          c && a.throttle("detect", b);
        });
      }
      function b(c) {
        var d =
            "undefined" !== typeof c.getAttr(g.LOADING_THRESHOLD_PIXELS)
              ? c.getAttr(g.LOADING_THRESHOLD_PIXELS)
              : 400,
          e = c.measureWidth(),
          f = c.getFirstEmptyDetails(),
          h = c.getViewport();
        -1 !== f.index && f.left < e + d
          ? c.wantNext(
              f.index,
              "undefined" !== typeof c.getAttr(g.NEXT_REQUEST_SIZE)
                ? c.getAttr(g.NEXT_REQUEST_SIZE)
                : 10
            )
          : c.getAttr("currentScrollPosition") === h.scrollLeft()
          ? a(c)
          : c.throttle("detect", b);
        c.setAttr("currentScrollPosition", h.scrollLeft());
      }
      function a(a) {
        if (a.getAttr("auto_adjust_height_freescroll")) {
          var b = a.getAttr("lastIndexChecked"),
            c = a.getAttr("lastScrollPosition"),
            d = a.getAttr("maxHeight"),
            f = a.getViewport();
          if (c < f.scrollLeft()) {
            c = a.getItems();
            var h = a.measureWidth(),
              l = a.countItems() - 1,
              k = a.getFirstEmptyDetails().index;
            -1 !== k && (l = Math.min(l, k - 1));
            for (b += 1; b <= l; ) {
              if (c[b].getBoundingClientRect().left <= h)
                d < e.$(c[b]).outerHeight() && (d = e.$(c[b]).outerHeight());
              else break;
              b += 1;
            }
            d != f.outerHeight() &&
              e.animate(
                f,
                {height: d},
                a.getAttr(g.HEIGHT_ANIMATION_SPEED),
                "linear"
              );
          }
          a.setAttr("lastScrollPosition", f.scrollLeft());
          a.setAttr("lastIndexChecked", b);
          a.setAttr("maxHeight", d);
        }
      }
      var p = {},
        t = function (a) {
          this.carousel = a;
        };
      e.extend(t.prototype, {
        setAttr: function (a, b) {
          return this.carousel.setAttr(a, b);
        },
        getAttr: function (a) {
          return this.carousel.getAttr(a);
        },
        onChange: function (a, b) {
          this.carousel.onChange(a, b);
        },
        getItems: function () {
          return this.carousel.dom.$carousel.children("li");
        },
        getViewport: function () {
          return this.carousel.dom.$viewport;
        },
        countItems: function () {
          return this.getItems().length;
        },
        showItems: function () {
          return this.getItems()
            .css("visibility", "")
            .attr("aria-hidden", "false");
        },
        getEmptyCard: function (a, b) {
          return this.carousel.getEmptyCard(a, b);
        },
        getEmptyCards: function () {
          return this.carousel.dom.$carousel.children(".a-carousel-card-empty");
        },
        hasEmptyCard: function () {
          return 0 < this.getEmptyCards().length;
        },
        getFirstEmptyDetails: function () {
          var a = this.getEmptyCards();
          return 0 < a.length
            ? ((a = a.first()), {index: a.index(), left: a.position().left})
            : {index: -1, left: -1};
        },
        appendItems: function (a) {
          this.carousel.dom.$carousel.append(a.join(""));
        },
        hasItem: function (a, b) {
          return 0 < a.eq(b).length;
        },
        insertFetchedItem: function (a, b, c) {
          m.addElementToDom(b.eq(c), m.getElementFromItem(a));
          return m.clearElementFromItem(a);
        },
        attachScrollListener: function (a) {
          this.carousel.dom.$carousel.bind(
            e.action.move +
              ".a-carousel-freeScroll scroll.a-carousel-freeScroll",
            a
          );
          this.triggerEvent("scrollEventAttached");
        },
        detachScrollListener: function (a) {
          this.carousel.dom.$carousel.unbind(".a-carousel-freeScroll");
          this.triggerEvent("scrollEventDetached");
        },
        triggerEvent: function (a) {
          this.carousel.triggerEvent(a, this.carousel);
        },
        measureWidth: function () {
          return this.carousel.dom.$viewport.outerWidth();
        },
        wantNext: function (a, b) {
          this.carousel.strategies.ajax.want(this.carousel, a, b);
        },
        getDimensions: function () {
          return this.carousel.getDimensions();
        },
        throttle: function (a, b) {
          var c = this;
          clearTimeout(c[a]);
          c[a] = setTimeout(function () {
            b(c);
          }, 100);
        },
        shouldRepaint: function () {
          return this.carousel.strategies.display.repaint;
        },
        repaint: function () {
          this.carousel.strategies.display.repaint(this.carousel);
        },
      });
      var n = {
        ajaxLock: !0,
        lastIndexChecked: -1,
        lastScrollPosition: -1,
        currentScrollPosition: -1,
        maxHeight: 1,
      };
      n[g.NO_TRANSITION] = !0;
      n[g.HIDE_OFF_SCREEN] = !1;
      n[g.AUTO_ADJUST_HEIGHT] = !1;
      n[g.HEIGHT_ANIMATION_SPEED] = 200;
      return {
        gotoIndex: e.constants.NOOP,
        gotoNextpage: e.constants.NOOP,
        gotoPrevPage: e.constants.NOOP,
        gotoPage: e.constants.NOOP,
        initAttrs: n,
        init: function (a) {
          var l = d(a);
          l.showItems();
          k(l);
          f(l);
          c(l);
          l.onChange(g.FETCHED_ITEMS, function (a, c) {
            h(l, a, c);
            b(l);
          });
          e.on.resize(function () {
            b(l);
          });
        },
        afterInit: function (a) {
          var c = d(a);
          e.delay(function () {
            c.setAttr("ajaxLock", !1);
            b(c);
          });
        },
        prepareFetchedItems: k,
        addEmptyCards: f,
        handleItemChanges: h,
        detectEmptyCardsLoadingThreshold: b,
        ATTR: {
          NEXT_REQUEST_SIZE: g.NEXT_REQUEST_SIZE,
          LOADING_THRESHOLD_PIXELS: g.LOADING_THRESHOLD_PIXELS,
          CURRENT_SCROLL_POSITION: "currentScrollPosition",
        },
      };
    }
  );
  ("use strict");
  n.when(
    "A",
    "jQuery",
    "a-carousel-transition-slide",
    "a-carousel-transition-swap",
    "a-carousel-transition-freescroll",
    "a-carousel-transition-slidecircular",
    "a-carousel-constants"
  ).register(
    "a-carousel-strategies-transition",
    function (e, m, g, d, k, f, h) {
      m = {};
      m[h.NO_TRANSITION] = !0;
      m[h.HIDE_OFF_SCREEN] = !1;
      m[h.AUTO_ADJUST_HEIGHT] = !1;
      return {
        slideHorizontal: g,
        swap: d,
        freeScroll: k,
        slideCircular: f,
        none: {
          gotoIndex: e.constants.NOOP,
          gotoNextPage: e.constants.NOOP,
          gotoPrevPage: e.constants.NOOP,
          gotoPage: e.constants.NOOP,
          initAttrs: m,
          init: function (c) {
            c.dom.$carousel
              .children("li")
              .css("visibility", "")
              .attr("aria-hidden", "false");
          },
        },
        default: "slideHorizontal",
      };
    }
  );
  ("use strict");
  n.when("A").register("a-carousel-ajax-standard", function (e) {
    function m(f, g, c, b) {
      f.triggerEvent("beforeAjax", {url: g, params: c});
      e.get(g, {
        cache: !1,
        success: function (a) {
          a = d(a, g);
          if (null === a)
            n.error(
              "Invalid JSON returned to carousel from " +
                g +
                " - see http://tiny/c1mr5h0u for details.",
              "a-carousel-ajax-standard",
              "sendRequest"
            );
          else {
            c.needSetSize &&
              ((a && a.length) ||
                n.error(
                  "Carousel requires a set_size and none was returned by the fallback AJAX request at: " +
                    g,
                  "a-carousel-ajax-standard",
                  "sendRequest"
                ),
              f.setAttr("set_size", a[0].setSize ? a[0].setSize : a.length));
            for (
              var b = f.getAttr("fetchedItems"),
                h = f.getAttr("ajax"),
                k = [],
                l,
                m = a.length;
              m--;

            )
              (l = a[m]),
                null === l && k.push(m),
                l &&
                  (l.content || "" === l.content
                    ? (l.content = e.trim(l.content))
                    : (l = e.trim(l))),
                (b[c.offset + m] = l);
            h.remove_nulls &&
              h.id_list &&
              k.length &&
              (e.each(k, function (a) {
                h.id_list.splice(c.offset + a, 1);
              }),
              f.setAttr("ajax", h));
            c.needSetSize && f.init();
            f.setAttr("fetchedItems", b);
            f.setAttr("ajaxLock", !1);
            c.needSetSize &&
              f.getAttr("pageSize") >= b.length &&
              f.strategies.ajax.wantCurrentPage(f);
            f.triggerEvent("ajaxSuccess", {url: g, params: c});
          }
        },
        params: c,
        headers: b,
      });
    }
    function g(d) {
      var e = d.getAttr("requestTimer");
      e && (clearTimeout(e), d.setAttr("requestTimer", null));
    }
    function d(d, g) {
      return e.isArray(d)
        ? d
        : d !== k &&
          null !== d &&
          !e.objectIsEmpty(d) &&
          d.hasOwnProperty("data") &&
          e.isArray(d.data)
        ? d.data
        : null;
    }
    var k;
    return {
      getItems: function (d, g, c, b) {
        var a = d.getAttr("ajax");
        d.setAttr("requestTimer", e.delay(m, a.fetch_delay, d, g, c, b));
      },
      wantNextPage: function (d) {
        g(d);
        if (d.getAttr("ajax").prefetch_next_page) {
          var e = d.getAttr("pageSize"),
            c = 2 * e;
          d.getAttr("show_partial_next") && c++;
          this.want(d, (d.getAttr("pageNumber") - 1) * e, c);
        } else this.wantCurrentPage(d);
      },
      wantPrevPage: function (d) {
        g(d);
        if (d.getAttr("ajax").prefetch_next_page) {
          var e = d.getAttr("pageSize"),
            c = 2 * e;
          d.getAttr("show_partial_next") && c++;
          this.want(d, (d.getAttr("pageNumber") - 2) * e, c);
        } else this.wantCurrentPage(d);
      },
      wantCurrentPage: function (d) {
        g(d);
        var e = d.getAttr("pageSize"),
          c = d.getAttr("show_partial_next") ? e + 1 : e;
        this.want(d, (d.getAttr("pageNumber") - 1) * e, c);
      },
      want: function (d, e, c) {
        if (!d.getAttr("ajaxLock")) {
          g(d);
          var b = d.getAttr("ajax"),
            a = d.getAttr("set_size");
          if (b.url) {
            var f = d.getAttr("fetchedItems"),
              h = b.id_list;
            h || (h = []);
            var k = -1 < e ? e : 0;
            e = e + c - 1;
            var l = b.params || {},
              m = b.headers || {},
              n = [],
              q = [];
            0 === a &&
              (h.length && (a = h),
              (l.needSetSize = "true"),
              d.setAttr("ajaxLock", !0));
            for (-1 === c && a && (e = a); k <= e && k < a; )
              f[k] || ((c = h[k]) && n.push(c), q.push(k), (f[k] = !1)), k++;
            d.setAttr("fetchedItems", f, {silent: !0});
            l.count = q.length;
            l.offset = q[0] || 0;
            0 < n.length && (l[b.id_param_name] = n.join(","));
            (0 < q.length || l.needSetSize) && this.getItems(d, b.url, l, m);
          }
        }
      },
      init: function (d) {
        var f = d.getAttr("ajax");
        e.isFiniteNumber(f.fetch_delay) || (f.fetch_delay = 500);
        f.id_param_name = f.id_param_name || "ids";
        f.prefetch_next_page =
          f.prefetch_next_page === k ? !0 : !!f.prefetch_next_page;
        d.setAttr("ajax", f);
        d.getAttr("set_size") || this.want(d, 0, -1);
      },
      afterInit: function (d) {
        d.strategies.ajax.wantCurrentPage(d);
        d.onChange("pageNumber", function (e, c) {
          e > c
            ? d.strategies.ajax.wantNextPage(d)
            : d.strategies.ajax.wantPrevPage(d);
        });
        d.onChange("loading", function (e) {
          e || d.strategies.ajax.wantCurrentPage(d);
        });
      },
    };
  });
  ("use strict");
  n.when("a-util").register("a-carousel-ajax-promise", function (e) {
    function m(g, d) {
      var k = g.getAttr("requestTimer");
      k && clearTimeout(k);
      g.setAttr("requestTimer", e.delay(d, 500));
    }
    return {
      getItems: function (g, d, k) {
        m(g, function () {
          var f = g.getAttr("async_provider");
          f &&
            f(d, k).then(function (f) {
              var c = g.getAttr("fetchedItems");
              e.each(f, function (b, a) {
                c[d[a]] = b;
              });
              g.setAttr("fetchedItems", c);
            });
        });
      },
      wantNextPage: function (e) {
        var d = e.getAttr("pageSize"),
          g = (e.getAttr("pageNumber") - 1) * d;
        this.want(e, g, 2 * d);
      },
      wantPrevPage: function (e) {
        var d = e.getAttr("pageSize"),
          g = (e.getAttr("pageNumber") - 2) * d;
        this.want(e, g, 2 * d);
      },
      wantCurrentPage: function (e) {
        var d = e.getAttr("pageSize"),
          g = (e.getAttr("pageNumber") - 1) * d;
        this.want(e, g, d);
      },
      want: function (g, d, k) {
        d = Math.max(0, d);
        k = Math.min(d + k, g.getAttr("set_size"));
        for (var f = g.getAttr("fetchedItems"), h = []; d < k; d++)
          f[d] || (h.push(d), (f[d] = !1));
        if (h.length) {
          var c,
            b = g.getAttr("ajax").id_list;
          b &&
            (c = e.map(h, function (a) {
              return b[a];
            }));
          g.setAttr("fetchedItems", f, {silent: !0});
          this.getItems(g, h, c);
        }
      },
      init: function (e) {},
      afterInit: function (g) {
        g.strategies.ajax.wantCurrentPage(g);
        g.onChange(
          "async_provider",
          e.once(function () {
            g.strategies.ajax.wantCurrentPage(g);
          })
        );
        g.onChange("pageNumber", function (d, e) {
          d > e
            ? g.strategies.ajax.wantNextPage(g)
            : g.strategies.ajax.wantPrevPage(g);
        });
      },
    };
  });
  ("use strict");
  n.when("A", "a-carousel-ajax-standard", "a-carousel-ajax-promise").register(
    "a-carousel-strategies-ajax",
    function (e, m, g) {
      return {
        standard: m,
        promise: g,
        none: {
          wantNextPage: e.constants.NOOP,
          wantPrevPage: e.constants.NOOP,
          wantCurrentPage: e.constants.NOOP,
          want: e.constants.NOOP,
          init: e.constants.NOOP,
        },
        default: "standard",
      };
    }
  );
  ("use strict");
  n.when("A", "a-carousel-constants").register(
    "a-carousel-accessibility-standard-desktop",
    function (e, m) {
      function g(a) {
        var b = a.dom.$carousel,
          c = b.children("li"),
          d = a.getAttr(m.PAGE_SIZE),
          e = a.getAttr(m.FIRST_VISIBLE_ITEM),
          f = e - 1,
          g = a.getAttr(m.TRANSITION_SLIDE_CIRCULAR_FIRST_CARD_IDX);
        if (a.getAttr(m.NO_TRANSITION)) return c;
        if (c.length <= d)
          return b.children("li:not(:empty), li.a-carousel-card-empty");
        "slideCircular" === a.getAttr(m.TRANSITION_STRATEGY) &&
          ((f = g - e - 1), 0 === c.length % 2 && --f);
        b = f = (f + 2 * c.length) % c.length;
        "peekCircular" === a.getAttr(m.DISPLAY_STRATEGY) && --b;
        d = f + d;
        if (
          "peekCircular" === a.getAttr(m.DISPLAY_STRATEGY) ||
          a.getAttr(m.SHOW_PARTIAL_NEXT)
        )
          d += 1;
        return c.slice(Math.max(b, 0), Math.min(d, c.length));
      }
      function d(a, b, c, d) {
        var h = function () {
          var c = g(a);
          (b ? c.first() : c.last())
            .find(
              "a, button, input, select, textarea, [tabindex]:not([tabindex\x3d'-1'])"
            )
            .not(":disabled")
            .first()
            .focus();
          e.delay(function () {
            f(a);
          }, a.getAttr(m.PAGE_SIZE) * a.getAttr(m.DELAY_TIME) + 50);
        };
        if (0 === c || 0 === d) e.delay(h, 0);
        else {
          var k = function (b) {
            b || (h(), a.unbind(m.ANIMATING, k));
          };
          a.onChange(m.ANIMATING, k);
        }
      }
      function k(a) {
        var c = a.dom.$carousel.children("li"),
          d = a.getAttr(m.TRANSITION_STRATEGY),
          e = a.getAttr(m.SET_SIZE),
          f = e ? {"aria-setsize": e} : {};
        if ("swap" === d) {
          var g = a.getAttr(m.FIRST_VISIBLE_ITEM);
          c.each(function (a) {
            var c = b(this);
            g + a > e
              ? (c.removeAttr("aria-setsize"), c.removeAttr("aria-posinset"))
              : ((f["aria-posinset"] = g + a), c.attr(f));
          });
        } else
          c.each(function (a) {
            f["aria-posinset"] = a + 1;
            b(this).attr(f);
          });
      }
      function f(a) {
        a = a.dom.$container;
        a.find(".a-carousel-accessibility-page-info").html(
          a.find(".a-carousel-page-count").text()
        );
      }
      function h(a, b) {
        if (!a.getAttr(m.NO_TRANSITION)) {
          var c = a.dom.$carousel.children("li"),
            d = a.getAttr(m.TRANSITION_STRATEGY);
          a = a.getAttr(m.DISPLAY_STRATEGY);
          c = c.not(b);
          b.attr("aria-hidden", !1);
          c.attr("aria-hidden", !0);
          if (
            ("slideCircular" === d && "peekCircular" !== a) ||
            "slideHorizontal" === d
          )
            b.css("visibility", "visible"), c.css("visibility", "hidden");
        }
      }
      function c(a, b) {
        if (!a.getAttr(m.CIRCULAR)) {
          var c = a.dom.$container;
          c.find(".a-carousel-goto-prevpage").attr(
            "aria-disabled",
            1 === b ? "true" : "false"
          );
          c.find(".a-carousel-goto-nextpage").attr(
            "aria-disabled",
            b === a.getAttr(m.TOTAL_PAGES) ? "true" : "false"
          );
        }
      }
      var b = e.$;
      return {
        init: function (a) {
          var b = a.getAttr(m.NAME);
          k(a);
          h(a, g(a));
          c(a, 1);
          e.on("a:carousel" + (b ? ":" + b : "") + ":repaint", function () {
            h(a, g(a));
          });
          a.onChange(m.SET_SIZE, function (b, c) {
            k(a);
          });
          a.onChange(m.LOADING, function (b) {
            a.getAttr(m.ANIMATING) ||
              a.dom.$carousel.attr("aria-busy", (!!b).toString());
          });
          a.onChange(m.ANIMATING, function (b) {
            a.getAttr(m.LOADING) ||
              a.dom.$carousel.attr("aria-busy", (!!b).toString());
            !b &&
              a.getAttr(m.SET_SIZE) > a.getAttr(m.PAGE_SIZE) &&
              ((b = a.getAttr(m.TRANSITION_STRATEGY)),
              h(a, g(a)),
              "slide" !== b && k(a));
          });
          a.onChange(m.PAGE_NUMBER, function (b) {
            c(a, b);
            h(a, a.dom.$carousel.children("li"));
          });
        },
        afterInit: function (a) {
          f(a);
        },
        gotoPage: function (a, b, c) {
          a.getAttr(m.NO_TRANSITION) || d(a, !0, b, c);
        },
        nextPage: function (a, b, c) {
          a.getAttr(m.NO_TRANSITION) || d(a, !0, b, c);
        },
        prevPage: function (a, b, c) {
          a.getAttr(m.NO_TRANSITION) || d(a, !1, b, c);
        },
      };
    }
  );
  ("use strict");
  n.when("A", "a-carousel-constants").register(
    "a-carousel-accessibility-standard-mobile",
    function (e, m) {
      function g(e) {
        var f = e.dom.$carousel;
        e = f.children(".a-carousel-card-empty");
        f = f.children("li").not(e);
        var g = f.length,
          c = g ? {"aria-setsize": g} : {};
        e.attr("aria-hidden", "true")
          .removeAttr("aria-setsize")
          .removeAttr("aria-posinset");
        f.each(function (b) {
          c["aria-posinset"] = b + 1;
          c["aria-hidden"] = "false";
          d(this).attr(c);
        });
      }
      var d = e.$;
      e = e.constants.NOOP;
      return {
        init: function (d) {
          g(d);
          d.onChange(m.SET_SIZE, function () {
            g(d);
          });
          d.onChange(m.LOADING, function (e) {
            d.dom.$carousel.attr("aria-busy", (!!e).toString());
            e || g(d);
          });
        },
        gotoPage: e,
        nextPage: e,
        prevPage: e,
      };
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-carousel-accessibility-standard-desktop",
    "a-carousel-accessibility-standard-mobile"
  ).register("a-carousel-strategies-accessibility", function (e, m, g) {
    return {
      standardDesktop: m,
      standardMobile: g,
      none: {
        init: e.constants.NOOP,
        gotoPage: e.constants.NOOP,
        nextPage: e.constants.NOOP,
        prevPage: e.constants.NOOP,
      },
      default:
        e.capabilities.mobile || e.capabilities.tablet
          ? "standardMobile"
          : "standardDesktop",
    };
  });
  ("use strict");
  n.when(
    "a-carousel-strategies-display",
    "a-carousel-strategies-transition",
    "a-carousel-strategies-ajax",
    "a-carousel-strategies-accessibility"
  ).register("a-carousel-strategies", function (e, m, g, d) {
    return {display: e, transition: m, ajax: g, accessibility: d};
  });
  ("use strict");
  n.when(
    "A",
    "jQuery",
    "a-carousel-classes",
    "a-carousel-strategies",
    "a-carousel-constants"
  ).register("a-carousel-framework", function (e, m, g, d, k) {
    function f(a, b, c, d) {
      var f = a.hasClass("a-begin"),
        g = 0 < a.children(".a-end").length;
      if (f ? g : 1)
        return (
          (b = new b(a, c, d)),
          (b.__id = ++y),
          a.data("a-carousel", b),
          a.removeClass("a-carousel-static"),
          t(a, b) ? e.delay(h, 10, b) : q.push(b),
          d.name && (w[d.name] = b),
          b
        );
    }
    function h(a) {
      a.init();
      u.push(a);
      a.__initialized = !0;
      a.dom.$container.addClass("a-carousel-initialized");
      var b = a.getAttr("name");
      b &&
        A[b] &&
        e.each(A[b], function (b) {
          b(a);
        });
    }
    function c(a, b) {
      (b = b[a + "Strategy"]) || (b = d[a]["default"]);
      return d[a][b];
    }
    function b(a) {
      for (var b = a.length, c; b--; )
        (c = a[b]),
          (c.dom.$container.length && r.find(c.dom.$container).length) ||
            ((c = c.getAttr("name")) && delete w[c], a.splice(b, 1));
    }
    function a() {
      b(q);
      b(u);
    }
    function p(a) {
      var b = a.data("a-carousel-options") || {};
      b.displayStrategy = a.data("a-display-strategy");
      b.transitionStrategy = a.data("a-transition-strategy");
      b.ajaxStrategy = a.data("a-ajax-strategy");
      b.accessibilityStrategy = a.data("a-accessibility-strategy");
      b.carouselClass = a.data("a-class");
      a = c("display", b);
      var d = c("transition", b),
        e = c("ajax", b),
        f = c("accessibility", b),
        h = b.carouselClass;
      h || (h = g["default"]);
      h = g[h];
      if (h !== v && a !== v && d !== v && e !== v && f !== v)
        return {
          carouselClass: h,
          strategies: {display: a, transition: d, ajax: e, accessibility: f},
          opts: b,
        };
    }
    function t(a, b) {
      return a.hasClass("a-begin") && 0 === a.children(".a-end").length
        ? !1
        : e.onScreen(a, b.getAttr("initThreshold"));
    }
    function x() {
      m(".a-carousel-static").each(function () {
        var a = m(this),
          b = p(a);
        b && f(a, b.carouselClass, b.strategies, b.opts);
      });
    }
    function l() {
      for (var a = q.length; a--; ) {
        var b = q[a];
        t(b.dom.$container, b) && (q.splice(a, 1), h(b));
      }
    }
    var v,
      u = [],
      q = [],
      z = !1,
      w = {},
      r = m(document),
      A = {},
      y = 0;
    e.on("resize orientationchange", function (b, c) {
      a();
      (c.height || c.width) &&
        e.delay(
          function () {
            e.each(u, function (a) {
              a.resize();
            });
          },
          e.capabilities.mobile || e.capabilities.tablet ? 100 : 0
        );
    });
    e.on("a:popover:afterSlideOut", function () {
      e.each(u, function (a) {
        a.resize();
      });
    });
    e.on("a:carousel:change:name", function (a) {
      a.newValue && (w[a.newValue] = a.carousel);
      a.oldValue && delete w[a.oldValue];
    });
    e.on(k.INIT_EVENTS, function () {
      l();
      x();
    });
    e.on("a:pageUpdate", a);
    e.on("scroll", function () {
      l();
      x();
    });
    e.declarative("a-tabs", "click", function (a) {
      e.delay(function () {
        l();
        e.each(u, function (a) {
          a.getAttr("isInTab") && a.resize();
        });
      }, 50);
    });
    e.on("a:popover:afterShow", function () {
      e.delay(l, 50);
    });
    e.on("a:popover:ajaxContentLoaded", function () {
      e.delay(function () {
        a();
        x();
      }, 50);
    });
    e.on.ready(function () {
      z = !0;
    });
    k = {
      getCarousel: function (a) {
        a.jquery || (a = m(a));
        var b = a.closest(".a-carousel-container").data("a-carousel");
        if (!b) {
          var c = p(a);
          c && (b = f(a, c.carouselClass, c.strategies, c.opts));
        }
        return b;
      },
      getCarouselByName: function (a) {
        return w[a];
      },
      createAll: function () {
        a();
        x();
      },
      initializeAll: function () {
        a();
        l();
      },
      kill: function (a) {
        a.jquery || (a = m(a));
        if (a.length && ((a = a.closest(".a-carousel-container")), a.length)) {
          var b = a.data("a-carousel");
          if (b) {
            var c = e.indexOfArray(u, b);
            -1 < c
              ? (u[c].name && delete w[u[c].name], u.splice(c, 1))
              : ((c = e.indexOfArray(q, b)),
                -1 < c && (q[c].name && delete w[q[c].name], q.splice(c, 1)));
          }
          a.remove();
        }
      },
      registerStrategy: function (a, b, c) {
        d[a] || (d.type = {});
        d[a][b] &&
          n.error(
            "Attempted to register a " +
              a +
              " strategy which already exists: " +
              b,
            "a-carousel-framework",
            "registerStrategy"
          );
        d[a][b] = c;
        z && x();
      },
      registerCarouselClass: function (a, b) {
        g[a] &&
          n.error(
            "Attempted to register a carousel class which already exists: " + a,
            "a-carousel-framework",
            "registerCarouselClass"
          );
        m.isFunction(b) ||
          n.error(
            "Attempted to register carousel class " +
              a +
              " without a constructor function.",
            "a-carousel-framework",
            "registerCarouselClass"
          );
        g[a] = b;
        z && x();
      },
      getAllCarousels: function () {
        return u.concat(q);
      },
      onInit: function (a, b) {
        a &&
          (A[a] || (A[a] = []),
          m.isFunction(b) &&
            (A[a].push(b), (a = w[a]) && a.__initialized && b(a)));
      },
    };
    Object.freeze !== v && Object.freeze(k);
    return k;
  });
});
/* ******** */
(function (e) {
  var g = window.AmazonUIPageJS || window.P,
    k = g._namespace || g.attributeErrors,
    a = k ? k("AmazonUIComponents", "AmazonUI") : g;
  a.guardFatal
    ? a.guardFatal(e)(a, window)
    : a.execute(function () {
        e(a, window);
      });
})(function (e, g, k) {
  e.when("A", "a-form-controls-api").register(
    "a-form-controls-handlers",
    function (a, b) {
      var f = a.$,
        d = function () {
          f(this).removeClass("a-hover-disable");
        },
        h = function (c, d) {
          var h = b.findFormElementContainer(c);
          a.delay(function () {
            h.find(d).each(b.normalizeElement);
          }, 0);
        };
      return {
        handleBoxInputMobileFocus: function () {
          f(this).addClass("a-form-focus");
        },
        handleBoxInputMobileBlur: function () {
          f(this).removeClass("a-form-focus");
        },
        accessibilityKeyPress: function (c) {
          c.keyCode === a.constants.keycodes.SPACE &&
            (c.preventDefault(), c.stopPropagation());
        },
        formReset: h,
        handleCheckboxClick: function () {
          if (!a.capabilities.mobile && !a.capabilities.tablet)
            f(this).addClass("a-hover-disable").one("mouseleave", d);
        },
        normalizeFormControls: function () {
          f("form")
            .unbind("reset.a-form-controls-reset")
            .bind("reset.a-form-controls-reset", function (c) {
              h(c.currentTarget, "li .a-touch-multi-select");
            });
        },
        touchMultiSelectHandler: function (c) {
          b.toggleCheckboxState(c.currentTarget);
        },
      };
    }
  );
  ("use strict");
  e.when("A", "a-form-controls-handlers", "ready").register(
    "a-form-controls",
    function (a, b) {
      function f(a) {
        var c = d(this),
          b = c.siblings("a.a-placeholder");
        c = c.find(":selected").text();
        b.html(c);
        a && a.preventDefault && a.preventDefault();
      }
      var d = a.$;
      d(document)
        .delegate(
          ".a-select-multiple, .a-input-text, .a-input-text-wrapper",
          "focusin",
          b.handleBoxInputMobileFocus
        )
        .delegate(
          ".a-select-multiple, .a-input-text, .a-input-text-wrapper",
          "focusout",
          b.handleBoxInputMobileBlur
        )
        .delegate(
          ".a-touch-radio, .a-touch-checkbox",
          "keypress",
          b.accessibilityKeyPress
        )
        .delegate(
          {OPTION: "li .a-touch-multi-select"}.OPTION,
          "click",
          b.touchMultiSelectHandler
        )
        .delegate("select.a-touch-select-input", "change", f);
      a.on("a:pageUpdate beforeReady", function () {
        d("body").find("select.a-touch-select-input").each(f);
        b.normalizeFormControls();
      });
    }
  );
  ("use strict");
  e.when("A").register("a-buttons", function (a) {
    var b = a.$,
      f = 0;
    a.declarative("a-button-group", ["click"], function (d) {
      var b = d.$target,
        c = b.closest(".a-button:not(.a-button-disabled)");
      if (c.length) {
        var f = d.$declarativeParent.find(".a-button");
        d = d.data && d.data.name ? d.data.name : !1;
        b =
          b.closest("input[type\x3dsubmit], button").attr("name") ||
          b.find("input[type\x3dsubmit], button").attr("name");
        f.removeClass("a-button-selected").attr("aria-checked", "false");
        c.addClass("a-button-selected").attr("aria-checked", "true");
        if (b || d)
          (c = {$button: c, buttonName: b, buttonGroupName: d}),
            d &&
              (a.trigger("a:button-group:" + d + ":toggle", {
                selectedButton: c,
              }),
              b &&
                a.trigger("a:button-group:" + d + ":" + b + ":toggle", {
                  selectedButton: c,
                }));
      }
    });
    a.on("a:pageUpdate beforeReady", function () {
      var a = b(".a-button:not([id])"),
        e = b(".a-button-group,.a-button-toggle-group");
      a.each(function () {
        var c = b(this),
          a = c.find(".a-button-text"),
          d = c.find(".a-button-input").not("[aria-label]"),
          e = "a-autoid-" + f++;
        c.attr("id", e);
        a.length &&
          ((e = (c = a.attr("id")) ? c : e + "-announce"),
          d.length && d.attr("aria-labelledby", e),
          a.attr("id", e));
      });
      e.each(function () {
        var a = b(this).find(".a-button[role\x3d'radio']"),
          d = a.length,
          e = 1;
        a.each(function () {
          b(this).attr({"aria-posinset": e++, "aria-setsize": d});
        });
      });
    });
    b(document)
      .delegate(".a-button-input, .a-button-text", "focusin", function () {
        var a = b(this).closest(".a-button");
        a.hasClass("a-button-disabled") || a.addClass("a-button-focus");
      })
      .delegate(
        ".a-button-input, .a-button-text",
        "focusout " + a.action.cancel,
        function () {
          b(this).closest(".a-button").removeClass("a-button-focus");
        }
      );
  });
});
/* ******** */
(function (d) {
  var f = window.AmazonUIPageJS || window.P,
    h = f._namespace || f.attributeErrors,
    c = h ? h("AmazonUITabs", "AmazonUI") : f;
  c.guardFatal
    ? c.guardFatal(d)(c, window)
    : c.execute(function () {
        d(c, window);
      });
})(function (d, f, h) {
  d.when("A").register("a-tabs", function (c) {
    function d(a) {
      var b = a.$target.closest("li"),
        k = a.data.name,
        d = b.data("a-tab-name"),
        e = b.closest(".a-tab-container"),
        f = e.find(".a-box-tab").not(e.find(".a-box-tab .a-box-tab"));
      d !== h &&
        (g(e.find("li.a-active"), b.closest(".a-tabs"))
          .removeClass("a-active")
          .find("a")
          .attr({"aria-selected": !1, tabindex: -1}),
        b
          .addClass("a-active")
          .find("a")
          .attr("aria-selected", !0)
          .removeAttr("tabindex"),
        g.each(f, function (b, a) {
          g(a).toggleClass("a-hidden", g(a).data("a-name") !== d);
        }),
        (b = {$tab: b, tabName: d, tabSetName: k}),
        c.trigger("a:tabs:" + k + ":select", {selectedTab: b}),
        c.trigger("a:tabs:" + k + ":" + d + ":select", {selectedTab: b}),
        a.$event.preventDefault());
    }
    var g = c.$,
      e = c.constants.keycodes;
    c.declarative("a-tabs", ["click"], d);
    c.on("beforeReady a:pageUpdate a:ajax:complete", function () {
      var a = g(document).find(".a-tab-container"),
        b = a.find(".a-tabs"),
        c = b.not('[role\x3d"tablist"]');
      a = a.find(".a-box-tab").not(a.find(".a-box-tab .a-box-tab"));
      var d = b.find(".a-tab-heading.a-active a"),
        e = b.find(".a-tab-heading:not('.a-active') a");
      c.length &&
        (b.find(".a-tab-heading").attr("role", "presentation"),
        c.attr("role", "tablist"),
        d.add(e).attr("role", "tab"),
        a.attr({role: "tabpanel", tabindex: "0"}),
        d.attr("aria-selected", !0),
        e.attr({"aria-selected": !1, tabindex: -1}));
    });
    c.declarative("a-tabs", ["keydown"], function (a) {
      var b = a.$target.closest(".a-tab-container").find(".a-tab-heading");
      switch (a.$event.which) {
        case e.SPACE:
          d(a);
          break;
        case e.END:
          a.$event.preventDefault();
          b.last().find("a").focus();
          break;
        case e.HOME:
          a.$event.preventDefault();
          b.first().find("a").focus();
          break;
        case e.LEFT_ARROW:
        case e.RIGHT_ARROW:
          b = a.$target.closest(".a-tab-heading");
          var c = b.closest(".a-tab-container").find(".a-tab-heading");
          a.$event.which === e.RIGHT_ARROW &&
            b.next(".a-tab-heading").add(c.first()).last().find("a").focus();
          a.$event.which === e.LEFT_ARROW &&
            b.prev(".a-tab-heading").add(c.last()).first().find("a").focus();
      }
    });
  });
});
/* ******** */
(function (d) {
  var f = window.AmazonUIPageJS || window.P,
    k = f._namespace || f.attributeErrors,
    a = k ? k("AmazonUIAccordion@jsAssets", "AmazonUI") : f;
  a.guardFatal
    ? a.guardFatal(d)(a, window)
    : a.execute(function () {
        d(a, window);
      });
})(function (d, f, k) {
  d.when("A").register("a-accordion-a11y", function (a) {
    var d = a.$,
      b;
    return {
      refreshFocus: function (e, g) {
        g = g || 600;
        b ||
          (b = d("\x3cb /\x3e", {
            class: "a-accordion-a11y",
            tabIndex: -1,
            style: "position: absolute",
          }).appendTo("body"));
        b.css({display: "block"}).offset(e.offset());
        a.delay(function () {
          b.focus();
        }, 50);
        a.delay(function () {
          e.focus();
          b.css({display: "none"});
        }, g);
      },
    };
  });
  d.when("A", "a-accordion-a11y", "prv:a-capabilities").register(
    "a-accordion",
    function (a, d, b) {
      function e(b) {
        var h = b.$target.closest(".a-accordion"),
          c = b.$target.closest(".a-box"),
          e = h.find(".a-box").not(c),
          l = c.find(".a-accordion-row"),
          n = h.data("a-accordion-name"),
          p = c.data("a-accordion-row-name"),
          u = h.hasClass("a-accordion-collapse"),
          v = c.find("a.a-accordion-row"),
          q = b.$target.closest(".a-accordion-row-a11y");
        h = h.find(".a-accordion-row-a11y").not(q);
        if (p) {
          var t = c.find(".a-accordion-inner"),
            r = !0;
          if (c.hasClass("a-accordion-active"))
            if (u)
              t[f]({
                duration: m,
                complete: function () {
                  c.removeClass("a-accordion-active");
                  c.find(".a-icon.a-accordion-radio")
                    .removeClass("a-icon-radio-active")
                    .addClass("a-icon-radio-inactive");
                  q.attr("aria-checked", "false").attr(
                    "aria-expanded",
                    "false"
                  );
                },
              });
            else r = !1;
          else
            e.find(".a-accordion-inner")[f]({
              duration: m,
              complete: function () {
                e.removeClass("a-accordion-active");
              },
            }),
              t[g]({
                duration: m,
                complete: function () {
                  c.addClass("a-accordion-active");
                  e.find(".a-icon.a-accordion-radio")
                    .removeClass("a-icon-radio-active")
                    .addClass("a-icon-radio-inactive");
                  c.find(".a-icon.a-accordion-radio")
                    .removeClass("a-icon-radio-inactive")
                    .addClass("a-icon-radio-active");
                },
              }),
              h.attr("aria-checked", "false").attr("aria-expanded", "false"),
              q.attr("aria-checked", "true").attr("aria-expanded", "true");
          r && k && d.refreshFocus(l);
          r &&
            ((l = {$row: c, rowName: p, accordionName: n}),
            a.trigger("a:accordion:select", {selectedRow: l}),
            a.trigger("a:accordion:" + n + ":select", {selectedRow: l}),
            a.trigger("a:accordion:" + n + ":" + p + ":select", {
              selectedRow: l,
            }));
        }
        v.length && b.$event.preventDefault();
      }
      var g = "slideDown",
        f = "slideUp",
        m = 300;
      if (a.capabilities.mobile || a.capabilities.tablet)
        (g = "show"), (f = "hide"), (m = 0);
      var k = !a.capabilities.touch && b.isFirefox;
      a.declarative("a-accordion", ["click"], e);
      a.declarative("a-accordion", ["keypress"], function (b) {
        var d = a.constants.keycodes,
          c = b.$event.which;
        (c !== d.ENTER && c !== d.SPACE) || e(b);
      });
    }
  );
});
/* ******** */
(function (c) {
  var e = window.AmazonUIPageJS || window.P,
    m = e._namespace || e.attributeErrors,
    a = m ? m("AmazonUIExpander", "AmazonUI") : e;
  a.guardFatal
    ? a.guardFatal(c)(a, window)
    : a.execute(function () {
        c(a, window);
      });
})(function (c, e, m) {
  c.declare("prv:a-expander-constants", {
    classNames: {
      inline: {expand: "a-icon-expand", collapse: "a-icon-collapse"},
      section: {
        expand: "a-icon-section-expand",
        collapse: "a-icon-section-collapse",
      },
      extender: {
        expand: "a-icon-extender-expand",
        collapse: "a-icon-extender-collapse",
      },
    },
    elementClasses: {
      container: "a-expander-container",
      content: "a-expander-content",
      header: "a-expander-header",
      fadeDiv: "a-expander-content-fade",
    },
  });
  c.when("A", "jQuery", "prv:a-expander-constants").register(
    "a-partial-expander",
    function (a, c, e) {
      function l() {
        c(".a-expander-partial-collapse-container").each(function () {
          var d = c(this),
            a = d.children("." + p.content),
            f = d.data("a-expander-collapsed-height"),
            b = d.children("." + p.header);
          a.height() <= f
            ? b.css({opacity: "0", display: "none"})
            : (b.css({opacity: "1", display: "block"}),
              a.css("padding-bottom", b.height()),
              "true" !== a.attr("aria-expanded") && d.css({height: f}),
              d.css({"max-height": "none"}));
        });
      }
      var p = e.elementClasses;
      a.on(
        "load ready resize orientationchange a:popover:afterShow a:popover:ajaxContentLoaded",
        l
      );
      return l;
    }
  );
  ("use strict");
  c.when(
    "A",
    "jQuery",
    "prv:a-expander-constants",
    "a-partial-expander"
  ).register("a-expander", function (a, c, e, l) {
    function p(b, a, f) {
      var c = b.closest("." + d.container),
        e = c.data("a-expander-collapsed-height"),
        q = "true" === b.attr("aria-expanded"),
        g = function () {
          b.toggleClass(d.content + "-expanded");
          b.attr("aria-expanded", q ? "false" : "true");
          a.attr("aria-expanded", q ? "false" : "true");
          f();
        };
      e
        ? (c.css("height", q ? e : "auto"), g())
        : b.toggle(0, function () {
            g();
          });
    }
    var d = e.elementClasses,
      g = e.classNames,
      f = {};
    a.each(g, function (b, d) {
      f[d] = {};
      a.each(b, function (a, b) {
        f[d][b] = new RegExp("\\b" + a + "\\b", "g");
      });
    });
    a.declarative("a-expander-toggle", "click", function (b) {
      var c = b.$target.closest("." + d.container),
        e = c.find("." + d.container),
        l = c.data("a-expander-name");
      var n = b.$currentTarget.hasClass(d.header)
        ? b.$currentTarget
        : c.find("." + d.header).not(e.find("." + d.header));
      var m = n.is("a[aria-expanded]") ? n : n.children("a[aria-expanded]"),
        r = c.find("." + d.content).not(e.find("." + d.content));
      p(r, m, function () {
        var h = n.find(".a-icon")[0],
          k = null,
          m = n.children("." + d.fadeDiv);
        "false" === r.attr("aria-expanded")
          ? (h &&
              (h.className = h.className
                .replace(f.inline.collapse, g.inline.expand)
                .replace(f.section.collapse, g.section.expand)
                .replace(f.extender.collapse, g.extender.expand)),
            b.data && b.data.expand_prompt && (k = b.data.expand_prompt),
            m.show(),
            (h = "collapse"))
          : (h &&
              (h.className = h.className
                .replace(f.inline.expand, g.inline.collapse)
                .replace(f.section.expand, g.section.collapse)
                .replace(f.extender.expand, g.extender.collapse)),
            b.data && b.data.collapse_prompt && (k = b.data.collapse_prompt),
            m.hide(),
            (h = "expand"));
        k &&
          "" !== k &&
          n
            .find(".a-expander-prompt")
            .not(e.find(".a-expander-prompt"))
            .html(k);
        k = {expander: {$expander: c, expanderName: l}};
        a.trigger("a:expander:toggle", k);
        a.trigger("a:expander:toggle:" + h, k);
        l &&
          (a.trigger("a:expander:" + l + ":toggle", k),
          a.trigger("a:expander:" + l + ":toggle:" + h, k));
      });
    });
    return {initializeExpanders: l};
  });
});
/* ******** */
(function (e) {
  var p = window.AmazonUIPageJS || window.P,
    l = p._namespace || p.attributeErrors,
    d = l ? l("AmazonUISwitch", "AmazonUI") : p;
  d.guardFatal
    ? d.guardFatal(e)(d, window)
    : d.execute(function () {
        e(d, window);
      });
})(function (e, p, l) {
  e.when("a-switch-framework", "jQuery").register("a-switch", function (d, h) {
    var g = d.SWITCH_STATE,
      e = d.SWITCH_CONTAINER_CLASS,
      w = d.SWITCH_CLASS;
    return {
      getSwitch: function (c) {
        function m(c) {
          var n = k.data(g);
          if (c === l) return n.isOn;
          if (!n.isEnabled || f(k)) return !1;
          d.setOnState(k, c);
          return !0;
        }
        function f() {
          return k.data(g).isDragging;
        }
        c.jquery || (c = h(c));
        if (0 === c.length) return null;
        c = c.eq(0);
        c = c.closest("." + e);
        if (0 === c.length) return null;
        var k = c.find("." + w);
        d.ensureInitialized(k);
        return {
          toggle: function () {
            return m(!k.data(g).isOn);
          },
          isOn: m,
          enabled: function (c) {
            var n = k.data(g);
            if (c === l) return n.isEnabled;
            if (n.isEnabled === c) return !1;
            d.setEnabled(k, c);
            return !0;
          },
          isDragging: f,
          label: function (d) {
            var c = k.data(g).label,
              e = c[0].childNodes[0];
            if (d === l) return c.text();
            3 === e.nodeType && (e.textContent = d);
          },
        };
      },
    };
  });
  ("use strict");
  e.when("A", "jQuery").register("a-switch-framework", function (d, h) {
    function g(a) {
      a.preventDefault();
      var b = a.data.$switch.data("a-switch-state"),
        c = b.control;
      if (!d.isAnimated(c)) {
        a = q(a) - b.initialX;
        b.isOn && (a += b.rightBoundary);
        var e = b.leftBoundary,
          v = b.rightBoundary;
        a = a < e ? e : a > v ? v : a;
        a !== b.leftOffset &&
          (d.animate(c, {left: a}, 0),
          (b.leftOffset = a),
          (b.isDragging = !0),
          b.dragCount++);
      }
    }
    function f(a) {
      a.preventDefault();
      if (d.capabilities.touch || 1 === a.which) {
        a = a.data.$switch;
        var b = a.data("a-switch-state");
        m(
          a,
          b.isDragging && 1 < b.dragCount ? b.leftOffset > b.midPoint : !b.isOn
        );
        b.isDragging = !1;
        t(a);
      }
    }
    function l(a, b, c) {
      c = {switchState: a, previousState: c};
      d.trigger("a:switch:" + b, c);
      a.name && d.trigger("a:switch:" + a.name + ":" + b, c);
    }
    function c(a) {
      if (!a.data("a-switch-state")) {
        var b = a.closest(".a-switch-row"),
          c = a.children(".a-switch-control"),
          d = b.find(".a-switch-label"),
          e = d.siblings("input"),
          k = e.attr("name"),
          l = b.hasClass("a-active"),
          g = !b.hasClass("a-disabled"),
          h = r.left,
          f = (a.width() - c.width() + r.right) * z;
        a.data("a-switch-state", {
          input: e,
          container: b,
          control: c,
          label: d,
          isDragging: !1,
          rightBoundary: f,
          leftBoundary: h,
          midPoint: f / 2,
          initialX: null,
          leftOffset: l ? f : h,
          maxLeftOffset: r.maxLeftOffset,
          isOn: l,
          isEnabled: g,
          name: k,
          dragCount: 0,
          clicked: !1,
        });
      }
    }
    function m(a, b) {
      c(a);
      a = a.data("a-switch-state");
      var e = a.isOn,
        k = b !== a.isOn;
      a.isOn = b;
      var f = a.control,
        h = a.maxLeftOffset,
        g = a.isOn ? a.rightBoundary : a.leftBoundary;
      g = h && g > h ? h : g;
      d.animate(f, {left: g}, 300, "ease-out");
      a.leftOffset = g;
      f = a.container;
      a.isOn ? f.addClass("a-active") : f.removeClass("a-active");
      f = a.input;
      a.isOn ? f.attr("checked", "checked") : f.removeAttr("checked");
      k && l(a, "flip", e);
      b ? l(a, "on", e) : l(a, "off", e);
    }
    var p = function (a) {
        a.bind("touchmove.a-switch-component", {$switch: a}, g);
        a.bind("touchend.a-switch-component", {$switch: a}, f);
        a.bind("touchcancel.a-switch-component", {$switch: a}, f);
        a.bind("mouseup.a-switch-component", {$switch: a}, f);
      },
      k = function (a) {
        a.unbind("touchmove.a-switch-component");
        a.unbind("touchend.a-switch-component");
        a.unbind("touchcancel.a-switch-component");
        a.unbind("mouseup.a-switch-component");
      },
      x = function (a) {
        return (a.originalEvent.touches[0] || a.originalEvent.changedTouches[0])
          .pageX;
      },
      n = function (a) {
        h("body").bind("mousemove.a-switch-component", {$switch: a}, g);
        h("body").bind("mouseup.a-switch-component", {$switch: a}, f);
      },
      y = function (a) {
        h("body").unbind("mousemove.a-switch-component", g);
        h("body").unbind("mouseup.a-switch-component", f);
      },
      A = function (a) {
        return a.pageX;
      },
      r = {left: d.capabilities.rtl ? 1 : -1, right: -1},
      z = d.capabilities.rtl ? -1 : 1;
    e.when("prv:skin-vars").execute(function (a) {
      r = a.toggle.bounds;
    });
    var u = null,
      t = null,
      q = null;
    d.capabilities.touch
      ? ((u = p), (t = k), (q = x))
      : ((u = n), (t = y), (q = A));
    d.declarative(
      "a-switch",
      d.capabilities.touch ? "touchstart" : "mousedown",
      function (a) {
        var b = a.$event;
        b.preventDefault();
        if (d.capabilities.touch || 1 === b.which) {
          a = a.$declarativeParent;
          c(a);
          var e = a.data("a-switch-state");
          e.dragCount = 0;
          e.clicked = !0;
          e.isDragging = !1;
          e.isEnabled && ((e.initialX = q(b)), u(a));
        }
      }
    );
    d.declarative("a-switch-input", "change", function (a) {
      a.$event.preventDefault();
      a = a.$target.closest(".a-switch-row").find(".a-switch");
      c(a);
      var b = a.data("a-switch-state");
      m(a, !b.isOn);
    });
    d.declarative("a-switch-label", "click", function (a) {
      a.$event.preventDefault();
      a = a.$target.closest(".a-switch-row").find(".a-switch");
      c(a);
      var b = a.data("a-switch-state");
      b.clicked ? (b.clicked = !1) : b.isEnabled && m(a, !b.isOn);
    });
    e.when("ready").execute("a-switch-normalization", function () {
      h(".a-switch-input").each(function () {
        var a = h(this),
          b = a.next().children(".a-switch");
        m(b, a.prop("checked"));
      });
    });
    return {
      ensureInitialized: c,
      setOnState: m,
      setEnabled: function (a, b) {
        c(a);
        a = a.data("a-switch-state");
        var d = a.container;
        b ? d.removeClass("a-disabled") : d.addClass("a-disabled");
        a.isEnabled = b;
      },
      SWITCH_STATE: "a-switch-state",
      SWITCH_CONTAINER_CLASS: "a-switch-row",
      SWITCH_CLASS: "a-switch",
    };
  });
});
/* ******** */
(function (a) {
  var f = window.AmazonUIPageJS || window.P,
    l = f._namespace || f.attributeErrors,
    b = l ? l("AmazonUIProgressBar", "AmazonUI") : f;
  b.guardFatal
    ? b.guardFatal(a)(b, window)
    : b.execute(function () {
        a(b, window);
      });
})(function (a, f, l) {
  a.when("A", "ready").register("a-progress", function (b) {
    function a(a) {
      (a ? e(a) : e(".a-js-progress-bar")).each(function () {
        var a = e(this);
        if (b.onScreen(a, 0)) {
          var g = +a.attr("data-progress-percentage");
          var h = -(g - 100);
          var c = a.width();
          var f = (h / 100) * c;
          var d = a.find(".a-js-progress-tooltip"),
            k = d.width();
          d.find(".a-js-tooltip-arrow");
          g = ((g + h / 2) / 100) * c - k / 2;
          h = k + g;
          (k = h < c) || (g -= h - c);
          c = g;
          e(d).css("left", c + 0);
          c = d.width();
          d = d.find(".a-js-tooltip-arrow");
          d.removeClass("aok-hidden");
          k ? ((c /= 2), e(d).css("left", c + -9)) : e(d).css("left", c + -27);
          12 > f && d.addClass("aok-hidden");
          e(a.find(".a-js-progress-tooltip"))
            .removeClass("a-progress-tooltip-hidden")
            .addClass("a-progress-tooltip-revealed");
        }
      });
    }
    var e = b.$;
    a();
    b.on("resize scroll", function (b) {
      a();
    });
    return {init: a};
  });
});
/* ******** */
(function (n) {
  var u = window.AmazonUIPageJS || window.P,
    B = u._namespace || u.attributeErrors,
    a = B ? B("AmazonUIPopover@base", "AmazonUI") : u;
  a.guardFatal
    ? a.guardFatal(n)(a, window)
    : a.execute(function () {
        n(a, window);
      });
})(function (n, u, B) {
  n.when("A", "a-popover-base-factory").register(
    "a-popover-base-apis",
    function (a, f) {
      return {
        show: function (a) {
          var d = f.get(a.$trigger ? a.$trigger : a);
          if (d) return d.show.apply(d, arguments);
        },
        hide: function (a) {
          var d = f.get(a);
          if (d) return d.unlock(1), d.hide.apply(d, arguments);
        },
        get: function (a) {
          return f.get(a);
        },
        remove: function (a) {
          return f.remove(a);
        },
      };
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-popover-util",
    "a-popover-objectclass",
    "a-popover-data"
  ).register("a-popover-base-factory", function (a, f, h, d) {
    function l(b) {
      return c[b] ? c[b] : null;
    }
    function m(b, c) {
      return new h.PopoverClass(b, c);
    }
    function k(c, e) {
      var a = null;
      if ("number" === typeof c) a = l(c);
      else if ("string" === typeof c) (a = b[c] ? b[c] : null) || (a = l(c));
      else if ("object" === typeof c)
        if (c.$popover) a = c;
        else if (
          ((c = g(c)),
          (a = c.data("a-popover-id")),
          a ||
            ((a = c.find(".a-declarative").eq(0)),
            (a = a.length ? a.data("a-popover-id") : null)),
          (a = l(a)),
          !a)
        ) {
          var k = c.data("action");
          (k = k ? c.data(k) : null) &&
            k.name &&
            ((a = k.name),
            (a = b[a] ? b[a] : null),
            !a || (e && a.type !== e)
              ? (a = null)
              : (e = (e = a.attrs("currentDataStrategy"))
                  ? d.getStrategyByName(e)
                  : d.guessStrategyByAttrs(a.attrs())) && e.reusePopover
              ? a.$trigger[0] !== c[0] &&
                (a.$trigger.data("a-popover-id", null), (a.$trigger = c))
              : (a = null));
        }
      return a;
    }
    function p() {
      r ||
        (r = m(
          {id: -1, $popover: q, $trigger: q, immersive: !0},
          {
            isActive: function () {
              return !0;
            },
            hideMethod: function () {
              this.hideChildren();
            },
            showMethod: a.constants.NOOP,
          }
        ));
      return r;
    }
    var g = a.$,
      e = 1,
      b = {},
      c = {},
      q = g(
        "\x3cdiv id\x3d'a-popover-root' style\x3d'z-index:-1;position:absolute;' /\x3e"
      ).appendTo("body"),
      r;
    return {
      getRoot: p,
      get: function (c, b) {
        b = b ? b : this ? this.type : null;
        return (c = k(c, b)) && b && c.type !== b ? null : c;
      },
      create: function (d, q) {
        var h = g(d),
          f = q.attributes || {},
          r = q.typeSpecificFunctions || q.variant || {};
        q = q.actionCheck || !1;
        h.data("a-popover-id");
        var t = f.type,
          v = null;
        !t ||
          (h.hasClass("a-declarative") &&
            h.data("action") &&
            -1 !== h.data("action").indexOf(t)) ||
          ((h = a.declarative.create(h, "a-" + t)), (d = h[0]));
        if (q && h.data("action") && -1 === h.data("action").indexOf(t))
          return null;
        t && h && (v = k(h));
        if (v) return v.type !== t ? null : v;
        h = f;
        d = g(d);
        h.type
          ? d && d.length
            ? ((h = a.extend({id: e++, $trigger: d, $triggerWrapper: null}, h)),
              (r = a.copy(r)),
              (r = m(h, r)),
              (c[r.id] = r),
              r.name && (b[r.name] = r),
              d.data("a-popover-id", r.id),
              (d = r.$trigger.closest(".a-popover")),
              (d =
                !r.attrs("immersive") && d.length
                  ? l(d.data("a-popover-id")) || p()
                  : p()),
              (r.parent = d),
              d.children.push(r))
            : (r = null)
          : (r = null);
        return r;
      },
      remove: function (e, g) {
        e = this.get(e);
        var k = !1;
        if (e) {
          k = e.id;
          if (e && -1 < k) {
            var d = a.indexOfArray(e.parent.children, e),
              q = e.$container,
              h = e.$trigger;
            e.parent.children.splice(d, 1);
            e.unlock().hide();
            e.update({content: ""});
            q && e.$container.remove();
            h.data("a-popover-id", "");
            e.name && delete b[e.name];
            delete c[k];
            k = !0;
          } else k = !1;
          g && a.declarative.remove(e.$trigger[0], "a-" + g);
        }
        return k;
      },
    };
  });
  ("use strict");
  n.when(
    "A",
    "a-popover-util",
    "a-popover-base-factory",
    "prv:a-capabilities"
  ).register("a-popover-base-handlers", function (a, f, h, d) {
    function l(a) {
      for (var e; a.length && !(e = a.data("a-popover-id")); ) a = a.parent();
      return h.get(e);
    }
    var m = a.$;
    m(document).bind("click " + a.action.start, function (g) {
      var e = m(g.target),
        b = g.originalEvent;
      if (
        !(
          (b &&
            b.pointerType &&
            b.pointerType === a.pointerType.touch &&
            "click" === b.type) ||
          e.hasClass("a-modal-scroller") ||
          "a-popover-lgtbox" === e[0].id ||
          "html" === e[0].nodeName.toLowerCase()
        )
      ) {
        var c = function (c) {
          return f.eventOccursWithin(g, c);
        };
        a.each(h.getRoot().children, function (b) {
          if (b.isVisible() || b.isContentLoaded()) {
            var a = f.search(b, c);
            a
              ? a.hideChildren()
              : null !== b.attrs("lightboxOptions") ||
                b.attrs("immersive") ||
                b.unlock(1).hide();
          }
        });
      }
    });
    a.declarative("a-popover-close", ["click", a.action.end], function (a) {
      var e = l(a.$target);
      e && (e.unlock().hide(), f.trigger("dismiss", e));
      a.$event.preventDefault();
    });
    var k = null,
      p = null;
    a.declarative("a-popover-a11y", "focusout", function (g) {
      var e = l(g.$target);
      e &&
        g.$target.length &&
        e.$firstTabbable.length &&
        g.$target[0] === e.$firstTabbable[0] &&
        !(k && 100 > a.now() - k) &&
        ((k = a.now()),
        a.delay(function () {
          m(document.activeElement).hasClass("a-popover-start") &&
            e.$lastTabbable.focus();
        }, 0));
    });
    a.declarative("a-popover-a11y", "focusin", function (g) {
      var e = l(g.$target);
      e &&
        g.$target.length &&
        g.$target.hasClass("a-popover-end") &&
        !(p && 100 > a.now() - p) &&
        ((p = a.now()),
        a.delay(function () {
          e.$firstTabbable.focus();
        }, 0));
    });
    a.declarative("a-popover-a11y", "keydown", function (g) {
      var e = g.$event;
      e.keyCode === a.constants.keycodes.ESCAPE &&
        ((g = l(g.$target)), e.preventDefault(), g && g.hide());
    });
    a.on("resize zoom", function () {
      h.getRoot().updatePosition();
    });
    if (d.isSafari && a.capabilities.ios)
      a.on("a:popover:refresh", function (g) {
        g = g.popover;
        g.$popover &&
          g.$popover
            .undelegate('input[type\x3d"date"]', "blur")
            .delegate('input[type\x3d"date"]', "blur", function () {
              var e = a.$(u);
              e.scrollTop(e.scrollTop() + 1);
            });
      });
  });
  ("use strict");
  n.when("A", "a-popover-base-apis", "a-popover-base-handlers").register(
    "a-popover-base",
    function (a, f, h) {
      return f;
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-popover-util",
    "a-popover-data",
    "a-popover-position",
    "a-popover-lightbox",
    "a-popover-animate",
    "prv:a-capabilities"
  ).register("a-popover-objectclass", function (a, f, h, d, l, m, k) {
    function p(k, d) {
      var h = -1,
        r = [1],
        p = -2;
      this.parent = null;
      this.children = [];
      this.typeSpecificFunctions = {};
      this.attributes = {
        position: "triggerVertical",
        alone: !1,
        immersive: !1,
        restoreFocusOnHide: !0,
      };
      var t = function () {
          this.isActive()
            ? this._willTriggerEvents && f.trigger("visible", this)
            : f.trigger("invisible", this);
          return this;
        },
        z = function (b, k) {
          var d = this.isActive(),
            h = this.getDataStrategy(),
            m = !this.$popover,
            f = k || m;
          k = !1;
          b = b || f;
          if (!f) for (var p = r.length; p-- && !f; ) f = !c[r[p]];
          f &&
            ((f = x.apply(this)),
            (f = e(f)),
            m || (h.unloadContent(this), this.$container.remove(), (k = !0)),
            e("body").append(f),
            (this.$container = f),
            (this.$popover = this.$container.hasClass("a-popover")
              ? this.$container
              : this.$container.find(".a-popover")),
            (this.$startAnchor = this.$popover.hasClass("a-popover-start")
              ? this.$popover
              : this.$popover.find(".a-popover-start")),
            (this.$endAnchor = this.$popover.find(".a-popover-end")),
            this.$popover
              .attr("id", "a-popover-" + this.id)
              .data("a-popover-id", this.id));
          this.attrs("immersive") ||
            ((f = parseInt(this.parent.$popover.css("z-index"), 10)),
            a.isFiniteNumber(f) ||
              (f = this.parent.attrs("immersive") ? 1010 : 0),
            "dropdown" === this.type && q && (f = Math.max(599, f)),
            (f = Math.max(299, 100 + f)),
            this.$popover.css("z-index", f));
          if (h.shouldRefreshContent(this) || b)
            k || h.unloadContent(this), h.loadContent(this, m);
          this.typeSpecificFunctions.updateDimensions !== g &&
            this.typeSpecificFunctions.updateDimensions.apply(this);
          r = [];
          d && C.call(this, [], !1);
          b = this.$popover
            .find(".a-popover-inner")
            .find(
              "a, button, input, select, textarea, [tabindex]:not([tabindex\x3d'-1'])"
            );
          b = b.not(".a-dropdown-link");
          this.$firstTabbable = this.$popover.find(
            '[data-action\x3d"a-popover-close"]'
          );
          this.$firstTabbable = this.$firstTabbable.length
            ? this.$firstTabbable
            : b.first();
          this.$lastTabbable = 0 === b.length ? this.$firstTabbable : b.last();
          return this;
        },
        C = function (c, e) {
          function k() {
            d.updatePosition();
            var a = d.attrs("navigate");
            !e && a && d.attrs("navigate", !1);
            q.call(d, t, c);
            e && f.trigger("show", d);
            r && r.apply(d, c);
            e && f.trigger("afterShow", d);
            d.$popover.attr("aria-hidden", "false");
            "tooltip" !== d.type && b.attr("aria-hidden", "true");
            !e && a && d.attrs("navigate", a);
            p = 2;
          }
          var d = this;
          e = !!e;
          var h = d.typeSpecificFunctions,
            q = h.showMethod !== g ? h.showMethod : y,
            m = h.beforeShowMethod !== g ? h.beforeShowMethod : null,
            r = h.afterShowMethod !== g ? h.afterShowMethod : null;
          p = 1;
          d._willTriggerEvents = e;
          d.attrs("originalFocus", document.activeElement);
          d.$popover
            .css("visibility", "hidden")
            .addClass("a-popover-hidden")
            .show();
          m && m.apply(d, c);
          d.attrs("synchronous")
            ? k()
            : a.delay(function () {
                k();
              }, 0);
        };
      this.show = function () {
        var b = this,
          c = b.attrs("lightboxOptions") || null;
        if (b.isActive() || m.isAnimating(b)) return this;
        b.lock(1);
        c && l.lock(1);
        b.parent.$container &&
          b.parent.$container.is(".a-popover") &&
          b.parent.$container.attr("aria-hidden", "true");
        b.attrs("alone") &&
          a.each(b.parent.children, function (c) {
            c.isActive() &&
              c.id !== b.id &&
              !c.attrs("modeless") &&
              c.unlock().hide();
          });
        f.trigger("beforeShow", b);
        if (
          !b.$container ||
          b.isDirty() ||
          b.getDataStrategy().shouldRefreshContent(b)
        )
          f.trigger("refresh", b), z.call(b);
        if (b.draggable) {
          var e = b.$container;
          a.draggable(e, {handle: e.find(".a-popover-draggable-handle")});
        }
        c && l.show(a.extend({popover: b}, c));
        C.call(b, arguments, !0);
        a.delay(function () {
          b.unlock(1);
          c && l.unlock(1);
        }, 0);
        return this;
      };
      this.hide = function () {
        var c = this,
          k = c.typeSpecificFunctions,
          d = k.hideMethod !== g ? k.hideMethod : n,
          h = k.beforeHideMethod !== g ? k.beforeHideMethod : null,
          q = k.afterHideMethod !== g ? k.afterHideMethod : null,
          r = c.attrs("lightboxOptions") || null;
        if (!c.isActive() || c.isLocked() || m.isAnimating(c)) return this;
        p = -1;
        c.hideChildren();
        f.trigger("beforeHide", c);
        h && h.apply(c, arguments);
        d.call(c, t, arguments);
        f.trigger("hide", c);
        a.delay(function () {
          function k() {
            var b = null;
            "dropdown" === c.type
              ? (b = c.$trigger)
              : c.$trigger &&
                e(c.$trigger).length &&
                (b = c.$trigger.is("a, input, button")
                  ? c.$trigger
                  : c.$trigger.find("a, input, button"));
            (b && b.length) || (b = e(c.attrs("originalFocus")));
            !b.length ||
              (v && !b.is(":visible")) ||
              a.delay(function () {
                ("secondary-view" === c.type || a.onScreen(b, 0)) && b.focus();
              }, 400);
          }
          q && q.apply(c, arguments);
          c.$popover.attr("aria-hidden", "true");
          "tooltip" !== c.type && b.attr("aria-hidden", "false");
          c.parent.$container &&
            c.parent.$container.is(".a-popover") &&
            c.parent.$container.attr("aria-hidden", "false");
          r &&
            (c.parent.attrs("lightboxOptions")
              ? l.show(a.extend({popover: c.parent}, r))
              : l.hide(r));
          f.trigger("afterHide", c);
          p = -2;
          c.attrs("restoreFocusOnHide") && k();
        }, 0);
        return this;
      };
      this.update = function (b) {
        var c = "string" === typeof b ? {content: b} : a.copy(b),
          e = this.attrs();
        b = this.getDataStrategy();
        a.each(c, function (b, c) {
          ((b && !e[c]) || (e[c] && e[c] !== b)) && r.push(c);
        });
        this.isDirty() &&
          ((c = a.extend({}, e, c)),
          this.attrs(c),
          this.getDataStrategy(c),
          this.$popover && b.unloadContent(this),
          this.isActive() && (z.call(this, !0), this.focus()));
        return this;
      };
      this.refresh = function (b, c) {
        return z.call(this, b || !0, c || !1);
      };
      this.isActive = function () {
        return 1 <= p;
      };
      this.isVisible = function () {
        return 2 === p;
      };
      this.isContentLoading = function () {
        return 3 === p;
      };
      this.setContentLoading = function () {
        p = 3;
      };
      this.isContentLoaded = function () {
        return 4 === p;
      };
      this.setContentLoaded = function () {
        p = 4;
      };
      this.isDirty = function () {
        return 0 < r.length;
      };
      this.lock = function (b) {
        b || (b = 10);
        h < b && (h = b);
        return this;
      };
      this.unlock = function (b) {
        b || (b = 10);
        h <= b && (h = -1);
        return this;
      };
      this.isLocked = function () {
        return -1 !== h;
      };
      this.typeSpecificFunctions = d;
      this.attrs(k);
      a.extend(this, this.attributes);
    }
    var g,
      e = a.$,
      b = e("#a-page"),
      c = {
        name: !0,
        url: !0,
        content: !0,
        width: !0,
        height: !0,
        "max-width": !0,
        "max-height": !0,
        "min-width": !0,
        "min-height": !0,
      },
      q = a.capabilities.mobile,
      r = q || a.capabilities.tablet,
      t = q && k.isIE10Plus,
      v = e("html").hasClass("a-lt-ie9"),
      y = function (b) {
        this.$popover
          .css({visibility: "visible"})
          .removeClass("a-popover-hidden");
        this.attrs("focusWhenShown") &&
          "ajax" !== this.attrs("currentDataStrategy") &&
          this.focus();
        b.call(this);
      },
      n = function (b) {
        this.$popover
          .hide()
          .find(".a-lgtbox-vertical-scroll")
          .removeClass("a-lgtbox-vertical-scroll");
        b.call(this);
      },
      x = function () {
        var b = this.typeSpecificFunctions;
        return b.skin !== g ? b.skin(this) : "";
      },
      w = p.prototype;
    w.getDataStrategy = function (b) {
      var c = this.typeSpecificFunctions;
      b || this.attrs("currentDataStrategy") || (b = this.attrs());
      b &&
        (b = b.dataStrategy
          ? h.getStrategyByName(b.dataStrategy)
          : h.guessStrategyByAttrs(b)) &&
        ((c.dataStrategy = b), this.attrs("currentDataStrategy", b.name));
      return c.dataStrategy;
    };
    w.getContent = function () {
      return this.typeSpecificFunctions.getContent !== g
        ? this.typeSpecificFunctions.getContent.apply(this, arguments)
        : null;
    };
    w.updateContent = function (b) {
      this.typeSpecificFunctions.updateContent !== g &&
        this.typeSpecificFunctions.updateContent.apply(this, arguments);
      return this;
    };
    w.setAriaBusy = function (b) {
      this.typeSpecificFunctions.setAriaBusy !== g &&
        this.typeSpecificFunctions.setAriaBusy.apply(this, arguments);
      return this;
    };
    w.ajax = function (b) {
      return this.update({url: b});
    };
    w.updateChildrenPosition = function () {
      a.each(this.children, function (b) {
        b.isActive() && b.updatePosition();
      });
      return this;
    };
    w.updatePosition = function () {
      var b = this;
      if (-1 === b.id)
        a.each(b.children, function (b) {
          b.isActive() && b.updatePosition();
        });
      else {
        if (this.typeSpecificFunctions.updatePosition !== g)
          return (
            this.typeSpecificFunctions.updatePosition.apply(this, arguments),
            a.each(b.children, function (b) {
              b.isActive() && b.updatePosition();
            }),
            b
          );
        var c = b.$popover;
        k.isMetroIEGuess && k.isIETouchCapable
          ? c.css("opacity", 0.01)
          : c.css("visibility", "hidden");
        var h = function () {
          var g = c
              .find(".a-popover-inner")
              .css({height: "auto", "overflow-y": "auto"}),
            h = b.attrs("position"),
            q = {};
          q = b.typeSpecificFunctions.positionStrategy
            ? d.customPosition(b, b.typeSpecificFunctions.positionStrategy)
            : d[h](b);
          f.trigger("beforeUpdatePosition", b);
          h = {top: q.top + "px", left: q.left + "px"};
          k.isMetroIEGuess && k.isIETouchCapable
            ? (h.opacity = 1)
            : (h.visibility = "visible");
          c.css(h);
          b.isContentLoaded() &&
            0 === e(document.activeElement).closest(b.$popover).length &&
            !0 === b.attrs("focusWhenShown") &&
            b.focus();
          if (
            g.length &&
            (!g[0].style.height || "auto" === g[0].style.height)
          ) {
            q = c.outerHeight() || 0;
            var m =
                c
                  .find(".a-popover-header, .a-modal-close-nohead-top")
                  .outerHeight(!0) || 0,
              r = c.find(".a-popover-footer").outerHeight(!0) || 0;
            h = g.outerHeight() || 0;
            q = q - m - r;
            h > q && g.css({height: q + "px", "overflow-y": "scroll"});
          }
          f.trigger("afterUpdatePosition", b);
          f.trigger("positionUpdated", b);
          a.each(b.children, function (b) {
            b.isActive() && b.updatePosition();
          });
        };
        b.attrs("immersive") && r
          ? (c.css({top: 0, left: 0}),
            a.delay(function () {
              h();
            }, 0))
          : h();
      }
      return b;
    };
    w.attrs = function (b, c) {
      var e = this;
      if (c === g && "object" !== typeof b)
        return b
          ? "string" === typeof b
            ? this.attributes[b] !== g
              ? this.attributes[b]
              : null
            : null
          : this.attributes;
      "object" === typeof b
        ? a.each(b, function (b, c) {
            e.attrs(c, b);
          })
        : "string" === typeof b && ((this.attributes[b] = c), (e[b] = c));
      return this;
    };
    w.hideChildren = function () {
      a.each(this.children, function (b) {
        b.unlock(1);
        b.hide();
      });
      return this;
    };
    w.focus = function () {
      var b = this,
        c = e(u),
        k = c.scrollTop(),
        g = b.$popover.offset().top;
      t && k > g && c.scrollTop(g);
      a.delay(function () {
        b.$firstTabbable.focus();
      }, 0);
      return this;
    };
    return {PopoverClass: p};
  });
  ("use strict");
  n.when("jQuery", "ready").register("a-changeover", function (a) {
    a(document).delegate(
      ".a-changeover:not(.a-changeover-manual)",
      "webkitAnimationEnd animationend click touchstart",
      function (a) {
        this.style.display = "none";
      }
    );
  });
  ("use strict");
  n.when(
    "A",
    "a-popover-lightbox",
    "a-popover-optional-helpers",
    "prv:a-capabilities"
  ).register("a-dropdown-base-positions", function (a, f, h, d) {
    function l(e) {
      e = e.popover;
      if (e.isVisible() && p) {
        var b = document.body,
          c = Math.abs(parseInt(b.style.top, 10));
        if (c) {
          b = b.clientHeight;
          var k = a.viewport().height,
            g = e.attrs("initialBodyTop");
          c > b - k
            ? (e.attrs("initialBodyTop", c),
              (document.body.style.top = -(b - k) + "px"))
            : g && (document.body.style.top = g);
        }
      }
    }
    function m(e) {
      var b = e.$popover;
      b.find(".a-popover-inner").css("height", "auto");
      l(e);
      b.css({width: "auto", position: "absolute", display: "inline-block"});
      b = e.measure(b, e.$trigger);
      var c = 0.1 * b.windowHeight;
      e = h.getOffsetTopDelta(e, c, g);
      return {
        top: u.scrollY + (c + e),
        left: (b.windowWidth - b.popoverWidth) / 2,
      };
    }
    function k(e) {
      var b = e.$popover,
        c = b.find(".a-popover-inner").css("height", "auto"),
        k = b.find(".a-popover-header");
      l(e);
      b.css({width: "auto", display: "inline-block"});
      b = e.measure(b, e.$trigger);
      k = 0.8 * (a.viewport().height - k.outerHeight());
      var d = c.outerHeight();
      h.evaluateActualHeight(e, d, g) > k
        ? ((d = 0.1 * a.viewport().height),
          (e = h.getOffsetTopDelta(e, d, g)),
          (d += e),
          c.css("height", k - e + "px").addClass("a-lgtbox-vertical-scroll"))
        : ((d = (b.windowHeight - b.popoverHeight) / 2),
          c.removeClass("a-lgtbox-vertical-scroll"));
      return {top: d, left: (b.windowWidth - b.popoverWidth) / 2};
    }
    f =
      a.capabilities.isGen5App ||
      (d.isAndroidStockGuess &&
        a.capabilities.androidVersion &&
        "4.1" > a.capabilities.androidVersion);
    var p = /Silk|Chrome|(?:UCBrowser\/(?:9|1\d+))/i.test(navigator.userAgent),
      g = 0;
    n.when("prv:skin-vars").execute(function (e) {
      g = e.popover.optionalButtonHeight;
    });
    return {positionStrategy: f ? m : k};
  });
  ("use strict");
  n.when("A", "a-dropdown-base-positions").register(
    "a-dropdown-base-view-base",
    function (a, f) {
      return a.extend(f, {
        updateContent: function (a) {
          "string" === typeof a
            ? this.$popover.find(".a-popover-inner").html(a)
            : a && this.$popover.find(".a-popover-inner").html("").append(a);
        },
        beforeShowMethod: function () {
          this.parent.lock(1);
          this.$trigger.attr("aria-pressed", !0);
        },
        afterShowMethod: function () {
          var h = this.$popover,
            d = h.find(".a-active");
          a.delay(function () {
            d.length
              ? d.closest("li").focus()
              : (d = h.find("li").first().focus());
          }, 0);
        },
        beforeHideMethod: function () {
          this.parent.unlock(1);
        },
        afterHideMethod: function () {
          this.$trigger.attr("aria-pressed", !1);
          this.$popover.css("width", "auto");
        },
      });
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-ua",
    "a-popover-base-factory",
    "a-dropdown-base-positions",
    "a-dropdown-base-view-base",
    "a-popover-animate",
    "prv:a-capabilities"
  ).register("a-dropdown-base-view", function (a, f, h, d, l, m, k) {
    function p(b, c) {
      b.$popover
        .css({opacity: 0, visibility: "visible"})
        .removeClass("a-popover-hidden");
      a.delay(function () {
        m.animate(b, {opacity: 1}, 500, "linear", function () {
          c.call(b);
        });
      }, 0);
    }
    function g(b, c) {
      var e = b.$popover;
      a.delay(function () {
        x && r.hide();
        e.css({visibility: "visible"}).removeClass("a-popover-hidden");
        c.call(b);
      }, 0);
    }
    function e(b, c) {
      var e = b.$popover.find(".a-lgtbox-vertical-scroll");
      b.scrollable = !!e.length;
      b.scrollable ||
        w ||
        e.addClass("a-gesture").bind("tap.a-dropdown", function (b) {
          q(b.target).trigger("click");
        });
      b.scrollY = u.scrollY;
      b.scrollX = u.scrollX;
      b.scrollY === B &&
        ((b.scrollY = u.pageYOffset), (b.scrollX = u.pageXOffset));
      z &&
        b.parent &&
        "secondary-view" !== b.parent.type &&
        (q("html, body").css({position: "fixed", overflow: "hidden"}),
        (document.body.style.top = -1 * b.scrollY + "px"));
      b.$popover.css("visibility", "visible").removeClass("a-popover-hidden");
      w &&
        q(u).bind("scroll.dropdown", function () {
          var c = parseInt(b.$popover[0].style.top, 10) || 0,
            e = c + b.$popover.height();
          u.scrollY + u.innerHeight < c + 50
            ? u.scrollTo(b.scrollX, c - 20)
            : u.scrollY > e - 50 &&
              u.scrollTo(b.scrollX, e - 0.8 * u.innerHeight);
        });
      c.call(b);
    }
    function b() {
      this.$trigger.attr("aria-pressed", !1);
      this.$popover.css("width", "auto");
    }
    function c() {
      this.$trigger.attr("aria-pressed", !1);
      var b = this.$popover;
      b.css("width", "auto");
      b.find(".a-popover-inner")
        .removeClass("a-gesture")
        .unbind("tap.a-dropdown");
      z &&
        (q("html, body").css({position: "", overflow: ""}),
        (document.body.style.top = "0"),
        this.attrs("initialBodyTop", 0));
      (z ||
        (t.android &&
          t.isAmazonApp &&
          t.androidVersion &&
          -1 === v(t.androidVersion, "4.4"))) &&
        u.scrollTo(this.scrollX, this.scrollY);
      w && q(u).unbind("scroll.dropdown");
    }
    var q = a.$,
      r = q("#a-page"),
      t = a.capabilities,
      v = f.compareVersions,
      y = h.getRoot().id,
      n = k.isIE10Plus && t.mobile,
      x = t.mobile && k.isIE10,
      w =
        t.isGen5App ||
        (k.isAndroidStockGuess &&
          t.androidVersion &&
          -1 === v(t.androidVersion, "4.1")),
      z =
        k.isChrome ||
        (t.tablet && t.ieIE10Plus) ||
        (t.isAmazonApp && t.androidVersion && -1 < v(t.androidVersion, "4.4"));
    return a.extend(d, l, {
      showMethod: function (b) {
        a.capabilities.ios ? p(this, b) : n ? g(this, b) : e(this, b);
      },
      afterShowMethod: function () {
        var b = this.$popover,
          c = b.find(".a-active");
        a.delay(function () {
          c.length
            ? c.closest("li").focus()
            : ((c = b.find("li").first().focus()),
              t.android &&
                t.isAmazonApp &&
                t.androidVersion &&
                -1 === v(t.androidVersion, "4.4") &&
                c[0].scrollIntoView());
        }, 25);
      },
      beforeHideMethod: function () {
        this.parent.unlock(1);
        if (x) {
          for (var b = !0, c = this.parent; b && c.id !== y; )
            c.attrs("lightboxOptions") && (b = !1), (c = c.parent);
          b && r.show();
        }
      },
      afterHideMethod: t.ios ? b : c,
    });
  });
  ("use strict");
  n.when("A", "a-popover-base-factory", "a-dropdown-base-view").register(
    "a-dropdown-base-factory",
    function (a, f, h) {
      function d(g, e, b) {
        var c = ['\x3cli tabindex\x3d"0" role\x3d"option"'],
          d = g.data("aCssClass"),
          h = g.data("aId"),
          m = g.data("aHtmlContent"),
          f = g.data("aImageSource"),
          p = JSON.stringify({stringVal: g.val()});
        p = [
          '\x3ca tabindex\x3d"-1" href\x3d"javascript:void(0)" aria-hidden\x3d"true" data-value\x3d"',
          a.escapeHtml(p),
          '"',
        ];
        var l = ["a-dropdown-link"],
          n = ["a-dropdown-item"];
        e && (l.push("a-active"), c.push(' aria-checked\x3d"true"'));
        k &&
          (a.capabilities.mobile || a.capabilities.tablet) &&
          l.push("a-list-link-after-group");
        k = !1;
        d && n.push(d);
        h && c.push(' id\x3d"' + h + '"');
        c.push('aria-labelledby\x3d"');
        c.push(b);
        c.push('"');
        p.push(' id\x3d"');
        p.push(b);
        p.push('"');
        c.push(' class\x3d"' + n.join(" ") + '"');
        c.push("\x3e");
        m
          ? (e = m)
          : ((e = []),
            f &&
              (l.push("a-option-has-image"),
              e.push(
                '\x3cimg src\x3d"' +
                  f +
                  '" class\x3d"a-rich-option-image" /\x3e'
              )),
            e.push(g.html()),
            (e = e.join("")));
        p.push(' class\x3d"');
        p.push(l.join(" "));
        p.push('"\x3e');
        p.push(e);
        p.push("\x3c/a\x3e");
        c.push(p.join(""));
        c.push("\x3c/li\x3e");
        return c.join("");
      }
      function l(a) {
        a.jquery || (a = m(a));
        var e = a.children("optgroup,option:not(.a-prompt)"),
          b = !1,
          c = a[0],
          g = a.attr("id") ? a.attr("id") : "dropdown" + p++;
        if (-1 < c.selectedIndex) var h = c.options[c.selectedIndex].value;
        var f = [
          '\x3cul tabindex\x3d"-1" class\x3d"a-nostyle a-list-link',
          a.data("a-has-images") ? " a-box-list" : "",
          '" role\x3d"listbox" aria-multiselectable\x3d"false"\x3e',
        ];
        var l = 0;
        e.each(function () {
          var c = m(this);
          c.is("optgroup")
            ? (c.children().each(function (b) {
                f.push(d(m(this), h === this.value, g + "_" + l++));
              }),
              f.push(
                '\x3cli tabindex\x3d"-1" class\x3d"divider"\x3e\x3chr /\x3e\x3c/li\x3e'
              ),
              (b = k = !0))
            : (f.push(d(c, h === this.value, g + "_" + l++)), (b = !1));
        });
        b && f.pop();
        f.push("\x3c/ul\x3e");
        return f.join("");
      }
      var m = a.$,
        k = !1,
        p = 1;
      return a.extend(
        {create: f.create, remove: f.remove, get: f.get},
        {
          type: "dropdown",
          create: function (k, e, b) {
            var c = e.$button,
              g = e.$sourceSelect,
              d = g[0],
              m = c.find(".a-dropdown-label"),
              p = g.data("aTouchHeader");
            if (!p || (!p.length && m.length)) p = m.text();
            return f.create(k, {
              attributes: {
                type: "dropdown",
                header: p,
                closeButtonLabel: e.closeButtonLabel
                  ? e.closeButtonLabel
                  : "Close",
                inlineContent: g,
                position: e.position,
                alone: !0,
                sourceSelect: g,
                sourceButton: c,
                name: g[0].name,
                preventNameReuse: !0,
                lightboxOptions:
                  a.capabilities.mobile || a.capabilities.tablet
                    ? {
                        showDuration: a.capabilities.ios ? null : 0,
                        hideDuration: 0,
                      }
                    : null,
              },
              typeSpecificFunctions: a.extend({}, h, b, {
                skin: function (c) {
                  var e = b.subskin ? b.subskin(d) : l(d);
                  c.attrs("inlineContent", e);
                  return b.skin(c);
                },
              }),
              actionCheck: !1,
            });
          },
        }
      );
    }
  );
  ("use strict");
  n.when("A", "prv:a-capabilities").execute(
    "a-dropdown-base-handlers",
    function (a, f) {
      var h = a.capabilities.tablet && f.isIE10Plus;
      a.declarative("a-popover-scroll", a.action.start, function (a) {
        a = a.$target.closest(".a-popover-inner")[0];
        if (!h) {
          var d = a.scrollTop + a.offsetHeight;
          0 >= a.scrollTop
            ? (a.scrollTop = 1)
            : a.scrollHeight <= d && --a.scrollTop;
        }
      });
      a.declarative("a-popover-header", a.action.move, function (a) {
        a.$event.originalEvent.preventDefault();
      });
      a.declarative("a-popover-scroll", a.action.move, function (a) {
        var d = a.$target.closest(".a-popover-inner");
        a = a.$event.originalEvent;
        d.hasClass("a-lgtbox-vertical-scroll") || a.preventDefault();
      });
    }
  );
  ("use strict");
  n.when("A", "a-dropdown-base-factory").register(
    "a-dropdown-keyboard-handlers",
    function (a, f) {
      function h(a) {
        a.removeData("a-user-navigated-text").removeData(
          "a-user-navigated-idx"
        );
      }
      function d(a, b) {
        a.removeAttr("aria-selected");
        "option" === b.attr("role") && b.attr("aria-selected", "true");
        b.focus();
      }
      function l(a) {
        var b = a.parent("ul");
        a = b.find("li");
        var c = b.find(":focus");
        1 > c.length && (c = b.find('[aria-checked\x3d"true"]'));
        b = c;
        return {index: 0 < b.length ? b.index() : 0, $options: a};
      }
      function m(a, b, c) {
        a.preventDefault();
        b.find("a").eq(0).trigger("click");
        h(c);
      }
      function k(e) {
        var b = e.data("a-user-navigated-debouncer");
        b ||
          ((b = a.debounce(function () {
            h(e);
          }, 1e3)),
          e.data("a-user-navigated-debouncer", b));
        b();
      }
      var p = a.$,
        g = a.constants.keycodes;
      return {
        keyDown: function (a) {
          var b = p(this),
            c = b.parent();
          switch (a.which) {
            case g.UP_ARROW:
              a.preventDefault();
              h(c);
              0 < l(b).index && d(b, b.prev());
              break;
            case g.DOWN_ARROW:
              a.preventDefault();
              h(c);
              c = l(b);
              a = c.index;
              0 <= a && a + 1 < c.$options.length && d(b, b.next());
              break;
            case g.ENTER:
              m(a, b, c);
              break;
            case g.ESCAPE:
              a.preventDefault();
              b = f.get(b.closest(".a-popover"));
              b.sourceButton.find(".a-button-text").focus();
              b.hide();
              h(c);
              break;
            case g.SPACE:
              c.data("a-user-navigated-text") || m(a, b, c);
              break;
            case g.TAB:
              h(c);
              break;
            case g.BACKSPACE:
              a.preventDefault();
          }
        },
        keyPress: function (e) {
          var b = p(this),
            c = b.parent(),
            d = f.get(b.closest(".a-popover")),
            h = e.which;
          if (d && d.isActive() && h !== g.TAB && 0 !== h) {
            k(c);
            var l = c.data("a-user-navigated-idx") || 0;
            if (!(0 > l)) {
              d =
                (c.data("a-user-navigated-text") || "") +
                String.fromCharCode(h).toLocaleLowerCase();
              c.data("a-user-navigated-text", d);
              for (var v = c.children(); l < v.length; l++) {
                var y = v.eq(l);
                if (0 === a.trim(y.text().toLocaleLowerCase()).indexOf(d)) {
                  y.focus();
                  c.data("a-user-navigated-idx", l);
                  return;
                }
              }
              c.data("a-user-navigated-idx", -1);
              h === g.SPACE && m(e, b, c);
            }
          }
        },
      };
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-dropdown-select-apis",
    "a-dropdown-base-factory",
    "a-popover-base"
  ).register("a-dropdown-base", function (a, f, h, d) {
    function l(e, b, c) {
      try {
        var d = e.$event || e;
        d.preventDefault ? d.preventDefault() : (d.returnValue = !1);
      } catch (t) {}
      var m = e.$declarativeParent ? e.$declarativeParent : g(e.currentTarget);
      a.delay(function () {
        var d = b.$button ? b.$button : b.getButtonFromEvent(e),
          f = b.$select ? b.$select : b.getSelectFromEvent(e);
        if (!d.hasClass("a-button-disabled")) {
          p(f, b).isSynced() || k(g.extend({$button: d, $select: f}, b));
          f = a.extend({}, b, {$button: d, $sourceSelect: f});
          var q = h.create(m, f, c);
          if (
            q &&
            (q.show(),
            d
              .data("a-popover-id", q.id)
              .data("popover", q)
              .data("isPressed", !0),
            !q.hasOnLoad)
          ) {
            q.hasOnLoad = !0;
            var r = [];
            d = q.$popover.find("img");
            d.length &&
              (d.each(function (b, c) {
                if (!c.complete || !c.naturalWidth) {
                  var a = g.Deferred();
                  r.push(a);
                  g(c).bind("load error", function () {
                    a.resolve();
                  });
                }
              }),
              r.length
                ? g.when.apply(g, r).done(function () {
                    q.updatePosition();
                  })
                : q.updatePosition());
          }
        }
      });
    }
    function m(a) {
      var b = a.$button;
      a = a.$select;
      b || (b = a.nextAll(".a-button-dropdown"));
      return a.length ? ((b = h.get(b)) && b.hide(), !0) : !1;
    }
    function k(a) {
      var b = a.$button;
      a = a.$select;
      b || (b = a.nextAll(".a-button-dropdown"));
      return a.length
        ? ((b = h.get(b)) && h.remove(b.id), a.data("a-info", null), !0)
        : !1;
    }
    function p(e, b) {
      e = b.$select
        ? b.$select
        : "string" === typeof e
        ? g("select#" + e)
        : e.jquery
        ? e
        : g(e);
      if (!e.length) return null;
      var c = b.$button ? b.$button : b.getButtonFromSelect(e);
      e.data("a-select")
        ? (b = e.data("a-select"))
        : ((b = a.extend(
            {
              hidePopover: m,
              refreshPopover: k,
              options: a.extend({$select: e, $button: c}, b),
            },
            f
          )),
          e.data("a-select", b));
      return b;
    }
    var g = a.$;
    return {
      toggleDropdown: function (a, b) {
        var c = (b.$button ? b.$button : b.getButtonFromEvent(a)).data(
          "popover"
        );
        c && c.$popover.is(":visible") ? c.hide() : l(a, b);
      },
      showDropdown: l,
      getSelect: p,
    };
  });
  ("use strict");
  n.when("A", "jQuery").register("a-dropdown-options-apis", function (a, f) {
    return {
      update: function (a) {
        "object" !== typeof a &&
          n.error("input of options.update() function must be a hash");
        this.hidePopover(this.options);
        for (var d = 0, h = this.size(); d < h; d++) {
          var f = this.options.elements[d],
            k = f[0];
          a.value && f.val(a.value);
          void 0 !== a.selected &&
            (!k.selected && a.selected
              ? this.options.$select.val(k.value)
              : k.selected && !a.selected && this.options.$select.val(""));
          a.html_content && f.data("a-html-content", a.html_content);
          a.image_source && f.data("a-image-source", a.image_source);
          a.native_css_class && (k.className = a.native_css_class);
          a.css_class && f.data("a-css-class", a.css_class);
          a.native_id && (k.id = a.native_id);
          a.id && f.data("a-id", a.id);
          a.text &&
            (f.text(a.text), k.selected && this.setSelectValue(k.value));
        }
        this.refreshPopover(this.options);
        return this;
      },
      remove: function () {
        this.hidePopover(this.options);
        for (var a = 0, d = this.size(); a < d; a++) {
          var f = this.options.elements[a];
          f.is(":selected") && this.setSelectValue("");
          f.remove();
        }
        this.refreshPopover(this.options);
        return !0;
      },
      info: function () {
        for (var a = [], d = 0, f = this.size(); d < f; d++) {
          var m = this.options.elements[d];
          a.push({
            value: m[0].value,
            text: m.text(),
            selected: m[0].selected,
            html_content: m.data("a-html-content"),
            image_source: m.data("a-image-source"),
            native_css_class: m[0].className,
            css_class: m.data("a-css-class"),
            native_id: m[0].id,
            id: m.data("a-id"),
          });
        }
        return a;
      },
      size: function () {
        return this.options.elements.length;
      },
    };
  });
  ("use strict");
  n.when("A", "jQuery", "a-dropdown-options-apis").register(
    "a-dropdown-select-apis",
    function (a, f, h) {
      function d(a) {
        var k = this.options.$select,
          g = this.options.$button,
          e = k[0];
        "number" === typeof a && (a = a.toString());
        for (
          var b = 0, c = e.options.length;
          b < c && e.options[b].value !== a;
          b++
        );
        b === c && "" === a && (b = 0);
        b < c &&
          (g.find(".a-dropdown-prompt").html(e.options[b].innerHTML),
          g.css("min-width", b / e.options.length + "%"),
          k.val() !== a && (k.val(a), k.trigger("change", [m, !0])));
        return this;
      }
      function l(a) {
        if (a === m) return this.options.$select.val();
        this.setValue = d;
        return this.setValue(a);
      }
      var m;
      return {
        isSynced: function () {
          var k = this.options.$select,
            d = k.data("a-info"),
            g = this.getOptions().info();
          k.data("a-info", g);
          return d ? a.equals(d, g) : !0;
        },
        update: function (a) {
          "object" !== typeof a &&
            n.error("input of select.update() function must be an object");
          this.hidePopover(this.options);
          var d = {
              none: !0,
              micro: !0,
              mini: !0,
              small: !0,
              base: !0,
              medium: !0,
              large: !0,
              "extra-large": !0,
              "double-large": !0,
              block: !0,
            },
            g = this.options.$select,
            e = g[0],
            b = this.options.$button,
            c = b[0],
            k = g.siblings("label");
          a.name && (e.name = a.name);
          if (a.option_prompt) {
            var h = g.find(".a-prompt");
            h.length
              ? (h.text(a.option_prompt),
                h.prop("selected") &&
                  b.find(".a-dropdown-prompt").text(a.option_prompt))
              : (g.prepend(
                  f("\x3coption class\x3d'a-prompt' /\x3e").text(
                    a.option_prompt
                  )
                ),
                b.find(".a-dropdown-prompt").text(a.option_prompt));
          }
          a.has_images !== m && g.data("a-has-images", !!a.has_images);
          a.button_size !== m &&
            b.length &&
            ("small" === a.button_size
              ? b.addClass("a-button-small")
              : b.removeClass("a-button-small"));
          a.spacing !== m &&
            d.hasOwnProperty(a.spacing) &&
            ((d = /\ba-spacing-[a-z]+\b/g),
            (e.className = e.className.replace(d, "")),
            (c.className = c.className.replace(d, "")),
            g.addClass("a-spacing-" + a.spacing),
            b.addClass("a-spacing-" + a.spacing));
          a.grid_units !== m &&
            ((d = /\ba-button-span\d{1,2}\b/g),
            (e.className = e.className.replace(d, "")),
            (c.className = c.className.replace(d, "")),
            isFinite(a.grid_units) &&
              0 < a.grid_units &&
              13 > a.grid_units &&
              (g.addClass("a-button-span" + a.grid_units),
              b.addClass("a-button-span" + a.grid_units)));
          a.width_name &&
            ("base" === a.width_named
              ? b.addClass("a-button-width-normal")
              : b.removeClass("a-button-width-normal"));
          if (a.status) {
            var l = a.status;
            d = b
              .closest(".a-dropdown-container, .a-splitdropdown-container")
              .find(".a-button");
            h = "error" === l;
            l = "disabled" === l;
            e.disabled = l;
            d.toggleClass("a-button-disabled", l);
            f(e).hasClass("a-native-splitdropdown")
              ? l
                ? d
                    .find("button.a-button-text")
                    .attr("aria-disabled", "true")
                    .parents(".a-button-splitdropdown")
                    .find("button.a-button-text")
                    .removeAttr("role")
                : d
                    .find("button.a-button-text")
                    .removeAttr("aria-disabled")
                    .parents(".a-button-splitdropdown")
                    .find("button.a-button-text")
                    .attr("role", "combobox")
              : l
              ? d.attr("aria-disabled", "true")
              : d.removeAttr("aria-disabled");
            d.toggleClass("a-button-error", h);
          }
          a.native_id &&
            ((e.id = a.native_id), k.length && (k[0].htmlFor = a.native_id));
          a.id && (c.id = a.id);
          a.native_css_class &&
            ((c = g.data("a-native-class")) && g.removeClass(c),
            g
              .addClass(a.native_css_class)
              .data("a-native-class", a.native_css_class));
          a.css_class &&
            ((c = b.data("a-class")) && b.removeClass(c),
            b.addClass(a.css_class).data("a-class", a.css_class));
          a.label_text !== m &&
            ("" === a.label_text
              ? (b.find(".a-dropdown-label").remove(),
                g.siblings("label").remove())
              : ((c = b.find(".a-dropdown-label")),
                c.length
                  ? c.text(a.label_text)
                  : b
                      .find(".a-dropdown-prompt")
                      .before(
                        f("\x3cspan class\x3d'a-dropdown-label' /\x3e").text(
                          a.label_text
                        )
                      ),
                k.length
                  ? k.text(a.label_text)
                  : g.before(
                      f(
                        "\x3clabel for\x3d'" +
                          e.id +
                          "' class\x3d'a-native-dropdown' /\x3e"
                      ).text(a.label_text)
                    )),
            b.css("min-width", "" === a.label_text ? "0.1%" : "0%"));
          this.refreshPopover(this.options);
          return this;
        },
        setValue: d,
        val: l,
        getOptions: function (d) {
          var k = this.options.$select,
            g = [];
          d =
            d === m
              ? k.children("optgroup, option:not(.a-prompt)")
              : f.isArray(d)
              ? d
              : [d];
          for (var e = 0, b = d.length; e < b; e++) {
            var c = d[e],
              q = [];
            a.isFiniteNumber(c)
              ? (q = k.children("optgroup, option:not(.a-prompt)").eq(c))
              : "string" === typeof c
              ? (q = k.children("option#" + c))
              : "object" === typeof c && (q = c.jquery ? c : f(c));
            q.length && g.push(q);
          }
          return a.extend(
            {
              hidePopover: this.hidePopover,
              refreshPopover: this.refreshPopover,
              setSelectValue: l,
              options: a.extend({elements: g}, this.options),
            },
            h
          );
        },
        getOption: function (a) {
          return this.getOptions(a);
        },
        addOptions: function (a, d) {
          f.isArray(a) || (a = [a]);
          for (var g = a.length; g--; ) this.addOption(a[g], d);
          return this;
        },
        addOption: function (a, d) {
          var g = this.options.$select;
          if (!a.native_id || !g.find("option#" + a.native_id).length) {
            var e = g.children("optgroup, option:not(.a-prompt)"),
              b = document.createElement("option");
            d = d && 0 < d && d <= e.length ? d : 0;
            a.native_id && (b.id = a.native_id);
            0 === e.length || d === e.length
              ? g[0].appendChild(b)
              : e.eq(d).before(b);
            this.getOption(b).update(a);
          }
          return this;
        },
        removeOptions: function (a) {
          this.getOptions(a).remove();
          return this;
        },
        removeOption: function (a) {
          return this.removeOptions(a);
        },
        appendOption: function (a) {
          return this.addOption(
            a,
            this.options.$select.children("optgroup, option:not(.a-prompt)")
              .length
          );
        },
        appendOptions: function (a) {
          if (f.isArray(a))
            for (var d = 0, g = a.length; d < g; d++) this.addOption(a[d]);
          return this;
        },
      };
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-dropdown-options",
    "a-dropdown-apis",
    "a-dropdown-keyboard-handlers",
    "a-analytics"
  ).register("a-dropdown", function (a, f, h, d, l) {
    var m = a.$,
      k = m(document);
    a.on("beforeReady a:pageUpdate a:ajax:complete", function () {
      var a = k.find("select.a-native-dropdown").not("[tabindex\x3d0]"),
        d = a.length;
      d &&
        (a
          .next(".a-button-dropdown")
          .attr("aria-hidden", !0)
          .find(".a-button-text")
          .removeAttr("tabindex"),
        l.count("dropdown:usage", d),
        a.attr("tabindex", 0));
    });
    k.delegate(".a-native-dropdown", "change", function (d, g, e) {
      var b = f.getButtonFromEvent(d),
        c = "",
        k =
          -1 < this.selectedIndex ? this.options[this.selectedIndex].value : "",
        r = b.data("popover");
      d = !1;
      if (b.length) {
        b = b.eq(0);
        for (var l = this.length; l--; ) {
          var p = this.options[l];
          if (p.value === k) {
            c = p.innerHTML;
            break;
          }
        }
        r &&
          r.$popover &&
          (r.$popover
            .find(".a-active")
            .removeClass("a-active")
            .closest("li")
            .attr("aria-checked", !1),
          void 0 === g &&
            ((g = JSON.stringify({stringVal: k})),
            (g = r.$popover.find(
              'a[data-value\x3d"' + a.escapeJquerySelector(g) + '"]'
            ))));
        g &&
          g.length &&
          ((d = !0),
          g.addClass("a-active").closest("li").attr("aria-checked", !0));
        b.find(".a-dropdown-prompt").html(c);
        b.css("min-width", this.selectedIndex / this.options.length + "%");
        r &&
          (r.hide(),
          (b = h.getSelect(this)) &&
            m(this).data("a-info", b.getOptions().info()));
        e ||
          ((e = this.name),
          (b = this.id),
          (g = {
            auiItemNode: d ? g[0] : null,
            nativeItemNode: this.options[this.selectedIndex],
            selectNode: this,
            id: b,
            name: e,
            value: this.value,
          }),
          e &&
            "" !== e &&
            (a.trigger("a:dropdown:" + e + ":select", g),
            a.trigger("a:dropdown:selected:" + e, g)),
          b && "" !== b && a.trigger("a:dropdown:" + b + ":select", g),
          a.trigger("a:dropdown:select", g));
      }
    });
    k.delegate(
      ".a-button-dropdown:not(.a-button-disabled)",
      "focusin",
      function () {
        m(this).find(".a-button-text").focus();
      }
    );
    k.delegate("select.a-native-dropdown", "focusin", function () {
      var a = m(this)
        .closest(".a-dropdown-container")
        .find(".a-button-dropdown");
      a.hasClass("a-button-disabled") || a.addClass("a-button-focus");
    }).delegate("select.a-native-dropdown", "focusout", function () {
      m(this)
        .closest(".a-dropdown-container")
        .find(".a-button-dropdown")
        .removeClass("a-button-focus");
    });
    return h;
  });
  ("use strict");
  n.when("A", "a-dropdown-base", "a-dropdown-options").register(
    "a-dropdown-apis",
    function (a, f, h) {
      function d(a) {
        return f.getSelect(a, h);
      }
      var l = a.$;
      a.on("beforeReady", function () {
        l(".a-dropdown-container select").each(function () {
          var a = d(this);
          a && a.val(a.val());
        });
      });
      return {
        getSelect: d,
        updateOption: function (a, k) {
          var h = l("option#" + a).closest("select");
          d(h).getOption(a).update(k);
        },
        updateSelect: function (a, k) {
          d(a).update(k);
        },
        setValue: function (a, k) {
          d(a).setValue(k);
        },
      };
    }
  );
  ("use strict");
  n.when("A", "a-popover-accessibility", "a-ua", "prv:a-capabilities").register(
    "a-dropdown-view",
    function (a, f, h, d) {
      a = a.capabilities;
      h =
        a.isGen5App ||
        (d.isAndroidStockGuess &&
          a.androidVersion &&
          -1 === h.compareVersions(a.androidVersion, "4.1"));
      var l = a.isAndroid ? "a-scrollbar-fix" : "";
      if (h) {
        var m = function () {
          return '\x3cdiv class\x3d"a-popover-header"\x3e';
        };
        var k = function () {
          return '\x3cdiv class\x3d"a-popover-inner ' + l + '"\x3e';
        };
      } else
        (m = function () {
          return '\x3cdiv data-action\x3d"a-popover-header" class\x3d"a-popover-header a-declarative"\x3e';
        }),
          (k = function () {
            return (
              '\x3cdiv data-action\x3d"a-popover-scroll" class\x3d"a-popover-inner a-declarative ' +
              l +
              '"\x3e'
            );
          });
      return {
        skin: function (a) {
          var d = a.attrs("header") || "",
            e = a.attrs("closeButtonLabel");
          a = a.id;
          var b = {id: a, header_str: d, needs_declarative: !1};
          return [
            '\x3cdiv class\x3d"a-popover a-dropdown a-dropdown-common a-declarative" aria-modal\x3d"true" data-action\x3d"a-popover-a11y"\x3e',
            f.getStartAnchorHtml(b),
            '\x3cdiv class\x3d"a-popover-wrapper"\x3e',
            m(),
            '\x3ch4 id\x3d"a-popover-header-',
            a,
            '" class\x3d"a-popover-header-content"\x3e',
            d,
            '\x3c/h4\x3e\x3cbutton data-action\x3d"a-popover-close" class\x3d"a-button-close a-declarative" aria-label\x3d"',
            e + '"\x3e',
            '\x3ci class\x3d"a-icon a-icon-close"\x3e\x3c/i\x3e\x3c/button\x3e\x3c/div\x3e',
            k(),
            "\x3c/div\x3e\x3c/div\x3e",
            f.getEndAnchorHtml(b),
            "\x3c/div\x3e",
          ].join("");
        },
      };
    }
  );
  ("use strict");
  n.when("A").register("a-dropdown-options", function (a) {
    function f(a) {
      return a.nextAll(".a-button-dropdown");
    }
    var h = a.$;
    return {
      getSelectFromButton: function (a) {
        return a
          .closest(".a-button-dropdown")
          .prevAll("select.a-native-dropdown");
      },
      getButtonFromEvent: function (a) {
        return a.popover
          ? a.popover.$trigger.nextAll(".a-button-dropdown")
          : a.$target
          ? f(a.$target)
          : h(a.target).nextAll(".a-button-dropdown");
      },
      getButtonFromSelect: f,
      getSelectFromEvent: function (a) {
        a = h(a.target);
        a.length || n.error("Cannot locate the \x3cselect\x3e of dropdown");
        return a;
      },
      triggerSelector: ".a-button-dropdown",
    };
  });
  ("use strict");
  n.when("A", "a-popover-accessibility").register(
    "a-dropdown-split-view",
    function (a, f) {
      return {
        skin: function (a) {
          var d = a.attrs("header") || "";
          a = {id: a.id, label_str: d, needs_declarative: !1};
          return [
            '\x3cdiv class\x3d"a-popover a-splitdropdown a-dropdown-common a-declarative" aria-modal\x3d"true" data-action\x3d"a-popover-a11y"\x3e',
            f.getStartAnchorHtml(a),
            '\x3cdiv class\x3d"a-popover-wrapper"\x3e\n\x3cdiv data-action\x3d"a-popover-scroll" class\x3d"a-popover-inner a-declarative"\x3e\x3c/div\x3e\n\x3c/div\x3e',
            f.getEndAnchorHtml(a),
            "\x3c/div\x3e",
          ].join("\n");
        },
      };
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-dropdown-base",
    "a-dropdown-split-utils",
    "a-dropdown-split-view",
    "a-dropdown-split-options",
    "a-dropdown-base-factory",
    "a-dropdown-keyboard-handlers"
  ).register("a-dropdown-split-handlers", function (a, f, h, d, l, m, k) {
    var p = a.$;
    a.declarative("a-splitdropdown-button", "click", function (g) {
      var e = l.getButtonFromEvent(g);
      f.showDropdown(g, a.extend({$button: e}, l), d);
    });
    a.declarative("a-splitdropdown-main", "click", function (a) {
      var d = a.$target.closest(".a-splitdropdown-container").find("select"),
        b = d.attr("id"),
        c = d.val();
      h.triggerEvent(b, d, c);
      a.$event.preventDefault();
    });
    a.declarative("a-splitdropdown-button", "keydown", function (g) {
      var e = l.getButtonFromEvent(g),
        b = a.constants.keycodes,
        c = g.$event.which;
      (c !== b.DOWN_ARROW && c !== b.ENTER && c !== b.SPACE) ||
        f.showDropdown(g, p.extend({$button: e}, l), d);
    });
    p(document)
      .delegate(".a-popover.a-splitdropdown a", "click", function (a) {
        var d = p(this),
          b = d.data("value").stringVal;
        d = m.get(d.closest(".a-popover"));
        var c = d.sourceSelect,
          g = c.attr("id");
        d.hide();
        h.triggerEvent(g, c, b);
        a.preventDefault();
      })
      .delegate(".a-splitdropdown li", "keydown", k.keyDown)
      .delegate(".a-splitdropdown li", "keypress", k.keyPress);
  });
  ("use strict");
  n.when("A").register("a-dropdown-split-options", function (a) {
    function f(a) {
      return a.popover
        ? a.popover.$trigger.closest(".a-button-splitdropdown")
        : a.$target
        ? a.$target.closest(".a-button-splitdropdown")
        : h(a.target).nextAll(".a-button-splitdropdown");
    }
    var h = a.$;
    return {
      getButtonFromEvent: f,
      getButtonFromSelect: function (a) {
        return a
          .next(".a-button-group-splitdropdown")
          .find(".a-button-splitdropdown");
      },
      getSelectFromEvent: function (a) {
        a = f(a).closest(".a-splitdropdown-container").find("select");
        a.length ||
          n.error("cannot locate the \x3cselect\x3e of the split dropdown");
        return a;
      },
    };
  });
  ("use strict");
  n.when("A").register("a-dropdown-split-utils", function (a) {
    return {
      triggerEvent: function (f, h, d) {
        h = {$select: h, value: d, id: f};
        a.trigger("a:splitdropdown:" + f + ":select", h);
        a.trigger("a:splitdropdown:select", h);
      },
    };
  });
  ("use strict");
  n.when(
    "A",
    "a-dropdown-base",
    "a-dropdown-split-options",
    "a-dropdown-split-utils",
    "a-dropdown-split-handlers",
    "a-analytics"
  ).register("a-splitdropdown", function (a, f, h, d, l, m) {
    var k = a.$,
      p = k(document);
    a.on("a:pageUpdate beforeReady", function () {
      if (
        (a.capabilities.mobile || a.capabilities.tablet) &&
        !a.capabilities.touchScrolling
      ) {
        p.find("select.a-native-splitdropdown")
          .removeAttr("tabindex")
          .removeAttr("aria-hidden");
        var d = p.find(".a-splitdropdown-container label.a-native-dropdown");
        a.each(d, function (a) {
          k(a).attr(
            "for",
            k(a).nextAll("select.a-native-splitdropdown").attr("id") || ""
          );
        });
      }
    });
    p.delegate(".a-native-splitdropdown", "change", function (a, e, b) {
      a = k(this);
      e = a.val();
      var c = a.attr("id");
      b || d.triggerEvent(c, a, e);
    }).delegate(
      ".a-button-splitdropdown:not(.a-button-disabled)",
      "focusin",
      function () {
        k(this).find(".a-button-text").focus();
      }
    );
    a.on("beforeReady a:pageUpdate a:ajax:complete", function () {
      var a = p.find(".a-button-group-splitdropdown .a-button-disabled");
      a.attr("aria-disabled") &&
        (m.count("splitdropdown:usage", a.length),
        a
          .removeAttr("aria-disabled")
          .find(".a-button-text")
          .attr("aria-disabled", !0)
          .removeAttr("role"));
    });
    return {
      getSelect: function (a) {
        return f.getSelect(a, h);
      },
    };
  });
  ("use strict");
  n.when("A", "a-popover-accessibility-templates").register(
    "a-popover-accessibility",
    function (a, f) {
      var h = f.startAnchorTemplate,
        d = f.startAnchorDeclarativeTemplate,
        l = f.endAnchorTemplate,
        m = f.descriptionTemplate,
        k = f.offscreenDescriptionTemplate,
        p = f.labelTemplate,
        g = f.offscreenStartTemplate,
        e = function (a, b) {
          var c = {"{{DESCRIPTION}}": b, "{{DESCRIPTION_ID}}": a};
          return m.replace(/\{\{[\w_]*\}\}/g, function (a) {
            return c[a];
          });
        },
        b = function (a) {
          var b = a.id,
            c = a.header_str;
          return (a = a.label_str)
            ? 'aria-label\x3d"' + a + '"'
            : c
            ? 'aria-labelledby\x3d"a-popover-header-' + b + '"'
            : "";
        },
        c = function (a, b) {
          var c = {"{{DESCRIPTION}}": b, "{{DESCRIPTION_ID}}": a};
          return k.replace(/\{\{[\w_]*\}\}/g, function (a) {
            return c[a];
          });
        };
      return {
        getAriaLabelledByDescribedby: function (a) {
          var b = a.id,
            c = a.header_str,
            d = a.aria_description,
            e = "";
          a.label_str
            ? (e = 'aria-labelledby\x3d"a-popover-label-' + b + '"')
            : c && (e = 'aria-labelledby\x3d"a-popover-header-' + b + '"');
          d &&
            (e +=
              ' aria-describedby\x3d"a-popover-aria-description-' + b + '"');
          return e;
        },
        getPopoverLabelHtml: function (a) {
          var b = "",
            c = a.id;
          if ((a = a.label_str)) {
            var d = {"{{LABEL}}": a, "{{LABEL_ID}}": "a-popover-label-" + c};
            b = p.replace(/\{\{[\w_]*\}\}/g, function (a) {
              return d[a];
            });
          }
          return b;
        },
        getStartAnchorHtml: function (c) {
          var g = c.id,
            k = c.label_str,
            f = c.aria_description,
            m = "";
          if (!g) return "";
          var q = {
            "{{ROLE}}": 'role\x3d"dialog"',
            "{{ANCHOR_NAME}}": "a-popover-start",
            "{{ARIA_LABEL}}": b(c),
            "{{LABEL_STR}}": k || "",
            "{{ARIA_DESCRIBEDBY}}": "",
          };
          c = c.needs_declarative ? d : h;
          f &&
            ((g = "a-popover-aria-description-" + g),
            (q["{{ARIA_DESCRIBEDBY}}"] = 'aria-describedby\x3d"' + g + '"'),
            (m = e(g, f)));
          a.capabilities.ios && (q["{{ROLE}}"] = "");
          c =
            c.replace(/\{\{[\w_]*\}\}/g, function (a) {
              return q[a];
            }) + m;
          return c.replace(/\s\s>|\s>/g, "\x3e");
        },
        getEndAnchorHtml: function (a) {
          return l;
        },
        getDescription: function (a) {
          var b = "",
            d = a.id;
          (a = a.aria_description) &&
            (b = c("a-popover-aria-description-" + d, a));
          return b;
        },
        getStartAnchorSimplifiedHtml: function () {
          return g;
        },
      };
    }
  );
  ("use strict");
  n.declare("a-popover-accessibility-templates", {
    startAnchorTemplate:
      '\x3cspan tabindex\x3d"0" {{ROLE}} class\x3d"{{ANCHOR_NAME}} a-popover-a11y-offscreen" {{ARIA_LABEL}} {{ARIA_DESCRIBEDBY}}\x3e{{LABEL_STR}}\x3c/span\x3e',
    startAnchorDeclarativeTemplate:
      '\x3cspan tabindex\x3d"0" {{ROLE}} data-action\x3d"a-popover-a11y" class\x3d"{{ANCHOR_NAME}} a-popover-a11y-offscreen a-declarative" {{ARIA_LABEL}} {{ARIA_DESCRIBEDBY}}\x3e{{LABEL_STR}}\x3c/span\x3e',
    endAnchorTemplate:
      '\x3cspan tabindex\x3d"0" class\x3d"a-popover-end a-popover-a11y-offscreen"\x3e\x3c/span\x3e',
    descriptionTemplate:
      '\x3cspan id\x3d"{{DESCRIPTION_ID}}" class\x3d"a-popover-a11y-offscreen"\x3e{{DESCRIPTION}}\x3c/span\x3e',
    offscreenDescriptionTemplate:
      '\x3cspan id\x3d"{{DESCRIPTION_ID}}" class\x3d"a-popover-a11y-offscreen" aria-hidden\x3d"true"\x3e{{DESCRIPTION}}\x3c/span\x3e',
    labelTemplate:
      '\x3cspan id\x3d"{{LABEL_ID}}" class\x3d"a-popover-a11y-offscreen" aria-hidden\x3d"true"\x3e{{LABEL}}\x3c/span\x3e',
    offscreenStartTemplate:
      '\x3cspan tabindex\x3d"0" class\x3d"a-popover-start a-popover-a11y-offscreen"\x3e\x3c/span\x3e',
  });
  ("use strict");
  n.when("A", "a-popover-util").register("a-popover-ajax", function (a, f) {
    return {
      update: function (a, d, f) {
        var h = {};
        h.url = d;
        f.timeout && (h.timeout = f.timeout);
        f.ajaxFailMsg && (h.ajaxFailMsg = f.ajaxFailMsg);
        f.cache && (h.cache = f.cache);
        a.update(h);
      },
      showSpinner: function (a) {
        return f.showSpinner(a);
      },
    };
  });
  ("use strict");
  n.when("A").register("a-popover-animate", function (a) {
    function f(d, f) {
      return function () {
        a[d].apply(a, f);
      };
    }
    function h(a, f) {
      return function () {
        a._isAnimating = !1;
        f && f();
      };
    }
    return {
      isAnimating: function (a) {
        return a._isAnimating;
      },
      animate: function (d, l, m, k, p) {
        d._isAnimating = 0 < m;
        a.animationFrameDelay(f("animate", [d.$popover, l, m, k, h(d, p)]));
      },
      fadeOut: function (d, l, m, k) {
        d._isAnimating = 0 < l;
        a.animationFrameDelay(f("fadeOut", [d.$popover, l, m, h(d, k)]));
      },
      fadeIn: function (d, l, m, k) {
        d._isAnimating = 0 < l;
        a.animationFrameDelay(f("fadeIn", [d.$popover, l, m, h(d, k)]));
      },
    };
  });
  n.declare("a-popover-lightbox-markup", {
    id: "a-popover-lgtbox",
    div: '\x3cdiv id\x3d"a-popover-lgtbox" class\x3d"a-declarative" data-action\x3d"a-popover-floating-close" /\x3e',
  });
  ("use strict");
  n.when("A", "ready").register("a-popover-navigate", function (a) {
    function f(a) {
      "string" === typeof a && ((m = !0), (u.location.hash = a));
      return u.location.hash || "";
    }
    var h = a.$;
    h = h(u);
    var d = [],
      l = [],
      m = !1,
      k = {},
      p = !1;
    l.push(f());
    h.bind("hashchange", function (d) {
      d.preventDefault();
      p ? (p = !1) : l.push(f());
      32 <= l.length && l.shift();
      m ? (m = !1) : a.trigger("a:popover:navigate", k[l[l.length - 1]]);
    });
    a.on("a:popover:navigate", function (a) {
      a
        ? a.show({preventNavigate: !0})
        : (a = 0 <= d.length - 1 ? d[d.length - 1] : null) &&
          a.unlock().hide({preventNavigate: !0});
    });
    a.on("a:popover:showNavigable a:popover:showNavigableLegacy", function (a) {
      d.push(a.popover);
    });
    a.on("a:popover:hideNavigable a:popover:hideNavigableLegacy", function (a) {
      d.pop();
    });
    return {
      forward: function (d) {
        var e = d.name + "_" + a.now();
        k["#" + e] = d;
        f(e);
      },
      back: function () {
        0 < l.length && l.pop();
        p = !0;
        u.history.back();
      },
    };
  });
  ("use strict");
  n.when("A", "prv:a-capabilities").register(
    "a-popover-position",
    function (a, f) {
      function h(b, c) {
        var d = a.viewport();
        if (1 === a.viewport().zoom) var f = {top: 0, left: 0};
        else
          p ||
            ((p = k(
              '\x3cspan id\x3d"a-popover-offset-tracker"\x3e\x3c/span\x3e'
            )),
            k("body").prepend(p)),
            (f = p.offset());
        var h = c.offset(),
          m = b.offset();
        if (e) {
          var l = u.pageYOffset - document.documentElement.scrollTop;
          h.top -= l;
          m.top -= l;
        }
        h.top -= f.top;
        h.left -= f.left;
        m.top -= f.top;
        m.left -= f.left;
        l = c[0].getBoundingClientRect();
        l = l.right - l.left;
        c = c.outerHeight();
        var n = b.outerWidth(!0),
          x = b.outerHeight(!0);
        b = b.find(".a-popover-header");
        b = b.length ? b.outerHeight(!0) : 0;
        return {
          windowWidth: d.width,
          windowHeight: d.height,
          windowTop: d.scrollTop,
          windowLeft: d.scrollLeft,
          windowRight: d.scrollLeft + d.width,
          windowBottom: d.scrollTop + d.height,
          zoomTop: f.top,
          zoomLeft: f.left,
          triggerWidth: l + 1,
          triggerHeight: c,
          triggerTop: h.top - g,
          triggerLeft: h.left - g,
          triggerRight: h.left + l + g,
          triggerBottom: h.top + c + g,
          triggerVerticalCenter: h.top + c / 2,
          triggerHorizontalCenter: h.left + l / 2,
          popoverWidth: n,
          popoverHeight: x,
          popoverTop: m.top,
          popoverLeft: m.left,
          popoverRight: m.left + n,
          popoverBottom: m.top + x,
          popoverVerticalCenter: m.top + x / 2,
          popoverHorizontalCenter: m.left + n / 2,
          headerHeight: b,
        };
      }
      function d(a) {
        return a.removeClass(
          "a-arrow-top a-arrow-bottom a-arrow-left a-arrow-right"
        );
      }
      function l(a) {
        var b = {deltaTop: 0};
        b.top = a.triggerVerticalCenter - a.popoverHeight / 2;
        if (b.top < a.windowTop + 20) {
          var d = Math.min(a.windowTop + 20, a.triggerTop - 20);
          b.deltaTop = b.top - d;
          b.top = d;
        } else
          b.top + a.popoverHeight > a.windowBottom - 20 &&
            ((d = Math.min(20, a.windowBottom - a.triggerBottom + 20)),
            (b.deltaTop = b.top + a.popoverHeight - (a.windowBottom - d)),
            (b.top = a.windowBottom - d - a.popoverHeight));
        return b;
      }
      function m(a) {
        var b = {deltaLeft: 0};
        b.left = a.triggerHorizontalCenter - a.popoverWidth / 2;
        if (20 > b.left) {
          var d = Math.min(20, a.triggerLeft - 20);
          b.deltaLeft = b.left - d;
          b.left = d;
        } else
          b.left + a.popoverWidth > a.windowRight - 20 &&
            ((d = Math.min(20, a.windowRight - a.triggerRight + 20)),
            (b.deltaLeft = b.left + a.popoverWidth - (a.windowRight - d)),
            (b.left = a.windowRight - d - a.popoverWidth));
        return b;
      }
      var k = a.$;
      k(u);
      var p = null,
        g = 1,
        e = a.capabilities.mobile && f.isIE10Plus;
      n.when("prv:skin-vars-desktop").execute(function (a) {
        g = a.popover.POPOVER_SPACING ? a.popover.POPOVER_SPACING : g;
      });
      return {
        windowCenter: function (a) {
          a = h(a.$popover, a.$trigger);
          var b = {};
          b.top = (a.windowHeight - a.popoverHeight) / 2;
          b.left = (a.windowWidth - a.popoverWidth) / 2;
          0 > b.top && (b.top = 0);
          return b;
        },
        windowTop: function (a) {
          a = h(a.$popover, a.$trigger);
          var b = {top: 0};
          b.left = a.windowWidth / 2 - a.popoverWidth / 2;
          return b;
        },
        windowFullWidth: function (a) {
          return {top: 0, left: 0};
        },
        triggerRight: function (a, c) {
          var b = a.$popover,
            e = a.$trigger;
          c || (c = h(b, e));
          e = l(c);
          e.left = c.triggerRight;
          a.attrs("popoverArrow") &&
            (d(b).addClass("a-arrow-right"),
            b
              .find(".a-arrow-border")
              .css("top", c.popoverHeight / 2 + e.deltaTop));
          return e;
        },
        triggerLeft: function (a, c) {
          var b = a.$popover,
            e = a.$trigger;
          c || (c = h(b, e));
          e = l(c);
          e.left = c.triggerLeft - c.popoverWidth;
          e.left = 0 < e.left ? e.left : 0;
          a.attrs("popoverArrow") &&
            (d(b).addClass("a-arrow-left"),
            b
              .find(".a-arrow-border")
              .css("top", c.popoverHeight / 2 + e.deltaTop));
          return e;
        },
        triggerTop: function (a, c) {
          var b = a.$popover,
            e = a.$trigger;
          c || (c = h(b, e));
          e = m(c);
          e.top = c.triggerTop - c.popoverHeight;
          a.attrs("popoverArrow") &&
            (d(b).addClass("a-arrow-top"),
            b
              .find(".a-arrow-border")
              .css("left", c.popoverWidth / 2 + e.deltaLeft));
          return e;
        },
        triggerBottom: function (a, c) {
          var b = a.$popover,
            e = a.$trigger;
          c || (c = h(b, e));
          e = m(c);
          e.top = c.triggerBottom;
          a.attrs("popoverArrow") &&
            (d(b).addClass("a-arrow-bottom"),
            b
              .find(".a-arrow-border")
              .css("left", c.popoverWidth / 2 + e.deltaLeft));
          return e;
        },
        triggerHorizontal: function (a, c) {
          var b = a.$popover,
            d = a.$trigger;
          c || (c = h(b, d));
          return c.triggerLeft - c.windowLeft > c.windowRight - c.triggerRight
            ? this.triggerLeft(a, c)
            : this.triggerRight(a, c);
        },
        triggerVertical: function (a, c) {
          var b = a.$popover,
            d = a.$trigger;
          c = c ? c : h(b, d);
          return c.triggerTop - c.windowTop > c.popoverHeight + 20
            ? this.triggerTop(a, c)
            : this.triggerBottom(a, c);
        },
        triggerVerticalAlignLeft: function (a, c) {
          var b = a.$popover,
            e = a.$trigger;
          c || (c = h(b, e));
          e = {};
          var g = 0,
            f = c.windowBottom - c.triggerBottom;
          e.left = c.triggerLeft;
          e.top =
            f > c.popoverHeight
              ? c.triggerBottom + 3
              : c.triggerTop - c.popoverHeight - 3;
          if (20 > e.left) {
            var k = Math.min(20, c.triggerLeft - 20);
            g = e.left - k;
            e.left = k;
          } else
            e.left + c.popoverWidth > c.windowRight - 20 &&
              ((k = Math.min(20, c.windowRight - c.triggerRight + 20)),
              (g = e.left + c.popoverWidth - (c.windowRight - k)),
              (e.left = c.windowRight - k - c.popoverWidth));
          a.attrs("popoverArrow") &&
            (d(b).addClass(
              f > c.popoverHeight ? "a-arrow-bottom" : "a-arrow-top"
            ),
            b.find(".a-arrow-border").css("left", c.triggerWidth / 2 + g));
          return e;
        },
        customPosition: function (a, c) {
          return c.call(this, {
            popover: a,
            $popover: a.$popover,
            $trigger: a.$trigger,
            measure: h,
          });
        },
      };
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-modal-view-base",
    "a-modal-positions",
    "a-popover-accessibility"
  ).register("a-modal-view", function (a, f, h, d) {
    var l = a.$;
    l = l("html").hasClass("a-lt-ie9");
    return a.extend(
      f,
      a.capabilities.touch ||
        a.capabilities.mobile ||
        a.capabilities.tablet ||
        l
        ? h.innerScroll
        : h.modalScroll,
      {
        skin: function (f) {
          var k = f.attrs("id"),
            h = f.attrs("header") || "",
            g = f.attrs("hideHeader") || !1,
            e = f.attrs("footer"),
            b = f.attrs("modeless") || !1,
            c = f.attrs("closeButton"),
            m = f.attrs("closeButtonLabel") || "",
            l = f.attrs("hideHeaderCloseButtonLayout") || "",
            n = f.attrs("popoverLabel") || "",
            v = f.attrs("padding");
          f = f.attrs("ariaDescription");
          f = {id: k, header_str: h, label_str: n, aria_description: f};
          n = d.getDescription(f);
          var y = d.getPopoverLabelHtml(f);
          c =
            '\x3cbutton data-action\x3d"a-popover-close" class\x3d"' +
            (c ? "" : " a-button-close-a11y") +
            " a-button-close a-declarative" +
            (g
              ? c
                ? "top" === l
                  ? " a-modal-close-nohead-top"
                  : " a-button-top-right"
                : " a-button-a11y-top-right"
              : "") +
            '" aria-label\x3d"' +
            m +
            '"\x3e\x3ci class\x3d"a-icon a-icon-close"\x3e\x3c/i\x3e\x3c/button\x3e';
          h =
            !g || y
              ? "\x3cheader" +
                (g ? "" : ' class\x3d"a-popover-header"') +
                "\x3e" +
                (g
                  ? ""
                  : '\x3ch4 class\x3d"a-popover-header-content' +
                    (b ? " a-popover-draggable-handle" : "") +
                    '" id\x3d"a-popover-header-' +
                    k +
                    '"\x3e' +
                    h +
                    "\x3c/h4\x3e") +
                c +
                y +
                "\x3c/header\x3e"
              : c;
          e = e
            ? '\x3cdiv class\x3d"a-popover-footer"\x3e' + e + "\x3c/div\x3e"
            : "";
          v = "none" === v ? " a-padding-none" : "";
          g = a.capabilities.isAndroid ? "" : d.getStartAnchorSimplifiedHtml();
          c = a.capabilities.isAndroid ? "" : d.getEndAnchorHtml(f);
          m = b
            ? ""
            : '\x3cdiv class\x3d"a-modal-scroller a-declarative" data-action\x3d"a-popover-floating-close"\x3e';
          f =
            '\x3cdiv class\x3d"a-popover a-popover-modal a-declarative' +
            (b ? " a-modal-modeless" : " ") +
            '" data-action\x3d"a-popover-a11y" aria-modal\x3d"true" role\x3d"dialog"' +
            d.getAriaLabelledByDescribedby(f) +
            "\x3e";
          return (
            m +
            f +
            g +
            n +
            '\x3cdiv class\x3d"a-popover-wrapper"\x3e' +
            h +
            ('\x3cdiv class\x3d"a-popover-inner' +
              v +
              '" id\x3d"a-popover-content-' +
              k +
              '"\x3e\x3c/div\x3e') +
            e +
            "\x3c/div\x3e" +
            c +
            "\x3c/div\x3e" +
            (b ? "" : "\x3c/div\x3e")
          );
        },
      }
    );
  });
  ("use strict");
  n.when(
    "A",
    "a-popover-lightbox",
    "a-popover-optional-helpers",
    "prv:a-capabilities"
  ).register("a-modal-positions", function (a, f, h, d) {
    function l(a) {
      var b = a.$popover.closest(".a-modal-scroller");
      b.scrollTop(0).css("visibility", "visible");
      b.bind("scroll", function () {
        a.updateChildrenPosition();
      });
    }
    function m() {
      var b = a.viewport();
      2 < b.width / b.height &&
        a.delay(function () {
          document.activeElement.scrollIntoView();
          u.scrollTo(u.pageXOffset, 0);
        }, 0);
    }
    function k(a, b, d) {
      if (0 > a)
        return d({"padding-right": b + "px", "box-sizing": "content-box"}), !0;
      d({"padding-right": "", "box-sizing": ""});
      return !1;
    }
    function p(a) {
      return function (b) {
        a.css(b);
      };
    }
    var g = a.$,
      e = d.isIE10Plus && a.capabilities.mobile,
      b = 0;
    n.when("prv:skin-vars").execute(function (a) {
      b = a.popover.optionalButtonHeight;
    });
    n.declare("prv:a-model-applyHorizonalScrollStyles", k);
    return {
      innerScroll: {
        positionStrategy: function (c) {
          var l = c.popover,
            n = c.$popover,
            t = c.$trigger,
            v = n.find(".a-popover-inner").css("height", "auto"),
            y = n.closest(".a-modal-scroller"),
            A = {},
            x = a.viewport(!0),
            w = 0.1 * x.height,
            z = 0.05 * x.width;
          x = 0.8 * x.height;
          var C = l.attrs("height");
          l = l.attrs("min-height");
          n.css({height: C ? C : "", "min-height": l ? l : ""});
          t = c.measure(n, t);
          A.left = (t.windowWidth - t.popoverWidth) / 2;
          k(A.left, z, p(n)) && (A.left = z);
          h.evaluateActualHeight(c, t.popoverHeight, b) > x
            ? ((l =
                n
                  .find(".a-popover-header, .a-modal-close-nohead-top")
                  .outerHeight(!0) || 0),
              (C = n.find(".a-popover-footer").outerHeight(!0) || 0),
              (c = h.getOffsetTopDelta(c, w, b)),
              (x -= c),
              (w += c),
              v.css({height: x - l - C + "px", "overflow-y": "auto"}),
              n.css({height: x, "min-height": 0}),
              (A.top = w))
            : ((A.top = (t.windowHeight - t.popoverHeight) / 2),
              v.css("height", "auto"));
          A.left += t.zoomLeft;
          A.top += t.zoomTop;
          e &&
            (y.css("top", g(u).scrollTop()),
            n.removeClass("a-popover-pan-y").addClass("a-popover-pan-x"),
            (n = g(document).height()),
            (v = g(document).width()),
            g("#" + f.LIGHTBOX_ID).css({
              height: n,
              width: v > t.popoverWidth ? v : t.popoverWidth + z,
            }));
          d.isMetroIEGuess && d.isIETouchCapable && m();
          return A;
        },
        beforeShowMethod: a.constants.NOOP,
        beforeHideMethod: a.constants.NOOP,
      },
      modalScroll: {
        positionStrategy: function (b) {
          var c = b.$popover,
            e = b.$trigger,
            f = c.closest(".a-modal-scroller"),
            g = c.find(".a-popover-inner").css("height", "auto");
          if (c.hasClass("a-popover-modal-fixed-height")) {
            var h = c.find(".a-popover-footer");
            g.css("padding-bottom", h.height() + 15);
          }
          g = {};
          var l = a.viewport(!0),
            n = l.height;
          h = 0.1 * n;
          l = 0.05 * l.width;
          n *= 0.8;
          var w = c.height(),
            u = c.width();
          b = b.measure(c, e);
          g.left = (b.windowWidth - u) / 2;
          g.top = (b.windowHeight - w) / 2;
          k(g.left, l, p(c)) && (g.left = l);
          w > n
            ? f.length
              ? ((g.top = 0),
                c.css({
                  position: "relative",
                  margin:
                    b.zoomTop +
                    h +
                    "px 0 " +
                    h +
                    "px " +
                    (b.zoomLeft + g.left) +
                    "px",
                }),
                (g.left = 0),
                f.css("padding-bottom", "1px"))
              : w > n && (g.top = padding)
            : f.length &&
              (c.css({position: "absolute", margin: "0px"}),
              f.css("padding-bottom", "0px"));
          g.left += b.zoomLeft;
          g.top += b.zoomTop;
          d.isMetroIEGuess && d.isIETouchCapable && m();
          return g;
        },
        beforeShowMethod: function () {
          l(this);
        },
        beforeHideMethod: function () {
          this.$popover
            .closest(".a-modal-scroller")
            .css("visibility", "hidden")
            .unbind("scroll");
        },
      },
      util: {
        determineMaximumInnerHeight: function (b) {
          var c = b.$popover;
          b = 0.8 * a.viewport().height;
          var d =
            c
              .find(".a-popover-header, .a-modal-close-nohead-top")
              .outerHeight(!0) || 0;
          c = c.find(".a-popover-footer").outerHeight(!0) || 0;
          return b - d - c;
        },
        determineInnerVerticalPadding: function (a) {
          a = a.$popover.find(".a-popover-inner");
          return a.outerHeight() - a.height();
        },
      },
    };
  });
  ("use strict");
  n.when(
    "A",
    "a-popover-base-factory",
    "a-modal-view",
    "a-popover-util",
    "prv:a-capabilities"
  ).register("a-modal-factory", function (a, f, h, d, l) {
    function m(g, e) {
      var b = !1,
        c = !1;
      a.capabilities.mobile ||
        a.capabilities.tablet ||
        ((b = d.getBool(e.modeless)), (c = d.getBool(e.draggable)));
      e = {
        modeless: b,
        draggable: c,
        type: "modal",
        alone: !0,
        immersive: !0,
        position: "windowCenter",
        header: e.header,
        hideHeader: e.hideHeader,
        footer: e.footer,
        padding: e.padding,
        width: e.width,
        height: e.height,
        "max-width": e["max-width"],
        "max-height": e["max-height"],
        "min-width": e["min-width"],
        "min-height": e["min-height"],
        closeButton: d.getBool(e.closeButton, !0),
        timeout: e.timeout,
        lightboxOptions: b
          ? B
          : {lockScroll: !0, showDuration: k || p ? 0 : null},
        data: e.data || {},
        dataStrategy: e.dataStrategy,
        url: e.url,
        manualRefresh: !!e.manualRefresh,
        ajaxFailMsg: e.ajaxFailMsg,
        cache: d.getBool(e.cache, !0),
        inlineContent: e.inlineContent ? e.inlineContent : e.content,
        name: e.name,
        closeButtonLabel: e.closeButtonLabel ? e.closeButtonLabel : "Close",
        hideHeaderCloseButtonLayout: e.hideHeaderCloseButtonLayout,
        popoverLabel: e.popoverLabel,
        ariaDescription: e.ariaDescription,
        ajaxHeaders: e.ajaxHeaders,
        withCredentials: d.getBool(e.withCredentials, !1),
        legacyNavigable: d.getBool(e.legacyNavigable, !0),
      };
      return f.create(g, {
        attributes: e,
        typeSpecificFunctions: h,
        actionCheck: !0,
      });
    }
    var k = -1 < document.documentElement.className.indexOf("a-lt-ie9"),
      p = a.capabilities.mobile && l.isIE10Plus;
    return {
      type: "modal",
      create: m,
      get: function (a) {
        var e = f.get(a, "modal");
        e ||
          "object" !== typeof a ||
          ((a = d.extractDeclarativeParams(a, "modal")) &&
            (e = m(a.$trigger, a.attributes || {})));
        return e;
      },
      remove: function (a) {
        return f.remove(a, "modal");
      },
    };
  });
  ("use strict");
  n.when("A", "a-modal-factory", "a-popover-base", "a-modal-handlers").register(
    "a-modal",
    function (a, f) {
      return f;
    }
  );
  ("use strict");
  n.when("A", "a-popover-util", "a-popover-animate").register(
    "a-popover-view-base",
    function (a, f, h) {
      return {
        setAriaBusy: function (a) {
          this.$popover.find(".a-popover-wrapper").attr("aria-busy", a);
        },
        updateContent: function (a) {
          "string" === typeof a
            ? this.$popover.find(".a-popover-content").html(a)
            : a && this.$popover.find(".a-popover-content").html("").append(a);
        },
        updateDimensions: function () {
          this.$popover.css(f.getCSSHash(this.attrs()));
          this.isActive() && this.updatePosition();
          return this;
        },
        getContent: function () {
          return this.$popover
            ? this.$popover.find(".a-popover-content")
            : null;
        },
        hideMethod: function (a) {
          var d = this;
          h.fadeOut(d, 250, "linear", function () {
            d.$popover.css({top: "auto", left: "auto"});
            a.call(d);
          });
        },
      };
    }
  );
  n.when("a-util").register("a-popover-optional-helpers", function (a) {
    return {
      getOffsetTopDelta: function (f, h, d) {
        d = parseFloat(d);
        var l = a.isFiniteNumber(d) && 0 < d;
        f =
          f.$popover.find(".a-button-close").length &&
          !f.$popover.find(".a-button-close-a11y").length;
        return l && f && 0 > h - d ? d - h : 0;
      },
      evaluateActualHeight: function (a, h, d) {
        return a.$popover.find(".a-button-close").length &&
          !a.$popover.find(".a-button-close-a11y").length
          ? h + d
          : h;
      },
    };
  });
  ("use strict");
  n.when(
    "A",
    "a-popover-view-base",
    "a-popover-util",
    "a-popover-accessibility"
  ).register("a-popover-view", function (a, f, h, d) {
    var l = !0;
    n.when("prv:skin-vars").execute(function (a) {
      l = a.popover.closeButtonEnabled;
    });
    return a.extend(f, {
      skin: function (f) {
        var h = f.attrs("id"),
          m = f.attrs("header"),
          g = l && f.attrs("closeButton"),
          e = f.attrs("closeButtonLabel") || "",
          b = f.attrs("popoverLabel") || "",
          c = f.attrs("ariaDescription"),
          n = f.attrs("padding");
        f = f.attrs("popoverArrow");
        c = {id: h, header_str: m, label_str: b, aria_description: c};
        a.capabilities.isAndroid && (e = (b || m) + " " + e);
        g =
          '\x3cbutton data-action\x3d"a-popover-close" class\x3d"a-button-close ' +
          (g ? "" : "a-button-close-a11y") +
          ' a-declarative" aria-label\x3d"' +
          e +
          '"\x3e\x3ci class\x3d"a-icon a-icon-close"\x3e\x3c/i\x3e\x3c/button\x3e';
        var r = (e = !!m) ? "a-popover-has-header" : "a-popover-no-header";
        n = "none" === n ? " a-padding-none" : "";
        f = f
          ? '\x3cdiv class\x3d"a-arrow-border"\x3e\x3cdiv class\x3d"a-arrow"\x3e\x3c/div\x3e\x3c/div\x3e'
          : "";
        b = a.capabilities.isAndroid ? "" : d.getStartAnchorSimplifiedHtml();
        var t = a.capabilities.isAndroid ? "" : d.getEndAnchorHtml(c);
        m = m
          ? '\x3ch4 class\x3d"a-popover-header-content" id\x3d"a-popover-header-' +
            h +
            '"\x3e' +
            m +
            "\x3c/h4\x3e"
          : "";
        r =
          '\x3cdiv class\x3d"a-popover ' +
          r +
          ' a-declarative" data-action\x3d"a-popover-container a-popover-a11y" aria-modal\x3d"true" role\x3d"dialog"' +
          d.getAriaLabelledByDescribedby(c) +
          "\x3e";
        var v = d.getDescription(c);
        c = d.getPopoverLabelHtml(c);
        return (
          r +
          b +
          v +
          '\x3cdiv class\x3d"a-popover-wrapper"\x3e' +
          (e
            ? '\x3cheader class\x3d"a-popover-header"\x3e' +
              m +
              g +
              c +
              "\x3c/header\x3e"
            : "") +
          ('\x3cdiv class\x3d"a-popover-inner' + n + '"\x3e') +
          (e ? "" : c ? "\x3cheader\x3e" + g + c + "\x3c/header\x3e" : g) +
          ('\x3cdiv class\x3d"a-popover-content" id\x3d"a-popover-content-' +
            h +
            '"\x3e\x3c/div\x3e') +
          "\x3c/div\x3e" +
          f +
          "\x3c/div\x3e" +
          t +
          "\x3c/div\x3e"
        );
      },
    });
  });
  ("use strict");
  n.when(
    "A",
    "a-popover-base-factory",
    "a-popover-view",
    "a-popover-util"
  ).register("a-popover-factory", function (a, f, h, d) {
    function l(a, k) {
      k = {
        type: "popover",
        alone: !0,
        header: k.header,
        width: k.width,
        height: k.height,
        "max-width": k["max-width"],
        "max-height": k["max-height"],
        "min-width": k["min-width"],
        "min-height": k["min-height"],
        padding: k.padding,
        closeButton: d.getBool(k.closeButton, !0),
        position: k.position || "triggerVertical",
        activate: k.activate || "onmouseover",
        timeout: k.timeout,
        data: k.data || {},
        dataStrategy: k.dataStrategy,
        url: k.url,
        manualRefresh: !!k.manualRefresh,
        ajaxFailMsg: k.ajaxFailMsg,
        cache: d.getBool(k.cache, !0),
        inlineContent: k.inlineContent ? k.inlineContent : k.content,
        name: k.name,
        closeButtonLabel: k.closeButtonLabel ? k.closeButtonLabel : "Close",
        popoverLabel: k.popoverLabel,
        ariaDescription: k.ariaDescription,
        focusWhenShown: d.getBool(k.focusWhenShown, !0),
        popoverArrow: d.getBool(k.popoverArrow, !0),
        restoreFocusOnHide: d.getBool(k.restoreFocusOnHide, !0),
      };
      return f.create(a, {
        attributes: k,
        typeSpecificFunctions: h,
        actionCheck: !0,
      });
    }
    return {
      type: "popover",
      create: l,
      get: function (a) {
        var h = f.get(a, "popover");
        h ||
          "object" !== typeof a ||
          ((a = d.extractDeclarativeParams(a, "popover")) &&
            (h = l(a.$trigger, a.attributes || {})));
        return h;
      },
      remove: function (a) {
        return f.remove(a, "popover");
      },
    };
  });
  ("use strict");
  n.when("A", "a-popover-factory").register(
    "a-popover-handlers",
    function (a, f) {
      a.declarative("a-popover", "click", function (a) {
        f.get(a.$declarativeParent).show();
        a.$event.preventDefault();
      });
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-popover-factory",
    "a-popover-base",
    "a-popover-handlers"
  ).register("a-popover", function (a, f) {
    return f;
  });
  ("use strict");
  n.when(
    "A",
    "a-popover-util",
    "a-popover-navigate",
    "a-touch",
    "a-detect",
    "a-popover-accessibility",
    "prv:a-capabilities"
  ).register("a-secondary-view-view", function (a, f, h, d, l, m, k) {
    function p() {
      v.show();
      a.delay(function () {
        v.css("opacity", 1);
      }, 0);
    }
    function g(b) {
      a.delay(function () {
        v.css("opacity", 0);
      }, 0);
      a.delay(function () {
        v.hide();
      }, b);
    }
    function e() {
      c.unbind(t);
      c.bind(t, function (a) {
        0 === b(a.target).closest("a").length && a.preventDefault();
      });
    }
    var b = a.$,
      c = b(u),
      n = b("body"),
      r = b("#a-page"),
      t =
        l.action.start +
        ".a-secondary-view " +
        l.action.move +
        ".a-secondary-view " +
        l.action.end +
        ".a-secondary-view",
      v = b("\x3cdiv id\x3d'a-white'/\x3e");
    n.append(v);
    v.bind(
      l.action.start + " " + l.action.move + " " + l.action.end + " click",
      function (a) {
        a.stopImmediatePropagation();
        a.preventDefault();
      }
    );
    return {
      skin: function (b) {
        var c = b.attrs("id"),
          d = b.attrs("hideHeader"),
          e = b.attrs("header"),
          f = b.attrs("backButtonText") || "Back",
          g = b.attrs("alternateBackground"),
          h = b.attrs("popoverLabel") || "",
          k = b.attrs("padding");
        b = b.attrs("ariaDescription");
        var l = {id: c, header_str: e, label_str: h, aria_description: b};
        h = e
          ? '\x3cdiv class\x3d"a-span8 a-column a-span-last a-text-right"\x3e\x3ch4 id\x3d"a-popover-header-' +
            c +
            '"\x3e' +
            e +
            "\x3c/h4\x3e\x3c/div\x3e"
          : "";
        b = a.capabilities.isAndroid ? "" : m.getStartAnchorSimplifiedHtml();
        var p = a.capabilities.isAndroid ? "" : m.getEndAnchorHtml(l),
          n = m.getDescription(l),
          r = m.getPopoverLabelHtml(l);
        k = "none" === k ? " a-padding-none" : "";
        l =
          '\x3cdiv class\x3d"a-popover a-popover-secondary a-declarative" aria-modal\x3d"true" data-action\x3d"a-popover-a11y" role\x3d"dialog"' +
          m.getAriaLabelledByDescribedby(l) +
          "\x3e";
        var q = (!d && e) || r ? "header" : "div";
        return (
          l +
          b +
          n +
          '\x3cdiv class\x3d"a-popover-wrapper"\x3e' +
          ("\x3c" +
            q +
            ' class\x3d"' +
            (d
              ? "a-popover-no-header a-popover-a11y-offscreen"
              : "a-popover-header-secondary") +
            '"\x3e\x3cdiv class\x3d"a-row"\x3e' +
            ('\x3cdiv class\x3d"' +
              (e ? "a-span4" : "a-span12 a-span-last") +
              ' a-column"\x3e\x3ca class\x3d"a-declarative" data-action\x3d"a-popover-close" href\x3d"#"\x3e\x3ci class\x3d"a-icon a-icon-page-back"\x3e\x3c/i\x3e\x3ch4\x3e' +
              f +
              "\x3c/h4\x3e\x3c/a\x3e\x3c/div\x3e") +
            r +
            h +
            "\x3c/div\x3e" +
            ("\x3c/" + q + "\x3e")) +
          ('\x3cdiv class\x3d"a-popover-inner' +
            (g ? " a-color-alternate-background" : "") +
            '"\x3e\x3cdiv class\x3d"a-popover-header-spacing' +
            (d ? " a-popover-no-header" : "") +
            '"\x3e\x3c/div\x3e\x3cdiv class\x3d"a-container a-secondary-view-inner' +
            k +
            '" id\x3d"a-popover-content-' +
            c +
            '"\x3e\x3c/div\x3e\x3c/div\x3e') +
          "\x3c/div\x3e" +
          p +
          "\x3c/div\x3e"
        );
      },
      setAriaBusy: function (a) {
        this.$popover.find(".a-popover-wrapper").attr("aria-busy", a);
      },
      updateContent: function (a) {
        var d = this;
        if (d.attrs("animating"))
          var e = setInterval(function () {
            d.attrs("animating") || (clearInterval(e), c.scrollTop(1));
          }, 50);
        var f = b(".a-secondary-view-inner", d.$popover);
        "string" === typeof a ? f.html(a) : a && f.html("").append(a);
      },
      getContent: function () {
        return this.$popover
          ? this.$popover.find(".a-secondary-view-inner")
          : null;
      },
      beforeShowMethod: function (a) {
        a = a && a.preventNavigate ? a.preventNavigate : !1;
        this.attrs("navigate", this.name && !a);
      },
      showMethod: function (b) {
        function k() {
          function d() {
            f.trigger("afterSlide", l);
            b.call(l);
          }
          v && h.forward(l);
          f.trigger("showNavigable", l);
          a.delay(function () {
            c.scrollTop(1);
          }, 0);
          m.show().css("visibility", "visible").removeClass("a-popover-hidden");
          l.focus();
          r.hide();
          q || g(n);
          q ? d() : a.delay(d, n);
        }
        var l = this,
          m = l.$popover,
          n = l.attrs("animationLength"),
          q = l.attrs("synchronous") || l.attrs("disableAnimation"),
          t = l.attrs("scrollable"),
          v = l.attrs("navigate"),
          u = function () {
            var b = a.viewport();
            m.width(b.width);
            m.css("min-height", b.height);
            m.find(".a-popover-wrapper, .a-popover-inner").css(
              "min-height",
              b.height
            );
          };
        l.attrs("resizeHandle", a.on("resize", u));
        u();
        d.pauseTouchEvents(n);
        f.trigger("beforeSlide", l);
        t || e();
        q || p();
        "none" !== r.css("display") && l.attrs("scrollTop", c.scrollTop());
        q ? k() : a.delay(k, n + 50);
      },
      beforeHideMethod: function (a) {
        a = a && a.preventNavigate ? a.preventNavigate : !1;
        this.attrs("navigate", this.name && !a);
      },
      hideMethod: function (b) {
        function e() {
          function d() {
            f.trigger("afterSlideOut", l);
            m.hide().css("visibility", "hidden");
            b.call(l);
          }
          v && h.back();
          f.trigger("hideNavigable", l);
          y || r.show();
          m.hide().css("visibility", "hidden");
          q || g(n);
          a.delay(function () {
            c.scrollTop(u);
          }, B);
          q ? d() : a.delay(d, n);
        }
        var l = this,
          m = l.$popover,
          n = l.attrs("animationLength"),
          q = l.attrs("disableAnimation"),
          u = l.attrs("scrollTop"),
          v = l.attrs("navigate"),
          y = !1,
          B = k.isIE10 ? 200 : 0;
        a.each(l.parent.children, function (a) {
          y = y || (a.type === l.type && a.isVisible());
        });
        d.pauseTouchEvents(l.animationLength);
        a.off("resize", l.attrs("resizeHandle"));
        y || c.unbind(t);
        f.trigger("beforeSlideOut", l);
        q || p();
        q ? e() : a.delay(e, n + 50);
      },
      updatePosition: function () {},
    };
  });
  ("use strict");
  n.when(
    "A",
    "a-popover-base-factory",
    "a-secondary-view-view",
    "a-popover-util"
  ).register("a-secondary-view-factory", function (a, f, h, d) {
    function l(l, g) {
      g.disableAnimation = g.disableAnimation || a.capabilities.isOldAndroid;
      g = {
        type: "secondary-view",
        immersive: !0,
        disableAnimation: k || g.disableAnimation,
        synchronous: !!(k || (g.synchronous && "false" !== g.synchronous)),
        animationLength: g.disableAnimation ? 0 : 300,
        alternateBackground: g.alternateBackground || !1,
        hideHeader: k || g.hideHeader || !1,
        scrollable: g.scrollable || !0,
        header: g.header,
        backButtonText: g.backButtonText,
        position: "windowFullWidth",
        timeout: g.timeout,
        dataStrategy: g.dataStrategy,
        inlineContent: g.inlineContent ? g.inlineContent : g.content,
        url: g.url,
        manualRefresh: !!g.manualRefresh,
        name: g.name,
        cache: "false" === g.cache || !1 === g.cache ? !1 : !0,
        data: g.data || {},
        popoverLabel: g.popoverLabel,
        padding: g.padding,
        ariaDescription: g.ariaDescription,
        historyApi: "true" === g.historyApi || !0 === g.historyApi,
        withCredentials: d.getBool(g.withCredentials, !1),
        ajaxFailMsg: g.ajaxFailMsg,
      };
      return f.create(l, {
        attributes: g,
        typeSpecificFunctions: h,
        actionCheck: !0,
      });
    }
    var m = a.$,
      k = !1;
    n.when("mash-will-load").execute(function () {
      k = !0;
    });
    return {
      type: "secondary-view",
      create: l,
      get: function (a) {
        var g = f.get(a, "secondary-view");
        if (!g && "object" === typeof a) {
          var e = d.extractDeclarativeParams(a, "secondary-view");
          e && (g = l(e.$trigger, e.attributes || {}));
        }
        g &&
          "object" === typeof a &&
          ((a = m(a)),
          (a = (a = a.hasClass("a-declarative")
            ? a
            : a.find(".a-declarative").eq(0))
            ? a.data("a-secondary-view")
            : null),
          (g.data = a.data));
        return g;
      },
      remove: function (a) {
        return f.remove(a, "secondary-view");
      },
    };
  });
  ("use strict");
  n.when("A", "a-secondary-view-factory", "a-popover-util").register(
    "a-secondary-view-handlers",
    function (a, f, h) {
      var d = !1,
        l = null;
      n.when("mash-will-load").execute(function () {
        d = !0;
      });
      n.when("mash").execute(function (a) {
        l = a;
      });
      var m = function (a) {
        var d = f.get(a.$declarativeParent);
        l &&
          l.navigate &&
          l.navigate({
            successCallback: function () {
              d.show({preventNavigate: !1});
            },
          });
      };
      a.declarative("a-secondary-view", "click", function (a) {
        d ? m(a) : f.get(a.$declarativeParent).show();
        a.$event.preventDefault();
      });
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-secondary-view-factory",
    "a-popover-base",
    "a-secondary-view-handlers"
  ).register("a-secondary-view", function (a, f) {
    return f;
  });
  ("use strict");
  n.when("A", "a-popover-animate").register(
    "a-tooltip-view-base",
    function (a, f) {
      return {
        updateContent: function (a) {
          this.$popover.find(".a-tooltip-inner").html(a);
        },
        getContent: function () {
          return this.$popover ? this.$popover.find(".a-tooltip-inner") : null;
        },
        hideMethod: function (a) {
          var d = this;
          f.fadeOut(d, 250, "linear", function () {
            a.call(d);
          });
        },
      };
    }
  );
  ("use strict");
  n.when("A", "a-tooltip-view-base").register(
    "a-tooltip-view",
    function (a, f) {
      return a.extend(f, {
        skin: function (a) {
          return [
            '\x3cdiv role\x3d"tooltip" class\x3d"a-popover a-tooltip a-declarative" data-action\x3d"a-popover-close"\x3e\x3cdiv class\x3d"a-tooltip-inner"\x3e\x3c/div\x3e',
            a.attrs("popoverArrow")
              ? '\x3cdiv class\x3d"a-arrow-border"\x3e\x3cdiv class\x3d"a-arrow"\x3e\x3c/div\x3e\x3c/div\x3e'
              : "",
            "\x3c/div\x3e",
          ].join("");
        },
      });
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-popover-base-factory",
    "a-tooltip-view",
    "a-popover-util"
  ).register("a-tooltip-factory", function (a, f, h, d) {
    function l(a, k) {
      k = {
        type: "tooltip",
        name: k.name,
        inlineContent: k.inlineContent ? k.inlineContent : k.content,
        position: k.position || "triggerVertical",
        activate: k.activate || "onmouseover",
        popoverArrow: d.getBool(k.popoverArrow, !0),
        restoreFocusOnHide: !1,
      };
      k = f.create(a, {
        attributes: k,
        typeSpecificFunctions: h,
        actionCheck: !0,
      });
      a.add(a.children())
        .filter("a, input")
        .attr("aria-describedby", "a-popover-" + a.data("a-popover-id"));
      return k;
    }
    return {
      type: "tooltip",
      create: l,
      get: function (a) {
        var h = f.get(a, "tooltip");
        h ||
          "object" !== typeof a ||
          ((a = d.extractDeclarativeParams(a, "tooltip")) &&
            (h = l(a.$trigger, a.attributes || {})));
        return h;
      },
      remove: function (a) {
        return f.remove(a, "tooltip");
      },
    };
  });
  ("use strict");
  n.when("A", "a-tooltip-factory").register(
    "a-tooltip-handlers",
    function (a, f) {
      a.declarative("a-tooltip", "click", function (a) {
        f.get(a.$declarativeParent).show();
        a.$target.is("input, button") || a.$event.preventDefault();
      });
      a.declarative("a-tooltip", "focus focusin", function (a) {
        (a = f.get(a.$declarativeParent)) && a.show();
      });
      a.declarative("a-tooltip", "blur focusout", function (a) {
        (a = f.get(a.$declarativeParent)) && a.hide();
      });
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-tooltip-factory",
    "a-popover-base",
    "a-tooltip-handlers"
  ).register("a-tooltip", function (a, f) {
    return f;
  });
});
/* ******** */
(function (d) {
  var f = window.AmazonUIPageJS || window.P,
    c = f._namespace || f.attributeErrors,
    e = c ? c("AmazonUIPopover@modal", "AmazonUI") : f;
  e.guardFatal
    ? e.guardFatal(d)(e, window)
    : e.execute(function () {
        d(e, window);
      });
})(function (d, f, c) {
  d.when("A", "a-popover-util", "a-popover-animate").register(
    "a-modal-view-base",
    function (e, d, f) {
      var c = e.$,
        g = c("html").hasClass("a-lt-ie9");
      return {
        setAriaBusy: function (b) {
          this.$popover.find(".a-popover-wrapper").attr("aria-busy", b);
        },
        updateContent: function (b) {
          "string" === typeof b
            ? this.$popover.find(".a-popover-inner").html(b)
            : b && this.$popover.find(".a-popover-inner").html("").append(b);
        },
        updateDimensions: function () {
          var b = this.$popover,
            a = d.getCSSHash(this.attrs());
          !this.draggable ||
            (a.width && "auto" !== a.width) ||
            (a.width = b.width() + "px");
          b.css(a);
          a.height
            ? b.addClass("a-popover-modal-fixed-height")
            : b.removeClass("a-popover-modal-fixed-height");
          this.isActive() && this.updatePosition();
          return this;
        },
        getContent: function () {
          return this.$popover ? this.$popover.find(".a-popover-inner") : null;
        },
        showMethod: function (b) {
          var a = this,
            c = a.$popover;
          c.css({visibility: "visible"}).removeClass("a-popover-hidden");
          g || "ajax" === a.attrs("currentDataStrategy")
            ? b.call(a)
            : (c.css({opacity: 0, transform: "translateY(8px)"}),
              f.animate(
                a,
                {opacity: 1, transform: "translateY(0)"},
                200,
                "linear",
                function () {
                  b.call(a);
                }
              ));
          e.animationFrameDelay(function () {
            a.focus();
          });
          a.attrs("legacyNavigable") && d.trigger("showNavigableLegacy", a);
        },
        hideMethod: function (b) {
          var a = this,
            c = a.$popover;
          g
            ? (c
                .hide()
                .css("visibility", "hidden")
                .find(".a-lgtbox-vertical-scroll")
                .removeClass("a-lgtbox-vertical-scroll"),
              b.call(a))
            : f.animate(
                a,
                {opacity: 0, transform: "translateY(8px)"},
                100,
                "linear",
                function () {
                  c.hide().css({visibility: "hidden", opacity: 1});
                  b.call(a);
                }
              );
          a.attrs("legacyNavigable") && d.trigger("hideNavigableLegacy", a);
        },
      };
    }
  );
});
/* ******** */
(function (n) {
  var r = window.AmazonUIPageJS || window.P,
    w = r._namespace || r.attributeErrors,
    a = w ? w("AmazonUIPopover@ready-treatment", "AmazonUI") : r;
  a.guardFatal
    ? a.guardFatal(n)(a, window)
    : a.execute(function () {
        n(a, window);
      });
})(function (n, r, w) {
  n.when("A", "a-popover-util").register(
    "a-popover-ajax-strategy",
    function (a, g) {
      return {
        name: "ajax",
        reusePopover: !1,
        loadContent: function (b, m) {
          b.setContentLoading();
          var d = b.attrs("url"),
            f = b.attrs("ajaxHeaders") || {},
            e = b.attrs("withCredentials") || !1,
            k = b.attrs("timeout") || 1e4,
            h = b.attrs("ajaxFailMsg") || g.defaultContentFailureMessage,
            p = !!b.attrs("cache"),
            q = b.attrs("spinnerTimer"),
            c = b.attrs("ajaxHandler"),
            z = b.attrs("content");
          b.attrs("content", null);
          if (z && !m)
            b.updateContent(z), q && clearTimeout(q), c && c.abort && c.abort();
          else {
            q = a.delay(function () {
              g.shouldPopoverUpdateContent(b, "ajax") &&
                (g.showSpinner(b), b.setAriaBusy(!0));
            }, 100);
            var l = function (c, d, l) {
              g.shouldPopoverUpdateContent(b, "ajax") &&
                (clearTimeout(q),
                b.setContentLoaded(),
                g.trigger(d, b),
                b.setAriaBusy(!1),
                b.update({content: c}),
                b.isActive() && b.updatePosition(),
                l && g.trigger("ajaxContentLoaded", b));
            };
            c = a.ajax(d, {
              type: "GET",
              timeout: k,
              cache: p,
              headers: f,
              withCredentials: e,
              success: function (c) {
                l(c, "ajaxSuccess", !0);
              },
              error: function () {
                l(h, "ajaxFail", !1);
              },
            });
            b.attrs({spinnerTimer: q, ajaxHandler: c});
          }
          return this;
        },
        unloadContent: function (b) {
          g.clearContent(b);
          return this;
        },
        shouldRefreshContent: function (b) {
          return !b.attrs("manualRefresh");
        },
        isValidStrategy: function (b) {
          return !!b.url;
        },
      };
    }
  );
  ("use strict");
  n.when("A", "a-popover-util").register(
    "a-popover-inline-strategy",
    function (a, g) {
      return {
        name: "inline",
        reusePopover: !1,
        loadContent: function (b) {
          b.setContentLoading();
          var a = b.attrs("content");
          a && b.attrs("content", null);
          if (!a) {
            a = b.$trigger;
            var d = a.data("action");
            a = a.data(d) || {};
            a = a.inlineContent ? a.inlineContent : null;
          }
          a || (a = b.attrs("inlineContent"));
          b.updateContent(a);
          b.setContentLoaded();
          return this;
        },
        unloadContent: function (b) {
          var a = b.getContent();
          a = a && 0 < a.length ? a.html() : b.attrs("inlineContent");
          var d = b.$trigger,
            f = d.data("action"),
            e = d.data(f) || {};
          e.inlineContent = a;
          d.data(f, e);
          g.clearContent(b);
          return this;
        },
        shouldRefreshContent: function (a) {
          return a.isDirty();
        },
        isValidStrategy: function (a) {
          return !!a.inlineContent;
        },
      };
    }
  );
  ("use strict");
  n.when("A", "a-popover-util", "a-dom-poller", "a-analytics").register(
    "a-popover-preload-strategy",
    function (a, g, b, m) {
      function d(c) {
        return "a-popover-" + c;
      }
      function f(c) {
        c = q("#" + d(c));
        return c.length ? c : p;
      }
      function e(c) {
        if ((c = f(c))) {
          c.detach();
          c = c[0];
          for (var a = document.createDocumentFragment(); c.firstChild; )
            a.appendChild(c.firstChild);
          return a;
        }
        return !1;
      }
      function k(c, a) {
        c.updateContent(a);
        c.setContentLoaded();
        c.setAriaBusy(!1);
        g.trigger("contentReady", c);
      }
      function h(c, a) {
        g.showSpinner(c);
        c.setAriaBusy(!0);
        b.waitFor(
          "#" + d(a),
          function () {
            if (g.shouldPopoverUpdateContent(c, "preload")) {
              var d = e(a);
              k(c, d);
              c.isActive() && c.updatePosition();
            }
          },
          function () {
            m.logError(
              "Failed to find preloaded content for popover.",
              "FATAL",
              "Popover: " + a
            );
            var d = {content: g.defaultContentFailureMessage};
            g.shouldPopoverUpdateContent(c, "preload")
              ? (c.updateContent(g.defaultContentFailureMessage),
                c.setContentLoaded(),
                c.setAriaBusy(!1),
                c.isActive() && c.updatePosition(),
                (d.seenByUser = !0))
              : (d.seenByUser = !1);
            c.attrs("temporaryError", d);
          }
        );
      }
      var p,
        q = a.$;
      return {
        name: "preload",
        reusePopover: !0,
        loadContent: function (c) {
          c.setContentLoading();
          var a = c.attrs("name"),
            l = c.attrs("content");
          c.attrs("content", null);
          var f = c.attrs("temporaryError");
          if (f)
            if (!f.seenByUser) {
              var p = f.content;
              f.seenByUser = !0;
            } else if (f.seenByUser)
              return c.attrs("temporaryError", null), h(c, a), this;
          f = e(a);
          l || p
            ? (c.updateContent(l || p),
              c.setContentLoaded(),
              b.stopPollingSelector("#" + d(a)))
            : a
            ? f
              ? (k(c, f), b.stopPollingSelector("#" + d(a)))
              : b.isPollingSelector("#" + d(a))
              ? g.showSpinner(c)
              : h(c, a)
            : c.setContentLoaded();
          return this;
        },
        unloadContent: function (c) {
          var e = c.attrs("name");
          if (
            e &&
            !b.isPollingSelector("#" + d(e)) &&
            !c.attrs("temporaryError")
          ) {
            var l = c.getContent();
            if (l && l.html()) {
              var h = f(e);
              h
                ? (h = h[0])
                : ((h = document.createElement("div")),
                  (h.id = d(e)),
                  (h.className = "a-popover-preload"),
                  document.body.appendChild(h));
              e = h;
              if (!a.trim(e.innerHTML))
                if (((l = l[0]), "string" === typeof l)) q(e).html(l);
                else {
                  for (h = document.createDocumentFragment(); l.firstChild; )
                    h.appendChild(l.firstChild);
                  e.appendChild(h);
                }
              g.clearContent(c);
            }
          }
          return this;
        },
        shouldRefreshContent: function (a) {
          var c = a.attrs("name"),
            e = f(c);
          return (
            !(!e || "" === e.html()) ||
            a.attrs("temporaryError") ||
            b.isPollingSelector("#" + d(c))
          );
        },
        isValidStrategy: function (a) {
          return !!a.name;
        },
      };
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-dropdown-base",
    "a-dropdown-view",
    "a-dropdown-options",
    "a-dropdown-apis",
    "a-dropdown-base-factory",
    "a-dropdown-keyboard-handlers"
  ).register("a-dropdown-handlers", function (a, g, b, m, d, f, e) {
    var k = a.$;
    d = k(document);
    a.declarative("a-dropdown-button", "click", function (a) {
      m.getSelectFromButton(a.$target).trigger("click");
    });
    d.delegate("select.a-native-dropdown", "keydown", function (d) {
      var e = a.constants.keycodes,
        f = d.which,
        c = k(d.target).nextAll(".a-button-dropdown").eq(0);
      if (
        a.onScreen(c) &&
        (f === e.UP_ARROW ||
          f === e.DOWN_ARROW ||
          f === e.ENTER ||
          f === e.SPACE)
      ) {
        var h = k(d.target);
        h.prop("disabled", !0);
        a.delay(function () {
          h.prop("disabled", !1);
        }, 0);
        d.preventDefault ? d.preventDefault() : (d.returnValue = !1);
        g.showDropdown(d, a.extend({$button: c}, m), b);
      }
    });
    d.delegate("select.a-native-dropdown", "click", function (d) {
      d.preventDefault ? d.preventDefault() : (d.returnValue = !1);
      var e = k(d.target).nextAll(".a-button-dropdown").eq(0);
      a.onScreen(e) && g.showDropdown(d, a.extend({$button: e}, m), b);
    });
    d.delegate(".a-popover.a-dropdown a", "click", function (a) {
      a.preventDefault();
      a = k(this);
      var d = f.get(a.closest(".a-popover")),
        b = !d.sourceButton.find(".a-dropdown-prompt").text();
      !a.hasClass("a-active") || b
        ? ((b = a.data("value").stringVal),
          d.sourceSelect.val(b).trigger("change", [a]))
        : d.hide();
    });
    e &&
      (e.keyDown && d.delegate(".a-dropdown li", "keydown", e.keyDown),
      e.keyPress && d.delegate(".a-dropdown li", "keypress", e.keyPress));
  });
  ("use strict");
  n.when(
    "A",
    "a-popover-util",
    "a-popover-inline-strategy",
    "a-popover-preload-strategy",
    "a-popover-ajax-strategy",
    "a-analytics",
    "a-util"
  ).register("a-popover-data", function (a, g, b, m, d, f, e) {
    var k = [d, b, m];
    return {
      guessStrategyByAttrs: function (a) {
        for (var d = 0, b = k.length; d < b; d++) {
          var c = k[d];
          if (c.isValidStrategy(a)) return c;
        }
        d = "NO-ATTRIBUTION-INFO";
        a &&
          a.$trigger &&
          a.$trigger.get(0) &&
          (d = e.attributionChain(a.$trigger.get(0)));
        f.logError(
          "https://tiny.amazon.com/aok2pdnt/auiamazdevepopopopo - Popover failed to be created, no data strategy provided. Please provide a valid dataStrategy param for popover.",
          "FATAL",
          d
        );
      },
      getStrategyByName: function (a) {
        for (var d = 0, b = k.length; d < b; d++) {
          var c = k[d];
          if (c.name === a) return c;
        }
        return null;
      },
      showSpinner: g.showSpinner,
    };
  });
  n.when("A", "a-analytics", "a-util").register(
    "a-dom-poller",
    function (a, g, b) {
      function m() {
        var a = Array.prototype.slice.call(arguments);
        return b.reduce(
          a,
          function (a, d) {
            return a || q === d;
          },
          !1
        );
      }
      function d(a) {
        a.callbackCalled = !0;
        a = c.indexOf(a);
        0 <= a && c.splice(a, 1);
      }
      function f(c, b) {
        a.defer(function () {
          c.callbackCalled || c.failureCallback(b);
          d(c);
        });
      }
      function e(c) {
        a.defer(function () {
          c.callbackCalled || c.successCallback();
          d(c);
        });
      }
      function k(a) {
        return b.reduce(
          c,
          function (d, c) {
            return d || c.selector === a;
          },
          !1
        );
      }
      function h() {
        if (c.length) {
          q = p.POLLING;
          setTimeout(h, 1e3);
          for (var a = c.length; a--; ) {
            var d = c[a];
            document.querySelector(d.selector)
              ? e(d)
              : r &&
                5e3 < Date.now() - d.startTime &&
                f(d, "Content not found in time.");
          }
        } else q = p.PAUSED;
      }
      var p = {
          NOT_STARTED: "NOT_STARTED",
          POLLING: "POLLING",
          PAUSED: "PAUSED",
        },
        q = p.NOT_STARTED,
        c = [],
        r = !1;
      n.when("ready").execute(function () {
        r = !0;
      });
      return {
        waitFor: function (a, d, b) {
          k(a)
            ? g.logError(
                "Tried to poll for DOM selector (" +
                  a +
                  ") that is already being polled for.",
                "WARN",
                "AUI DomPoller: " + a
              )
            : ((a = {
                selector: a,
                successCallback: d,
                failureCallback: b,
                callbackCalled: !1,
                startTime: Date.now(),
              }),
              c.unshift(a),
              m(p.NOT_STARTED, p.PAUSED) && h());
        },
        stopPollingSelector: function (a) {
          b.filter(c, function (d) {
            return d.selector === a;
          }).forEach(function (a) {
            d(a);
          });
        },
        isPollingSelector: k,
      };
    }
  );
  ("use strict");
  n.when(
    "A",
    "a-popover-lightbox-markup",
    "prv:a-capabilities",
    "a-bodyBegin"
  ).register("a-popover-lightbox", function (a, g, b) {
    function m(a) {
      a.preventDefault();
      a.stopPropagation();
      a.stopImmediatePropagation();
      return !1;
    }
    function d() {
      w.unbind("click", m);
      l = !1;
    }
    function f(c) {
      var b = e(r);
      -1 < x ||
        !t ||
        ((c = c || {}),
        w.bind("click", m),
        (l = !0),
        "number" !== typeof c.hideDuration && (c.hideDuration = 250),
        0 < c.hideDuration
          ? a.fadeOut(t, c.duration, "linear", function () {
              c.lockScroll &&
                (e("html, body").css("overflow", ""),
                e("body").css("margin-right", ""),
                a.delay(function () {
                  0 < u && (b.scrollTop(u), (u = -1));
                  0 < y && (b.scrollLeft(y), (y = -1));
                }, 100));
              v = null;
            })
          : (t.css("display", "none"),
            c.lockScroll &&
              (e("html, body").css("overflow", ""),
              e("body").css("margin-right", ""),
              0 < u && (b.scrollTop(u), (u = -1))),
            (v = null)),
        t.css({height: "", width: ""}),
        a.delay(d, c.hideDuration + 350),
        e("#a-page").removeAttr("aria-hidden"));
    }
    var e = a.$,
      k = -1 < document.documentElement.className.indexOf("-ie"),
      h = b.isIE10Plus && a.capabilities.mobile,
      p = 0 === (a.capabilities.androidVersion + "").indexOf("4."),
      q = b.isUCBrowser,
      c = g.id,
      n = g.div,
      l = !1,
      w = e("body"),
      t = null,
      x = -1,
      u = -1,
      y = -1,
      v = null;
    e(document).delegate(
      "#" + c,
      "click " + a.action.start + " " + a.action.move,
      function (a) {
        a.preventDefault();
      }
    );
    a.declarative(
      "a-popover-floating-close",
      a.capabilities.touch ? a.action.end : "click",
      function (a) {
        !l &&
          a.$target.data("action") &&
          -1 < a.$target.data("action").indexOf("a-popover-floating-close") &&
          (v && v.isActive()
            ? (v.unlock().hide(), a.$event.preventDefault())
            : f());
      }
    );
    if (b.isiOS8)
      a.on("a:popover:afterUpdatePosition", function (a) {
        a = a.popover;
        var d = e("#" + c),
          b = d.length ? d.offset().top : -1,
          f = e(r);
        if (a.isActive() && a.attrs("lightboxOptions") && b) {
          var g = 0;
          var k = setInterval(function () {
            f.scrollTop(b);
            5 < ++g && clearInterval(k);
          }, 200);
        }
      });
    return {
      show: function (b) {
        e("#a-page").attr("aria-hidden", "true");
        var f = e(r);
        t || (e("body").append(n), (t = e("#" + c)));
        b = b || {};
        w.bind("click", m);
        l = !0;
        b.lockScroll &&
          (-1 === u && ((u = f.scrollTop()), (y = f.scrollLeft())),
          a.setCssImportant(
            e("body"),
            "margin-right",
            a.scrollBarWidth() + "px"
          ),
          h ||
            (k
              ? e("html, body").css("overflow", "hidden")
              : e("body").css("overflow", "hidden")));
        var g = (v = b.popover || null) ? v.$popover.css("z-index") - 2 : -1;
        0 < g && (t.css("z-index", g), p && f.width());
        "number" !== typeof b.showDuration && (b.showDuration = 200);
        q && v.$popover.css("overflow", "auto");
        0 < b.showDuration
          ? a.fadeIn(t, b.showDuration)
          : t.css("display", "block");
        a.delay(d, b.showDuration + 300);
      },
      hide: f,
      lock: function (a) {
        a || (a = 10);
        x < a && (x = a);
      },
      unlock: function (a) {
        a || (a = 10);
        x <= a && (x = -1);
      },
      LIGHTBOX_ID: c,
    };
  });
  ("use strict");
  n.when("A").register("a-popover-util", function (a) {
    function g(a, b) {
      for (var d = a.children.length; d--; ) {
        var f = g(a.children[d], b);
        if (f) return f;
      }
      if (b(a)) return a;
    }
    var b = a.$,
      m = /^-?\d+(?:\.\d+)?$/;
    return {
      trigger: function (d, b) {
        a.trigger("a:popover:" + d, {popover: b});
        b.name && a.trigger("a:popover:" + d + ":" + b.name, {popover: b});
      },
      extractDeclarativeParams: function (d, f) {
        d = b(d);
        d = d.hasClass("a-declarative") ? d : d.find(".a-declarative").eq(0);
        f = "a-" + f;
        var e = d.data("action");
        return e && a.contains(e, f)
          ? {attributes: d.data(f) || null, $trigger: d}
          : null;
      },
      eventOccursWithin: function (a, f) {
        a = b(a.target);
        return (
          0 < a.closest(f.$trigger).length || 0 < a.closest(f.$popover).length
        );
      },
      search: g,
      getCSSHash: function (d) {
        var b = {};
        a.each(
          "height width max-height max-width min-height min-width".split(" "),
          function (e) {
            if (d[e]) {
              var f = d[e];
              if (a.isFiniteNumber(f) || m.test(f)) f += "px";
              b[e] = f;
            }
          }
        );
        b.height && !b["max-height"] && (b["max-height"] = "none");
        b.width && !b["max-width"] && (b["max-width"] = "none");
        return b;
      },
      clearContent: function (a) {
        (a = a.getContent()) && a.empty();
      },
      showSpinner: function (a) {
        a.updateContent(
          '\x3cdiv class\x3d"a-popover-loading-wrapper a-text-center"\x3e\x3cdiv class\x3d"a-box a-color-base-background a-popover-loading"\x3e\x3c/div\x3e\x3c/div\x3e'
        );
        a.updatePosition();
        return a;
      },
      getBool: function (a, b) {
        return void 0 !== a ? !0 === a || "true" === a : !0 === b;
      },
      shouldPopoverUpdateContent: function (a, b) {
        return (
          !a.attrs("content") &&
          a.attrs("currentDataStrategy") === b &&
          (a.isVisible() || a.isActive())
        );
      },
      defaultContentFailureMessage: "Sorry, content is not available.",
    };
  });
  ("use strict");
  n.when("A", "a-modal-factory").register("a-modal-handlers", function (a, g) {
    var b = a.$;
    a.declarative("a-modal", "click", function (a) {
      g.get(a.$declarativeParent).show();
      a.$event.preventDefault();
    });
    b(document).delegate(
      ".a-modal-scroller",
      "click " + a.action.start + " " + a.action.move,
      function (a) {
        a.target === this && a.preventDefault();
      }
    );
  });
});
/* ******** */
(function (e) {
  var h = window.AmazonUIPageJS || window.P,
    t = h._namespace || h.attributeErrors,
    a = t ? t("AmazonUIBottomSheet", "AmazonUI") : h;
  a.guardFatal
    ? a.guardFatal(e)(a, window)
    : a.execute(function () {
        e(a, window);
      });
})(function (e, h, t) {
  e.when(
    "A",
    "a-analytics",
    "a-sheet-web",
    "a-sheet-capabilities",
    "prv:a-sheet-constants",
    "prv:a-sheet-web-private",
    "prv:a-sheet-lightbox",
    "prv:a-sheet-history-manager",
    "prv:a-sheet-orientation-change"
  ).register("a-sheet", function (a, d, k, n, f, c, b, q, l) {
    var g = null,
      r = {};
    a.on("a:sheet:private:beforeShow", function (c) {
      h(c.sheet);
    });
    a.on("a:sheet:private:beforeHide", function (c) {
      p(c.sheet);
    });
    a.on("a:sheet:lightbox:private:click", function (c) {
      g && p(g) && (g = null);
    });
    a.on("a:sheet:history:private:pop", function (a) {
      g === r[a.sheetName] && c.hide(g) && (g = null);
    });
    a.on("a:sheet:private:destroy", function (c) {
      delete r[c.sheet._name];
    });
    a.on("orientationchange", function (c) {
      if (g) {
        var b = g;
        l.handleScrollerOrientation(b);
        l.resetSheetHeight(b);
        a.capabilities.ios &&
          (b.$sheetOuterContainer.css("WebkitOverflowScrolling", "auto"),
          a.delay(function () {
            b.$sheetOuterContainer.css("WebkitOverflowScrolling", "");
          }, 1e3));
      }
    });
    a.on("a:popover:beforeShow", function (a) {
      g &&
        "secondary-view" === a.popover.type &&
        (c.unlockPageScroll(g), c.turnOffExperimentalScrolling(g));
    });
    a.on("a:popover:afterHide", function (a) {
      g &&
        "secondary-view" === a.popover.type &&
        (c.lockPageScroll(g), c.turnOnExperimentalScrolling(g));
    });
    if (a.capabilities.isAndroid)
      a.on("resize", function (c) {
        g && g.updatePosition();
      });
    var h = function (a) {
        a ||
          e.error(
            "Invalid sheet object passed in to .showSheet()",
            "AmazonUIBottomSheet",
            "BottomSheet"
          );
        return g
          ? !1
          : c.show(a)
          ? ((g = a), a._historySupportEnabled && q.push(a), !0)
          : !1;
      },
      p = function (a) {
        a ||
          e.error(
            "Invalid sheet object passed in to .hideSheet()",
            "AmazonUIBottomSheet",
            "BottomSheet"
          );
        return c.hide(a)
          ? ((g = null), a._historySupportEnabled && q.goBack(), !0)
          : !1;
      };
    return {
      showSheet: h,
      hideSheet: p,
      create: function (a) {
        var c = new b();
        d.increment("bottomsheet-web");
        var m = new k.Sheet(a);
        r[a.name] = m;
        m._lightbox = c;
        return m;
      },
      get: function (a) {
        return r[a];
      },
    };
  });
  ("use strict");
  e.when("A", "a-component", "prv:a-sheet-constants").register(
    "a-sheet-base",
    function (a, d, k) {
      return d.create({
        _componentName: "sheet",
        init: function (d) {
          this._preloadDomId = d.preloadDomId;
          this._inlineContent = d.inlineContent;
          this._name = d.name;
          this._a11y = {label: d.sheetLabel, description: d.sheetDescription};
          var f = d.closeMessage && a.trim(d.closeMessage);
          this._closeEnabled =
            d.closeType === k.closeButtonType.icon ||
            (d.closeType === k.closeButtonType.message && !!f);
          this._closeMessage = f;
          this._closeType = d.closeType;
          var c = parseFloat(d.duration);
          this._duration = a.isFiniteNumber(c)
            ? 1e3 * c
            : k.defaults.animationDurationInMS;
          this._height = parseInt(d.height, 10) || k.defaults.sheetHeightInPx;
          this._autoHeight = !1;
          this._scrollPosition;
          this._historySupportEnabled = !1 !== d.historySupportEnabled;
          this._preventBackgroundPinToTop = !1 === d.preventBackgroundPinToTop;
          d.closeType !== k.closeButtonType.message ||
            f ||
            e.log(
              "closeType is " + d.closeType + " but closeMessage is not set",
              "WARN",
              "AmazonUIBottomsheet"
            );
          this._trackApi();
        },
      });
    }
  );
  ("use strict");
  e.when("A", "a-sheet", "a-sheet-accessibility").register(
    "a-sheet-handlers",
    function (a, d, k) {
      a.declarative("a-sheet", "click", function (c) {
        var b = d.get(c.data.name);
        a.debounce(
          function () {
            b ? d.showSheet(b) : d.showSheet(d.create(c.data));
          },
          250,
          !0
        )();
      });
      a.declarative("a-sheet-close", "click", function (a) {
        a = d.get(a.data.name);
        d.hideSheet(a);
      });
      var e = null,
        f = null;
      a.declarative("a-sheet-a11y", "focusout", function (c) {
        if (!(e && 100 > a.now() - e)) {
          e = a.now();
          var b = d.get(c.data.name);
          b &&
            a.delay(function () {
              a.$(document.activeElement).hasClass("a-sheet-start") &&
                k.getTabbableElements(b.$container).last().focus();
            }, 0);
        }
      });
      a.declarative("a-sheet-a11y", "focusin", function (c) {
        if (
          !(f && 100 > a.now() - f) &&
          ((f = a.now()), c.$target.hasClass("a-sheet-end"))
        ) {
          var b = d.get(c.data.name);
          b &&
            a.delay(function () {
              k.getTabbableElements(b.$container).first().focus();
            }, 0);
        }
      });
    }
  );
  ("use strict");
  e.when(
    "A",
    "a-sheet-util",
    "a-sheet-accessibility",
    "prv:a-sheet-dimensions",
    "prv:a-capabilities",
    "prv:a-sheet-constants"
  ).register("prv:a-sheet-web-private", function (a, d, k, n, f, c) {
    var b = a.$,
      q = a.constants.HIDE_CLASS,
      l = b("#a-page");
    b("body");
    var g = b(h),
      r = function (m) {
        var g = b(
            '\x3cdiv class\x3d"a-sheet-content-container"\x3e\x3c/div\x3e'
          ),
          f = b('\x3cdiv class\x3d"a-sheet-web"\x3e\x3c/div\x3e').append(g),
          l = b(
            '\x3cdiv class\x3d"a-sheet-web-container"\x3e\x3c/div\x3e'
          ).append(f);
        if (m._preloadDomId) {
          var r = b("#" + m._preloadDomId);
          r.show().removeClass(q);
          g.append(r);
        } else m._inlineContent && g.append(b(m._inlineContent));
        r = m._closeMessage || "close";
        var n = "";
        a.capabilities.ios && m._a11y.label && (n += m._a11y.label + ", ");
        var p = b(a.capabilities.ios ? "\x3cbutton/\x3e" : "\x3cspan/\x3e", {
          class: "a-sheet-close visually-hidden",
          "aria-label": n + r,
          tabindex: "0",
        })
          .prependTo(f)
          .bind("click", d.handleHidingClick);
        e.when("a-event-analytics").execute(
          "TNR: notifyJquery for click",
          function (a) {
            a.notifyJquery(p, "click");
          }
        );
        m._closeEnabled &&
          (p.removeClass("visually-hidden"),
          m._closeType === c.closeButtonType.message
            ? p.html(r)
            : p.addClass("a-icon a-icon-close-white"));
        "undefined" !== typeof h.orientation &&
          (p.addClass("a-focus-hidden"), f.addClass("a-focus-hidden"));
        k.addA11yMarkup(f, m);
        m.$contentContainer = g;
        m.$sheetOuterContainer = l;
        m.$container = f;
        m.$sheetOuterContainer.bind(
          "click",
          d.guardedHandler(m.$sheetOuterContainer[0], d.handleHidingClick)
        );
        e.when("a-event-analytics").execute(
          "TNR: notifyJquery for click (sheetOuterContainer)",
          function (a) {
            a.notifyJquery(m.$sheetOuterContainer, "click");
          }
        );
        g = "100%";
        l && (g = m._height + "px");
        l = "translateY(" + g + ")";
        m.$sheetOuterContainer
          .addClass(q)
          .css({transform: l, WebkitTransform: l});
      },
      v = function (a) {
        var c = g.scrollTop();
        l.addClass("a-scroll-disabled");
        a._preventBackgroundPinToTop || l.css("top", "-" + c + "px");
        a._initialScrollPosition = c;
      },
      p = function (a) {
        l.removeClass("a-scroll-disabled");
        a._preventBackgroundPinToTop || l.css("top", "");
      },
      u = function (a) {
        a.$sheetOuterContainer.removeClass("a-experimental-ios-scrolling");
      },
      t = function (a) {
        a.$sheetOuterContainer.addClass("a-experimental-ios-scrolling");
      };
    return {
      lockPageScroll: v,
      unlockPageScroll: p,
      turnOffExperimentalScrolling: u,
      turnOnExperimentalScrolling: t,
      hide: function (b) {
        var g = b.$container,
          f = b._duration,
          l = b.$sheetOuterContainer;
        b._animating && a.stopAnimation(g, !0, !0);
        var m = function () {
          b._active = !1;
          b._animating = !1;
          p(b);
          u(b);
          l.addClass(q);
          b._blurSheet && b._blurSheet();
          d.triggerEvent(c.events.afterHide, b);
        };
        d.triggerEvent(c.events.beforeHide, b);
        0 < f && (b._animating = !0);
        a.animationFrameDelay(function () {
          var c = "translateY(" + (l.height() + "px") + ")";
          a.animate(l, {transform: c, WebkitTransform: c}, f, "ease-in", m);
          b._lightbox.hide(f);
        });
        return !0;
      },
      show: function (b) {
        var g = b.$container,
          f = b.$sheetOuterContainer,
          l = b._duration,
          e = d.getWindowHeight(),
          p = n.getContainerHeight(b._height, b._autoHeight, e);
        b._animating && a.stopAnimation(g, !0, !0);
        g ||
          (r(b),
          (g = b.$container),
          (f = b.$sheetOuterContainer),
          f.appendTo("body"));
        b._active = !0;
        g.css({height: p, maxHeight: d.getMaxHeight(e)});
        v(b);
        var h = function () {
          b._animating = !1;
          t(b);
          d.triggerEvent(c.events.afterShow, b);
          b._blurSheet = k.focusComponent(b);
        };
        d.triggerEvent(c.events.beforeShow, b);
        0 < l && (b._animating = !0);
        a.requestAnimationFrame(function () {
          f.removeClass(q);
          b.updatePosition();
          b.$contentContainer.css({height: "100%", overflowY: "auto"});
          b._lightbox.show(l);
          a.animate(
            f,
            {transform: "translateY(0)", WebkitTransform: "translateY(0)"},
            l,
            "ease-out",
            h
          );
        });
        return !0;
      },
    };
  });
  e.when(
    "A",
    "a-sheet-base",
    "a-sheet-util",
    "prv:a-sheet-web-private",
    "prv:a-sheet-constants",
    "prv:a-sheet-dimensions",
    "a-sheet-capabilities"
  ).register("a-sheet-web", function (a, d, k, h, f, c, b) {
    return {
      Sheet: d.extend({
        init: function (a) {
          this._super(a);
        },
        _componentName: "sheet-web",
        show: function () {
          if (this._animating || this._active) return !1;
          k.triggerEvent("private:beforeShow", this);
          return !0;
        },
        hide: function () {
          if (this._animating || !this._active)
            return (
              e.log(
                "Failed to hide bottom sheet: bottom sheet is " +
                  (this._animating ? "animating" : "not active"),
                "WARN",
                "hide"
              ),
              !1
            );
          k.triggerEvent("private:beforeHide", this);
          return !0;
        },
        changeHeight: function (b) {
          var c = this,
            g = !1 !== b.persist,
            d = 1e3 * parseFloat(b.duration);
          b = b.height;
          var q = Math.min(Math.max(b, 0), k.getMaxHeight()),
            h = c.$container;
          if (c._animating || !a.isFiniteNumber(q))
            return (
              e.log(
                "Failed to change bottom sheet height: " +
                  (c._animating
                    ? "bottom sheet is animating"
                    : "height is not finite"),
                "WARN",
                "changeHeight"
              ),
              !1
            );
          g && (c._height = b);
          if (!c._active || q === h.height())
            return k.triggerEvent(f.events.changeHeight, c), !0;
          a.isFiniteNumber(d) || (d = c._duration);
          var n = function () {
            c._animating = !1;
            k.triggerEvent(f.events.changeHeight, c);
          };
          0 < d &&
            ((c._animating = !0),
            c._autoHeight && h.css("height", h.height() + "px"));
          c.updatePosition();
          a.animationFrameDelay(function () {
            a.animate(h, {height: q + "px"}, d, "ease-out", n);
          });
          return !0;
        },
        updatePosition: function () {
          var b = this,
            d = k.getWindowHeight(),
            g = b.$contentContainer.height(),
            f = b.$sheetOuterContainer;
          d = c.getSheetOuterContainerDimensions(d, g);
          f.css({height: d.height + "px"});
          a.capabilities.ios &&
            (h.turnOffExperimentalScrolling(b),
            a.delay(function () {
              h.turnOnExperimentalScrolling(b);
            }, 500));
        },
        getContentContainer: function () {
          return this.$contentContainer;
        },
        destroy: function () {
          if (this._active)
            e.log(
              "Cannot destroy Bottomsheet as Bottomsheet is currently open",
              "WARN",
              "AmazonUIBottomsheet"
            );
          else {
            for (var b in f.events)
              a.off("a:sheet:" + f.events[b] + ":" + this._name);
            this.$sheetOuterContainer.remove();
            a.trigger("a:sheet:private:destroy", {sheet: this});
          }
        },
      }),
    };
  });
  ("use strict");
  e.when(
    "A",
    "prv:a-sheet-constants",
    "a-sheet-util",
    "prv:a-sheet-dimensions"
  ).register("prv:a-sheet-orientation-change", function (a, d, k, e) {
    return {
      resetSheetHeight: function (a) {
        var c = a.$container.height(),
          b = k.getMaxHeight(),
          d = {duration: 0, persist: !1};
        c > b
          ? (d.height = b)
          : c !== a._height && (d.height = a._autoHeight ? "auto" : a._height);
        "height" in d && a.changeHeight(d);
      },
      handleScrollerOrientation: function (a) {
        var c = k.getWindowHeight();
        a.$container.css({
          top: "",
          height: e.getContainerHeight(a._height, a._autoHeight, c),
          maxHeight: k.getMaxHeight(),
        });
        a.updatePosition();
      },
    };
  });
  ("use strict");
  e.when("A", "a-component", "a-sheet-util").register(
    "prv:a-sheet-lightbox",
    function (a, d, k) {
      var h = a.$,
        f =
          '\x3cdiv class\x3d"a-sheet-lightbox ' +
          a.constants.HIDE_CLASS +
          '" /\x3e';
      return d.create({
        _componentName: "sheet-lightbox",
        init: function (a) {
          this.$container = h(f);
          this.$container
            .bind("click", k.handleHidingClick)
            .bind("touchmove", k.handleLightboxTouchmove);
          var b = this.$container;
          e.when("a-event-analytics").execute(function (a) {
            a.notifyJquery(b, "click");
          });
          this._animating = this._active = !1;
          this._trackApi();
        },
        show: function (c) {
          var b = this;
          c = c || 0;
          b._duration = c;
          var d = b.$container;
          d.appendTo("body");
          var f = function () {
            b._active = !0;
            b._animating = !1;
          };
          0 < c && (b._animating = !0);
          a.requestAnimationFrame(function () {
            a.fadeIn(d, c, null, f);
          });
        },
        hide: function (c) {
          var b = this;
          c = a.isFiniteNumber(c) ? c : b._duration;
          var d = b.$container,
            f = function () {
              b._active = !1;
              b._animating = !1;
            };
          0 < c && (b._animating = !0);
          a.requestAnimationFrame(function () {
            a.fadeOut(d, c, null, f);
          });
        },
      });
    }
  );
  ("use strict");
  e.when("A", "a-sheet-accessibility-templates").register(
    "a-sheet-accessibility",
    function (a, d) {
      var e = a.$,
        n = e(h),
        f = d.startAnchorTemplate,
        c = d.endAnchorTemplate,
        b = d.descriptionTemplate,
        q = function (a, c) {
          var d = {"{{DESCRIPTION}}": c, "{{DESCRIPTION_ID}}": a};
          return b.replace(/\{\{[\w_]*\}\}/g, function (a) {
            return d[a];
          });
        },
        l = function (a) {
          a = a.find("a, button, input, select, textarea, [tabindex]");
          a = a.not("[tabindex\x3d'-1']");
          return a.not(".a-sheet-start, .a-sheet-end");
        };
      return {
        getStartAnchorHtml: function (a) {
          return f;
        },
        getEndAnchorHtml: function () {
          return c;
        },
        getTabbableElements: l,
        addA11yMarkup: function (b, d) {
          var g = d._a11y;
          a.declarative.create(b, "a-sheet-a11y", {name: d._name});
          var e = {role: "dialog", tabindex: "0", "aria-modal": !0};
          a.capabilities.ios && delete e.role;
          g.label &&
            (0 === g.label.indexOf("#")
              ? (e["aria-labelledby"] = g.label.substring(1))
              : (e["aria-label"] = g.label));
          g.description &&
            (0 === g.label.indexOf("#")
              ? (e["aria-describedby"] = g.description.substring(1))
              : ((d = d._name + "-description"),
                (e["aria-describedby"] = d),
                b.prepend(q(d, g.description))));
          for (var h in e) e[h] !== t && b.attr(h, e[h]);
          b.prepend(f);
          b.append(c);
        },
        focusComponent: function (b) {
          var c = e(document.activeElement);
          a.capabilities.ios
            ? l(b.$container).first().focus()
            : b.$container.focus();
          e("#a-page").attr("aria-hidden", "true");
          return function () {
            e("#a-page").removeAttr("aria-hidden");
            c.focus();
            b._initialScrollPosition !== t &&
              (n.scrollTop(b._initialScrollPosition),
              delete b._initialScrollPosition);
          };
        },
      };
    }
  );
  ("use strict");
  e.declare("a-sheet-accessibility-templates", {
    startAnchorTemplate:
      '\x3cspan tabindex\x3d"0" class\x3d"a-sheet-start a-sheet-a11y-offscreen"\x3e\x3c/span\x3e',
    endAnchorTemplate:
      '\x3cspan tabindex\x3d"0" class\x3d"a-sheet-end a-sheet-a11y-offscreen"\x3e\x3c/span\x3e',
    descriptionTemplate:
      '\x3cspan id\x3d"{{DESCRIPTION_ID}}" class\x3d"a-sheet-a11y-offscreen a-hidden"\x3e{{DESCRIPTION}}\x3c/span\x3e',
  });
  e.declare("prv:a-sheet-constants", {
    closeButtonAreaHeightInPx: 40,
    defaultSheetHeaderHeightInPx: 50,
    maxHeightOffsetInPx: {
      mshop: {portrait: 80, landscape: 80},
      web: {portrait: 160, landscape: 120},
    },
    defaults: {animationDurationInMS: 300, sheetHeightInPx: 300},
    headerAnimationFunction: "cubic-bezier(0.4, 0, 0.6, 0.95)",
    logPrefix: "AmazonUIBottomSheet: ",
    closeButtonType: {icon: "icon", message: "message"},
    events: {
      afterHide: "afterHide",
      beforeHide: "beforeHide",
      afterShow: "afterShow",
      beforeShow: "beforeShow",
      changeHeight: "changeHeight",
    },
  });
  ("use strict");
  e.when("A", "prv:a-sheet-constants").register(
    "a-sheet-util",
    function (a, d) {
      var k,
        n = d.maxHeightOffsetInPx;
      e.when("mash").execute(function (a) {
        k = !0;
      });
      var f = function () {
          return h.innerHeight;
        },
        c = function (b, c) {
          a.trigger("a:sheet:" + b, {sheet: c});
          c && c._name && a.trigger("a:sheet:" + b + ":" + c._name, {sheet: c});
        };
      return {
        getWindowHeight: f,
        getMaxHeight: function (a) {
          var b =
            n[k ? "mshop" : "web"][
              90 === Math.abs(h.orientation) ? "landscape" : "portrait"
            ];
          return (a || f()) - b;
        },
        guardedHandler: function (a, c) {
          return function (b) {
            b.target === a && c(b);
          };
        },
        triggerEvent: c,
        handleLightboxTouchmove: function (a) {
          a.preventDefault();
          a.stopPropagation();
        },
        handleHidingClick: function (a) {
          a.preventDefault();
          a.stopPropagation();
          c("lightbox:private:click");
        },
        triggerEventDeferred: function (b, d) {
          a.delay(function () {
            c(b, d);
          });
        },
      };
    }
  );
  ("use strict");
  e.when("A", "a-util", "a-ua", "prv:a-capabilities").register(
    "a-sheet-capabilities",
    function (a, d, h, n) {
      function f(a) {
        if (b) return b[a];
        var e = d.cookies.get("amzn-app-ctxt");
        if (e) {
          e = decodeURIComponent(e);
          var f = e.indexOf(" ");
          e.substring(0, f);
          e = e.substring(f);
          b = c.parseJSON(e);
          return b[a];
        }
      }
      var c = a.$,
        b;
      return {
        isAndroidApp: function () {
          return "Android" === f("os");
        },
        isIOSApp: function () {
          return "iOS" === f("os");
        },
        shouldShowHybridBottomSheet: function () {
          e.log(
            "Hybrid Bottomsheets have been deprecated in AUI v3.19.3 and only Web Bottomsheets are vended. Please stop using this API immediately.",
            "WARN",
            "aSheetCapabilities"
          );
          return !1;
        },
      };
    }
  );
  e.when("A", "a-sheet-util", "prv:a-sheet-constants").register(
    "prv:a-sheet-dimensions",
    function (a, d, e) {
      return {
        getSheetOuterContainerDimensions: function (a, d) {
          var c = a - d - e.closeButtonAreaHeightInPx;
          return {
            top: 0 < c ? c : 0,
            height: 0 < c ? d + e.closeButtonAreaHeightInPx : a,
          };
        },
        getContainerHeight: function (a, e, c) {
          a = Math.min(a, d.getMaxHeight(c));
          return e ? "auto" : a + "px";
        },
      };
    }
  );
  ("use strict");
  e.when("A").register("prv:a-sheet-history-manager", function (a) {
    var d = 0,
      k = !1;
    e.when("mash").execute(function (a) {
      k = !0;
    });
    e.when("a-sheet-history-support").execute(function (a) {
      a.hasHistorySupport()
        ? ((d = 2), h.addEventListener("popstate", n))
        : ((d = 1), h.addEventListener("hashchange", f));
    });
    var n = function (c) {
        var b = c.state;
        b &&
          "a-sheet-web" === b.component &&
          "hide" === b.action &&
          (c.preventDefault(),
          h.history.replaceState(b.oldState, "", null),
          a.trigger("a:sheet:history:private:pop", {sheetName: b.sheetName}));
      },
      f = function (c) {
        k ||
          ((c = c.oldURL),
          (c = 1 < c.split("#").length && c.split("#")[1]) &&
            0 === c.indexOf("a-sheet-web-") &&
            ((c = c.split("a-sheet-web-")[1]),
            a.trigger("a:sheet:history:private:pop", {sheetName: c})));
      };
    return {
      push: function (a) {
        2 === d
          ? (h.history.replaceState(
              {
                oldState: h.history.state,
                component: "a-sheet-web",
                action: "hide",
                sheetName: a._name,
              },
              "",
              null
            ),
            h.history.pushState(null, "", null))
          : 1 === d && (h.location.hash = "#a-sheet-web-" + a._name);
      },
      goBack: function () {
        0 !== d && h.history.back();
      },
    };
  });
  ("use strict");
  e.when("A").execute("a-sheet-history-support-detection", function (a) {
    var d = function () {
      e.declare("a-sheet-history-support-ready", {});
    };
    if (
      h.navigator &&
      h.navigator.userAgent &&
      h.navigator.userAgent.match("CriOS")
    )
      a.$(document).one("touchstart", d);
    else d();
    e.when("a-sheet-history-support-ready").register(
      "a-sheet-history-support",
      function () {
        return {
          hasHistorySupport: function () {
            return h.history && "function" === typeof h.history.pushState;
          },
        };
      }
    );
  });
});
/* ******** */
(function (e) {
  var k = window.AmazonUIPageJS || window.P,
    g = k._namespace || k.attributeErrors,
    c = g ? g("AmazonUITruncate", "AmazonUI") : k;
  c.guardFatal
    ? c.guardFatal(e)(c, window)
    : c.execute(function () {
        e(c, window);
      });
})(function (e, k, g) {
  e.when("A", "a-component", "prv:a-truncate-util").register(
    "a-truncate",
    function (c, e, k) {
      function g(a) {
        var b = a._$fullText,
          c = Math.round(parseFloat(a._$element.css("max-height"))),
          e = a.getOverflowMarker(),
          g = a.getSpecialCharacterList(),
          d = a._$offscreenTextHolder;
        a._$element.append(d);
        if (!(parseFloat(d.html(b).css("height")) <= c)) {
          a = 0;
          for (var f = b.length, h, l; f > a; )
            (h = Math.floor((a + f) / 2)),
              (l = b.substring(0, h + 1) + e),
              parseFloat(d.html(l).css("height")) > c ? (f = h) : (a = h + 1);
          b = k.trimSpecialChars(b.substring(0, f), g) + e;
        }
        d.remove();
        return b;
      }
      function h(a) {
        a = f(a).attr("data-a-recalculate", !0);
        m();
        return a.length;
      }
      function d() {
        return h(
          '.a-truncate:not([data-a-manual-update\x3d"true"]):not([data-a-updated])'
        );
      }
      var f = c.$,
        l = e.create({
          _componentName: "truncate",
          init: function (a, b) {
            this._super(a, b);
            this._$full = this._$element.find(".a-truncate-full");
            this._$cut = this._$element.find(".a-truncate-cut");
            this._$fullText = this.getFullText();
            this._$offscreenTextHolder = f(
              '\x3cspan class\x3d"a-truncate-calc a-offscreen"/\x3e'
            );
            c.capabilities.android &&
              c.capabilities.isAmazonApp &&
              ((a = this.getMaxHeight()),
              /[^r]em$/.test(a) &&
                ((a = parseFloat(a)),
                (b = parseFloat(this._$element.css("font-size"))),
                this._$element.css("max-height", a * b + "px")));
          },
          update: function (a) {
            var b = this._$cut.html(),
              d = g(this);
            this._$fullText !== d
              ? this._$cut.height(this.getMaxHeight())
              : this._$cut.height("auto");
            this._$cut.html(d);
            this._$element.attr("data-a-updated", !0);
            this._$full.addClass("a-offscreen");
            this._$cut.removeClass("a-hidden");
            d = {truncateContainer: this._$element, truncateInstance: this};
            (a && a.silent) ||
              ((a = this.getTruncatedText()),
              b !== a &&
                (c.trigger("a:truncate:updated", d),
                (b = this._$element.data("a-truncate-name")) &&
                  c.trigger("a:truncate:" + b + ":updated", d)));
          },
          getFullText: function () {
            return this._$full.html();
          },
          getTruncatedText: function () {
            return this.getIsUpdated() ? this._$cut.html() : g(this);
          },
          getIsUpdated: function () {
            return this._$element.is("[data-a-updated]");
          },
          getOverflowMarker: function () {
            return this._$element.data("a-overflow-marker") || "";
          },
          getSpecialCharacterList: function () {
            return this._$element.data("a-special-character-list") || "";
          },
          getLineHeight: function () {
            return this._$element[0].style.lineHeight;
          },
          getMaxHeight: function () {
            return this._$element[0].style.maxHeight;
          },
          getIfTextFits: function () {
            return this._$fullText === g(this);
          },
        }),
        m = (function (a) {
          function b() {
            (d = a()) && c.delay(b, 0);
          }
          var d = !1;
          return function () {
            d || b();
          };
        })(function () {
          var a = f('.a-truncate[data-a-recalculate\x3d"true"]').first(),
            b = !!a.length;
          b && (new l(a).update(), a.attr("data-a-recalculate", !1));
          return b;
        });
      c.on("ready orientationchange", function () {
        h('.a-truncate:not([data-a-manual-update\x3d"true"])');
      });
      c.on("resize", function (a, b) {
        b.width && h('.a-truncate:not([data-a-manual-update\x3d"true"])');
      });
      c.on("a:pageUpdate", d);
      return {
        get: function (a, b) {
          return new l(a, b);
        },
        manualTruncate: function (a) {
          return h(f(a).find('.a-truncate[data-a-manual-update\x3d"true"]'));
        },
        switchToAutoTruncate: function (a) {
          a = f(a).find('.a-truncate[data-a-manual-update\x3d"true"]');
          a.removeAttr("data-a-manual-update");
          return a.length;
        },
        refreshAutoTruncate: d,
      };
    }
  );
  e.declare("prv:a-truncate-util", {
    trimSpecialChars: function (c, d) {
      d = new RegExp(
        "[" + d.replace(/[.\\+*?[^\]$(){}=!<>|:-]/g, "\\$\x26") + "\\s]+$"
      );
      return c.replace(d, "");
    },
  });
});
/* ******** */
(function (l) {
  var m = window.AmazonUIPageJS || window.P,
    n = m._namespace || m.attributeErrors,
    b = n ? n("AmazonUICardUI", "AmazonUI") : m;
  b.guardFatal
    ? b.guardFatal(l)(b, window)
    : b.execute(function () {
        l(b, window);
      });
})(function (l, m, n) {
  l.when(
    "A",
    "a-component",
    "prv:a-cardui-peek-toggle",
    "prv:a-cardui-peek-expand"
  ).register("a-cardui", function (b, d, g, h) {
    var c = b.$,
      f = d.create({
        _componentName: "cardui",
        init: function (a, c) {
          this._super(a, c);
          this.metadata = {
            interactedOnce: !1,
            describedByIds: this._$element.data("describedByIds"),
            cardExpanded: this.isExpanded(),
            cardName: this.getName(),
          };
        },
        getCardType: function () {
          return c(this._$element).data("a-card-type");
        },
        isExpanded: function () {},
        getName: function () {
          return this._$element.attr("name");
        },
        getId: function () {
          return this._$element.attr("id");
        },
        toggle: function () {},
      });
    return {
      get: function (a, d) {
        var e;
        if (!(e = c(a).data("cardInstance"))) {
          switch (c(a).data("a-card-type")) {
            case "peekToggle":
              e = f.extend(g);
              break;
            case "peekExpand":
              e = f.extend(h);
              break;
            default:
              e = f;
          }
          d = new e(a, d);
          c(a).data("cardInstance", d);
          b.trigger("a:card:initialized", d);
          c(a).attr("id") &&
            b.trigger("a:card:" + c(a).attr("id") + ":initialized", d);
          e = d;
        }
        return e;
      },
    };
  });
  ("use strict");
  l.when("A", "a-component").register("prv:a-cardui-content", function (b, d) {
    var g = d.create({
      _componentName: "carduiContent",
      init: function (b, c) {
        this._super(b, c);
      },
      getHeight: function () {
        return this._$element[0].scrollHeight;
      },
      getMaxHeightDataAttribute: function () {
        return this._$element.data("a-max-height");
      },
    });
    return {
      get: function (b, c) {
        return new g(b, c);
      },
    };
  });
  ("use strict");
  l.when("A", "a-component", "a-cardui").register(
    "a-cardui-deck",
    function (b, d, g) {
      function h(a, k) {
        f(a).data("cardInstance") ||
          (f(a).attr("name", k.deckName + "-card" + k.cardCount++),
          f(a).data("describedByIds", k.describedByIds));
        return g.get(a);
      }
      function c(a, k) {
        k = new p(a, k);
        f(a).data("deckInstance", k);
        return k;
      }
      var f = b.$,
        a = 0,
        p = d.create({
          _componentName: "carduiDeck",
          init: function (e, k) {
            this._super(e, k);
            k = this._$element;
            e = "a-cardui-deck-autoname-" + a++;
            f(k).attr("name", e);
            k = this._$element;
            var c = e + "-teaser-describedby-collapsed",
              b = e + "-teaser-describedby-expanded";
            f(k).find(".a-teaser-describedby-collapsed").attr("id", c);
            f(k).find(".a-teaser-describedby-expanded").attr("id", b);
            this.metadata = {
              cardCount: 0,
              deckName: e,
              describedByIds: {collapsed: c, expanded: b},
            };
            this.initializeAllCards();
          },
          initializeCard: function (a, c) {
            return h(a, this.metadata);
          },
          initializeAllCards: function () {
            var a = this;
            f(this._$element)
              .find(".a-cardui")
              .each(function () {
                return h(this, a.metadata);
              });
          },
          addCards: function (a) {
            var c = this;
            (a && a.url) ||
              l.error("ajax options object or url is not defined.");
            var e,
              d = a.targetSelector,
              h = c._$element;
            d
              ? ((d = f(d)),
                d.closest(h).length
                  ? (e = d)
                  : l.error(
                      "container is outside the deck",
                      "ERROR",
                      "addCards"
                    ))
              : (e = h);
            b.get(a.url, {
              cache: !1,
              success: function (a) {
                e.append(a);
                c.initializeAllCards();
                b.trigger("a:deck:new-cards-added");
                f(c._$element).attr("id") &&
                  b.trigger(
                    "a:deck:" + f(c._$element).attr("id") + ":new-cards-added"
                  );
              },
              failure: function (a, e, k) {
                b.trigger("a:deck:cards-added-fail", {
                  xhr: a,
                  status: e,
                  errorThrown: k,
                });
                f(c._$element).attr("id") &&
                  b.trigger(
                    "a:deck:" + f(c._$element).attr("id") + ":cards-added-fail",
                    {xhr: a, status: e, errorThrown: k}
                  );
              },
            });
          },
        });
      b.on("ready", function () {
        f(".a-cardui-deck").each(function () {
          c(this);
        });
      });
      return {
        get: function (a, b) {
          return f(a).data("deckInstance") || c(a, b);
        },
      };
    }
  );
  ("use strict");
  l.when(
    "A",
    "a-component",
    "prv:a-see-more",
    "prv:a-expander-icon",
    "p-detect",
    "prv:csa-logger"
  ).register("prv:a-cardui-expand-control-footer", function (b, d, g, h, c, f) {
    function a(a, c) {
      a._$seeMore.toggleSeeMore(c.cardExpanded);
      a._$expanderIcon.toggleExpanderIcon(c.cardExpanded);
    }
    var p = d.create({
      _componentName: "carduiExpandControlFooter",
      init: function (a, c) {
        this._super(a, c);
        this._$expanderIcon = h.get(this._$element.find(".a-expander-icon"));
        this._$seeMore = g.get(this._$element.find(".a-see-more"));
        this._$button = this._$element.find(
          ".a-cardui-expand-control-footer-button"
        );
      },
      toggleExpansion: function (e) {
        var d = this;
        c.capabilities.transition && e.interactedOnce
          ? b.fadeOut(d._$element, 200, "linear", function () {
              a(d, e);
              b.fadeIn(d._$element, 200);
            })
          : a(d, e);
      },
      getName: function () {
        return this._$element.attr("name");
      },
      getId: function () {
        return this._$element.attr("id");
      },
      addTrigger: function (a) {
        this._$element.click(function () {
          b.trigger("a:card:" + a + ":toggle", this);
        });
        this._$element.length && f.element(this._$element.get(0), "click");
        this._$element.keypress(function (c) {
          var e = b.constants.keycodes;
          c = c.which;
          (c !== e.ENTER && c !== e.SPACE) ||
            b.trigger("a:card:" + a + ":toggle", this);
        });
        this._$element.length && f.element(this._$element.get(0), "keypress");
      },
    });
    return {
      get: function (a, c) {
        return new p(a, c);
      },
    };
  });
  ("use strict");
  l.when("A", "a-component", "prv:csa-logger").register(
    "prv:a-cardui-expand-control-title",
    function (b, d, g) {
      var h = d.create({
        _componentName: "carduiExpandControlTitle",
        init: function (c, b) {
          this._super(c, b);
          this._$button = this._$element.find('span[role\x3d"button"]');
          this._$header = this._$element.find("h3");
        },
        getName: function () {
          return this._$element.attr("name");
        },
        getId: function () {
          return this._$element.attr("id");
        },
        addTrigger: function (c) {
          this._$element.click(function () {
            b.trigger("a:card:" + c + ":toggle", this);
          });
          this._$element.length && g.element(this._$element.get(0), "click");
          this._$element.keypress(function (d) {
            var a = b.constants.keycodes;
            d = d.which;
            (d !== a.ENTER && d !== a.SPACE) ||
              b.trigger("a:card:" + c + ":toggle", this);
          });
          this._$element.length && g.element(this._$element.get(0), "keypress");
        },
      });
      return {
        get: function (c, b) {
          return new h(c, b);
        },
      };
    }
  );
  ("use strict");
  l.when("A", "a-component").register("prv:a-cardui-teaser", function (b, d) {
    var g = d.create({
      _componentName: "carduiTeaser",
      init: function (b, c) {
        this._super(b, c);
      },
      getHeight: function () {
        return this._$element[0].scrollHeight;
      },
    });
    return {
      get: function (b, c) {
        return new g(b, c);
      },
    };
  });
  ("use strict");
  l.when("A", "a-component").register("prv:a-expander-icon", function (b, d) {
    var g = d.create({
      _componentName: "expanderIcon",
      init: function (b, c) {
        this._super(b, c);
        this._$icon = this._$element.find(".a-css-icon");
      },
      toggleExpanderIcon: function (b) {
        var c = b ? "a-css-icon-expand" : "a-css-icon-collapse";
        b = b ? "a-css-icon-collapse" : "a-css-icon-expand";
        this._$icon.addClass("a-css-icon-draw");
        this._$icon.removeClass(c).addClass(b);
      },
    });
    return {
      get: function (b, c) {
        return new g(b, c);
      },
    };
  });
  ("use strict");
  l.when("A", "a-component", "prv:a-cardui-scroll-viewport").register(
    "a-reactive-container",
    function (b, d, g) {
      var h = d.create({
        _componentName: "reactiveContainer",
        init: function (c, b) {
          this._super(c, b);
          this._$measured = !1;
          this._$element.addClass("a-reactive-container-transition");
        },
        setHeight: function (c) {
          this._$element.css("height", c + "px");
          this._$measured
            ? g.adjustScroll(this, parseFloat(c))
            : (this._$measured = !0);
        },
        resetInitialization: function () {
          this._$measured = !1;
        },
        getHeight: function () {
          return this._$element.css("height");
        },
      });
      return {
        get: function (c, b) {
          return new h(c, b);
        },
      };
    }
  );
  ("use strict");
  l.when("A", "a-component").register("prv:a-see-more", function (b, d) {
    var g = d.create({
      _componentName: "seeMore",
      init: function (b, c) {
        this._super(b, c);
        this._$seeMoreText = this._$element.find(".a-see-more-text");
        this._$seeLessText = this._$element.find(".a-see-less-text");
      },
      toggleSeeMore: function (b) {
        b
          ? (this._$seeMoreText.hide(), this._$seeLessText.show())
          : (this._$seeMoreText.show(), this._$seeLessText.hide());
      },
    });
    return {
      get: function (b, c) {
        return new g(b, c);
      },
    };
  });
  ("use strict");
  l.when("A").register("prv:a-cardui-scroll-viewport", function (b) {
    var d = b.$;
    return {
      adjustScroll: function (b, h) {
        b = b._$element.offset().top;
        var c = d(document).scrollTop(),
          f = d(m).height();
        c > b + h && d("html,body").animate({scrollTop: b - 100}, 400);
        c + f < b + h && d("html,body").animate({scrollTop: c + 100}, 400);
      },
    };
  });
  ("use strict");
  l.when(
    "A",
    "prv:a-cardui-expand-control-title",
    "prv:a-cardui-expand-control-footer",
    "prv:a-cardui-teaser",
    "prv:a-cardui-content",
    "prv:a-reactive-container"
  ).register("prv:a-cardui-type-utility", function (b, d, g, h, c, f) {
    return {
      getExpandControlTitle: function (a) {
        return d.get(a._$element.find(".a-cardui-expand-control-title"));
      },
      getExpandControlFooter: function (a) {
        return g.get(a._$element.find(".a-cardui-expand-control-footer"));
      },
      getTeaser: function (a) {
        return h.get(a._$element.find(".a-cardui-teaser"));
      },
      getContent: function (a) {
        return c.get(a._$element.find(".a-cardui-content"));
      },
      getReactiveContainer: function (a) {
        a = a._$element.find(".a-reactive-container");
        return 0 < a.length ? f.get(a) : null;
      },
      getEventName: function (a) {
        return "a:card:" + a.getName() + ":toggle";
      },
    };
  });
  ("use strict");
  l.when("A", "prv:a-cardui-type-utility").register(
    "prv:a-cardui-peek-expand",
    function (b, d) {
      function g(a) {
        var c = a._$header;
        a.metadata.interactedOnce &&
          b.delay(function () {
            var a = f(document).scrollTop();
            c._$header.focus();
            f("html,body").scrollTop(a);
          }, 50);
      }
      function h(a) {
        var f = d.getEventName(a);
        b.on(f, function (d) {
          if (!a.metadata.interactedOnce) {
            a.metadata.interactedOnce = !0;
            var e = a._$content;
            a._$teaser._$element.removeClass("a-cardui-uninitialized");
            e._$element.removeClass("a-cardui-uninitialized");
            e._$element.css("max-height", "none");
            c(a);
          }
          e = !a.isExpanded();
          a._$element.attr("data-a-expanded", e);
          a.metadata.cardExpanded = e;
          a._$footer.toggleExpansion(a.metadata);
          c(a);
          g(a);
          d = {carduiInstance: a, triggerElement: d};
          b.trigger("a:card:toggled", d);
          a.getId() && b.trigger("a:card:" + a.getId() + ":toggled", d);
        });
      }
      function c(a) {
        var b = a._$teaser,
          c = a._$content,
          d = a._$reactiveContainer,
          f = a.metadata;
        c.getMaxHeightDataAttribute()
          ? ((b = c.getHeight()),
            b <= c.getMaxHeightDataAttribute()
              ? (a._$element.attr("data-a-card-type", "basic"),
                a._$element.find(".a-cardui-footer").addClass("a-hidden"),
                d.setHeight(b))
              : (a._$element.attr("data-a-card-type", "peekExpand"),
                a._$element.find(".a-cardui-footer").removeClass("a-hidden"),
                (a = c.getMaxHeightDataAttribute()),
                d.setHeight(f.cardExpanded ? c.getHeight() : a)))
          : d.setHeight(
              f.cardExpanded ? b.getHeight() + c.getHeight() : b.getHeight()
            );
      }
      var f = b.$;
      return {
        init: function (a, f) {
          this._super(a, f);
          this._$content = d.getContent(this);
          this._$reactiveContainer = d.getReactiveContainer(this);
          this._$footer = d.getExpandControlFooter(this);
          var e = this;
          b.on("orientationchange", function () {
            e._$reactiveContainer.resetInitialization();
            c(e);
          });
          this._$header = d.getExpandControlTitle(this);
          this._$teaser = d.getTeaser(this);
          this._$header.addTrigger(this.metadata.cardName);
          this._$footer.addTrigger(this.metadata.cardName);
          this._$footer.toggleExpansion(this.metadata);
          g(this);
          h(this);
          this._$content.getHeight() <=
            this._$content.getMaxHeightDataAttribute() &&
            (this._$reactiveContainer.setHeight(this._$content.getHeight()),
            this._$element.attr("data-a-card-type", "basic"),
            this._$element.find(".a-cardui-footer").addClass("a-hidden"));
        },
        isExpanded: function () {
          return "true" === this._$element.attr("data-a-expanded");
        },
        toggle: function (a) {
          b.trigger("a:card:" + this.getName() + ":toggle", a);
        },
      };
    }
  );
  ("use strict");
  l.when("A", "prv:a-cardui-type-utility").register(
    "prv:a-cardui-peek-toggle",
    function (b, d) {
      function g(a) {
        var c = a._$header,
          d = a._$footer,
          k = a._$teaser,
          g = a._$content;
        a = a.metadata;
        a.interactedOnce &&
          b.delay(function () {
            var a = f(document).scrollTop();
            c._$header.focus();
            f("html,body").scrollTop(a);
          }, 50);
        c._$button.attr("aria-expanded", a.cardExpanded);
        c._$header.attr(
          "aria-describedby",
          a.cardExpanded
            ? a.describedByIds.expanded
            : a.describedByIds.collapsed
        );
        d._$button.attr("aria-expanded", a.cardExpanded);
        d._$element.attr(
          "aria-describedby",
          a.cardExpanded
            ? a.describedByIds.expanded
            : a.describedByIds.collapsed
        );
        k._$element.attr("aria-hidden", a.cardExpanded);
        g._$element.attr("aria-hidden", !a.cardExpanded);
      }
      function h(a) {
        var f = d.getEventName(a);
        b.on(f, function (d) {
          if (!a.metadata.interactedOnce) {
            a.metadata.interactedOnce = !0;
            var e = a._$content;
            a._$teaser._$element.removeClass("a-cardui-uninitialized");
            e._$element.removeClass("a-cardui-uninitialized");
            a._$reactiveContainer && c(a);
          }
          e = !a.isExpanded();
          var f = a._$teaser,
            h = a._$content;
          a._$element.attr("data-a-expanded", e);
          (a.metadata.cardExpanded = e)
            ? (f._$element.addClass("a-cardui-absolute-position"),
              h._$element.removeClass("a-cardui-absolute-position"))
            : (h._$element.addClass("a-cardui-absolute-position"),
              f._$element.removeClass("a-cardui-absolute-position"));
          a._$footer.toggleExpansion(a.metadata);
          a._$reactiveContainer && c(a);
          g(a);
          d = {carduiInstance: a, triggerElement: d};
          b.trigger("a:card:toggled", d);
          a.getId() && b.trigger("a:card:" + a.getId() + ":toggled", d);
        });
      }
      function c(a) {
        var b = a._$teaser,
          c = a._$content,
          d = a._$reactiveContainer;
        a.metadata.cardExpanded
          ? d.setHeight(c.getHeight())
          : d.setHeight(b.getHeight());
      }
      var f = b.$;
      return {
        init: function (a, f) {
          this._super(a, f);
          this._$header = d.getExpandControlTitle(this);
          this._$content = d.getContent(this);
          this._$footer = d.getExpandControlFooter(this);
          this._$teaser = d.getTeaser(this);
          this._$reactiveContainer = d.getReactiveContainer(this);
          this._$header.addTrigger(this.metadata.cardName);
          this._$footer.addTrigger(this.metadata.cardName);
          this._$footer.toggleExpansion(this.metadata);
          g(this);
          h(this);
          var e = this;
          if (e._$reactiveContainer)
            b.on("orientationchange", function () {
              e.metadata.interactedOnce &&
                (e._$reactiveContainer.resetInitialization(), c(e));
            });
        },
        isExpanded: function () {
          return "true" === this._$element.attr("data-a-expanded");
        },
        toggle: function (a) {
          b.trigger("a:card:" + this.getName() + ":toggle", a);
        },
      };
    }
  );
});
/* ******** */
(function (c) {
  var b = window.AmazonUIPageJS || window.P,
    d = b._namespace || b.attributeErrors,
    a = d ? d("AmazonUICompatJS", "AmazonUI") : b;
  a.guardFatal
    ? a.guardFatal(c)(a, window)
    : a.execute(function () {
        c(a, window);
      });
})(function (c, b, d) {
  c.when("A").register("a-ios-bug-fixes", function (a) {
    var e = a.$;
    a.capabilities.ios &&
      a.on.load(function () {
        a.delay(function () {
          0 !== b.scrollY ||
            e("body").hasClass("a-suppress-ios-scroll") ||
            e('meta[name\x3d"apple-itunes-app"]').length ||
            b.speechSynthesis ||
            b.scrollTo(0, 1);
        }, 10);
      });
  });
  ("use strict");
  c.when("A").register("a-orientation-change", function (a) {
    a.capabilities.touch &&
      a.on.ready(function () {
        a.on("orientationchange", function () {
          var a = document,
            b = a.activeElement;
          b &&
            b !== a.body &&
            ((a = b.tagName.toLowerCase()),
            ("input" !== a && "textArea" !== a && "select" !== a) ||
              b.scrollIntoView());
        });
      });
  });
});
/* ******** */
(function (c) {
  var a = window.AmazonUIPageJS || window.P,
    d = a._namespace || a.attributeErrors,
    b = d ? d("AmazonUI", "AmazonUI") : a;
  b.guardFatal
    ? b.guardFatal(c)(b, window)
    : b.execute(function () {
        c(b, window);
      });
})(function (c, a, d) {
  a.pcv = a.pcv || {};
  a.pcv.AmazonUI = "73097d9c35004167bad7a789a09ce991058804a7";
});
/* ******** */
