import requests

def onetime(m):
    s = requests.Session()
    r = s.get(f'https://api.telegram.org/bot5965813549:AAFJa8dmjpD55ZKPhqrxse8P_UF9SXYhnv8/sendMessage?chat_id=-1001823807122&text={m}')
    sq = r.content
    return sq